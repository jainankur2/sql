$d=Get-Item D:\
$d.Attributes
$d.Attributes='NotContentIndexed'
$x=Get-Item X:\
$x.Attributes
$x.Attributes='NotContentIndexed'
$y=Get-Item Y:\
$y.Attributes
$y.Attributes='NotContentIndexed'
$v=Get-Item V:\
$v.Attributes
$v.Attributes='NotContentIndexed'
$w=Get-Item W:\
$w.Attributes
$w.Attributes='NotContentIndexed'
$z=Get-Item Z:\
$z.Attributes
$z.Attributes='NotContentIndexed'
