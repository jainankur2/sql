Import-Module SqlPS -DisableNameChecking
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SqlWmiManagement") 


try{

$Instance = "MSSQLSERVER"
$urn = "ManagedComputer[@Name='$env:computername']/ServerInstance[@Name='$Instance']/ServerProtocol[@Name='Tcp']"
$wmi = new-object ("Microsoft.SqlServer.Management.Smo.Wmi.ManagedComputer") $env:computername
$tcp = $wmi.GetSmoObject($urn);
$IPaddr=((ipconfig | findstr [0-9].\.)[2]).Split()[-1]
$a=$IPaddr
$tcp.IPAddresses["IP2"].IPAddressProperties["IpAddress"].Value = "$a";
$tcp.Alter();

}
catch{
$_ | fl -Force
}
