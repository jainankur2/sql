USE [msdb]
GO

/****** Object:  Job [Alert - Disk Space Enhanced]    Script Date: 10/25/2014 12:49:00 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 10/25/2014 12:49:00 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Alert - Disk Space Enhanced', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'Step 1 --  Creates a history table named DiskSpace in master. 
Step 2 -- Inserts Drives/Disk Space info into the DiskSpace table
Step 3 -- Defines thresholds and size ranges used to send alert emails. 
Step 4 --  Email.  Job will send an email if: 
  a) If FreeSpace falls below the threshold and no email has been sent for 1hr
  b) If FreeSpace has fallen by 10% within the last 30 minutes.
Step 5 -- Purges old data from the master.dbo.DiskSpace table', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [1 - CREATE DiskSpace TABLE IN MASTER DB]    Script Date: 10/25/2014 12:49:01 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'1 - CREATE DiskSpace TABLE IN MASTER DB', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'/*****************  STEP 1  CREATE DiskSpace TABLE IN MASTER DB********************/
USE [master]

IF  NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[DiskSpace]'') AND type in (N''U''))
BEGIN
CREATE TABLE [dbo].[DiskSpace](
	[ServerName] [varchar](250) NULL,
	[Drive] [char](3) NOT NULL,
	[FreeSpace] [int] NULL,
	[TotalSize] [int] NULL,
	[Threshold] [int] NULL,
	[PercentFree] [int] NULL,
	[FreespaceTimestamp] [datetime] NULL,
	[Alert] [int] NULL,
	[EmailSent] [char](1) NULL
) ON [PRIMARY]
END', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [2 - GATHER DISK INFO]    Script Date: 10/25/2014 12:49:01 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'2 - GATHER DISK INFO', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=4, 
		@on_fail_step_id=6, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'/***************  STEP 2 -- GATHER DISK INFO  ***********************/

-- Downloaded this from the web
declare @svrName varchar(255)
declare @sql varchar(400)
                            --by default it will take the current server name, we can the set the server name as well
set @svrName = CAST(SERVERPROPERTY(''ComputerNamePhysicalNetBIOS'') as varchar(128))
set @sql = ''powershell.exe -c "Get-WmiObject -ComputerName '' + QUOTENAME(@svrName,'''''''') + '' -Class Win32_Volume -Filter ''''DriveType = 3'''' | select name,capacity,freespace | foreach{$_.name+''''|''''+$_.capacity/1048576+''''%''''+$_.freespace/1048576+''''*''''}"''

                          --creating a temporary table
CREATE TABLE #output
(line varchar(255))
                            --inserting disk name, total space and free space value in to temporary table
insert #output
EXEC xp_cmdshell @sql
                      --script to retrieve the values in MB from PS Script output and insert them into the DiskSpaceTable
Insert into master.dbo.DiskSpace 
	(ServerName, Drive, FreeSpace, TotalSize)
select @svrName, rtrim(ltrim(SUBSTRING(line,1,CHARINDEX(''|'',line) -1))) as Drivename
      ,round(cast(rtrim(ltrim(SUBSTRING(line,CHARINDEX(''%'',line)+1,
      (CHARINDEX(''*'',line) -1)-CHARINDEX(''%'',line)) )) as Float),0) as ''freespace(MB)''
      ,round(cast(rtrim(ltrim(SUBSTRING(line,CHARINDEX(''|'',line)+1,
      (CHARINDEX(''%'',line) -1)-CHARINDEX(''|'',line)) )) as Float),0) as ''capacity(MB)''
from #output
where line like ''[A-Z][:]%''
order by Drivename
drop table #output', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [3 - SET Alert THRESHOLDS]    Script Date: 10/25/2014 12:49:01 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'3 - SET Alert THRESHOLDS', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=4, 
		@on_fail_step_id=6, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'/*************** STEP 3 Set Alert Thresholds   *****/

--  Add Threshold value & DateTime to DiskSpace Table 
--  FreeSpace values <100 are considered % free, FreeSpace values > 100 are considered MB  

DECLARE @SizeRange1 int, @SizeRange2 int, @SizeRange3 int, @SizeRange4 int, -- In MB These define the total disk space for the alert
		@CDrive int, @FreeSpace1 int, @FreeSpace2 int, @FreeSpace3 int, @FreeSpace4 int, @FreeSpace5 int, -- In MB min free space
		@FreespaceTimestamp datetime

SET @CDrive = 1024

SET @FreeSpace1 = 15 --  When Drive is <@SizeRange1

SET @SizeRange1 = 250000

SET @FreeSpace2 = 15 --  When Drive is between @SizeRange1 and @SizeRange2

SET @SizeRange2 = 500000

SET @FreeSpace3 = 80000 --  When Drive is between @SizeRange2 and @SizeRange3

SET @SizeRange3 = 1000000

SET @FreeSpace4 = 120000 -- When Drive is between @SizeRange3 and @SizeRange4

SET @SizeRange4 = 2000000

SET @FreeSpace5 = 200000 --  When Drive is > @SizeRange4

UPDATE DiskSpace
SET Threshold = CASE 	WHEN Drive = ''C:\'' THEN @CDrive
						WHEN TotalSize < @SizeRange1 and Drive <> ''C:\'' THEN @FreeSpace1
						WHEN TotalSize between @SizeRange1 and @SizeRange2 and Drive <> ''C:\'' THEN @FreeSpace2
						WHEN TotalSize between @SizeRange2 and @SizeRange3 and Drive <> ''C:\'' THEN @FreeSpace3
						WHEN TotalSize between @SizeRange3 and @SizeRange4 and Drive <> ''C:\'' THEN @FreeSpace4
						WHEN TotalSize > @SizeRange4  and Drive <> ''C:\'' THEN @FreeSpace5
			    END, 
	PercentFree = (FreeSpace/(TotalSize*1.0))*100.0,
	FreespaceTimestamp = CAST(CAST(CURRENT_TIMESTAMP as DATE)as CHAR(10))+'' ''+
						CASE	WHEN CAST(DATEPART(hh,CURRENT_TIMESTAMP) as VARCHAR(2)) < 10 
								THEN ''0''+ CAST(DATEPART(hh,CURRENT_TIMESTAMP) as VARCHAR(2))
								ELSE CAST(DATEPART(hh,CURRENT_TIMESTAMP) as VARCHAR(2)) 
						END+'':''+
						CASE	WHEN CAST(DATEPART(mi,CURRENT_TIMESTAMP) as VARCHAR(2)) <10 
								THEN ''0''+CAST(DATEPART(mi,CURRENT_TIMESTAMP) as VARCHAR(2))
								ELSE CAST(DATEPART(mi,CURRENT_TIMESTAMP) as VARCHAR(2)) 
						END			    
Where Threshold is null and FreespaceTimestamp is null

SET @FreespaceTimestamp = (Select MAX(FreespaceTimestamp) from master.dbo.DiskSpace)

/* Set Alert Flag for MB Thresholds*/

Update DiskSpace
SET DiskSpace.Alert = 1
FROM (Select Drive from  master.dbo.DiskSpace where FreespaceTimestamp = @FreespaceTimestamp and Threshold > 100) as DS2
WHERE DiskSpace.Alert is null and DiskSpace.Drive = DS2.Drive and
(
(TotalSize < @SizeRange1 and FreeSpace < @FreeSpace1 and DiskSpace.Drive <> ''C:\'') or
(TotalSize between @SizeRange1 and @SizeRange2 and FreeSpace < @FreeSpace2 and DiskSpace.Drive <> ''C:\'') or
(TotalSize between @SizeRange2 and @SizeRange3 and FreeSpace < @FreeSpace3 and DiskSpace.Drive <> ''C:\'') or
(TotalSize between @SizeRange3 and @SizeRange4 and FreeSpace < @FreeSpace4 and DiskSpace.Drive <> ''C:\'') or
(TotalSize > @SizeRange4 and FreeSpace < @FreeSpace5 and DiskSpace.Drive <> ''C:\'') or
(DiskSpace.Drive = ''C:\'' and FreeSpace < @CDrive)
)
and FreespaceTimestamp = @FreespaceTimestamp

/* Set Alert Flag for % Thresholds*/

Update DiskSpace
SET DiskSpace.Alert = 1
FROM (Select Drive from  master.dbo.DiskSpace where FreespaceTimestamp = @FreespaceTimestamp and Threshold < 100) as DS2
WHERE DiskSpace.Alert is null and DiskSpace.Drive = DS2.Drive and
(
(TotalSize < @SizeRange1 and PercentFree < @FreeSpace1 and DiskSpace.Drive <> ''C:\'') or
(TotalSize between @SizeRange1 and @SizeRange2 and PercentFree < @FreeSpace2 and DiskSpace.Drive <> ''C:\'') or
(TotalSize between @SizeRange2 and @SizeRange3 and PercentFree < @FreeSpace3 and DiskSpace.Drive <> ''C:\'') or
(TotalSize between @SizeRange3 and @SizeRange4 and PercentFree < @FreeSpace4 and DiskSpace.Drive <> ''C:\'') or
(TotalSize > @SizeRange4 and PercentFree < @FreeSpace5 and DiskSpace.Drive <> ''C:\'') or
(DiskSpace.Drive = ''C:\'' and PercentFree < @CDrive)
)
and FreespaceTimestamp = @FreespaceTimestamp

/* Set Alert Flag to 0 for non-alert situations  */
Update DiskSpace
SET Alert = 0
WHERE Alert is null
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [4 - SEND Alert EMAIL TO CSDBA-Alerts]    Script Date: 10/25/2014 12:49:01 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'4 - SEND Alert EMAIL TO CSDBA-Alerts', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=4, 
		@on_fail_step_id=6, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'/*************** STEP 4 Email DBAs when Alert is Needed  ***************************/

DECLARE @EmailTo varchar(250), @Sbjct varchar(250), @EmailBody varchar(max), @Results varchar(200), 
		@MinutesBetweenAlerts int, @PercentDifference int, @LastAlert datetime, @AlertTime datetime, 
		@Server varchar(200), @Drive char(3)
SET @EmailBody = '' ''
SET @MinutesBetweenAlerts = 59  --  Determines wait time in minutes between Alert Emails
SET @PercentDifference = 10    -- Overrides wait time if free disk space drops by this % in less than the wait time
SET @AlertTime = (Select MAX(FreespaceTimestamp) as MaxTime from DiskSpace) -- Time when this is running
SET @Server = CAST(SERVERPROPERTY(''ComputerNamePhysicalNetBIOS'') as varchar(200))
SET @Sbjct =''Alert - '' + @Server  +'' - Disk Space for Drive(s):''

-- Update EmailSent = Y when Free Space has dropped by > 10% in the last 10 minutes
UPDATE master.dbo.DiskSpace
SET EmailSent = ''Y''
WHERE	Alert = 1 and
		  EXISTS	(Select 1 
			from		(Select	DS.Drive, MAXDS.MaxFree, LSTALRT.MaxAlert
					From	master.dbo.DiskSpace as DS,
							(Select Drive, MAX(FreeSpace) as MaxFree 
							From	master.dbo.DiskSpace 
							Where	DATEDIFF(mi, FreespaceTimestamp, @AlertTime) <11 and
								FreespaceTimestamp <> @AlertTime
							group by Drive)
						as MAXDS left outer join 
							(Select Drive, MAX(FreespaceTimestamp) as MaxAlert
							 From	master.dbo.DiskSpace
							 Where	FreespaceTimestamp <> @AlertTime and EmailSent = ''Y''
							 Group by Drive)
						as LSTALRT on MAXDS.Drive = LSTALRT.Drive
					Where	DS.Drive = MAXDS.Drive and DS.FreespaceTimestamp = @AlertTime and
					100-(CAST(DS.FreeSpace as DECIMAL(18,2))/CAST(MAXDS.MaxFree as DECIMAL(18,2))*100) >= 10 and
					DATEDIFF(mi,isnull(LSTALRT.MaxAlert, ''1/1/2000''),@AlertTime) >= 29)
				as Alert
			Where	DiskSpace.Drive = Alert.Drive and DiskSpace.FreespaceTimestamp = @AlertTime)

--Updates EmailSent = ''Y'' when Alert = 1 and there has never been an alert email sent for that Drive
UPDATE master.dbo.DiskSpace
SET EmailSent = ''Y''  
WHERE Alert = 1 and EmailSent is null and not exists
		(Select 1 
		from	master.dbo.DiskSpace as DS2
		where DiskSpace.Drive = DS2.Drive and EmailSent = ''Y'')

					
--  Updates EmailSent = ''Y'' when Alert = 1 and it has been more than 59 minutes since the last alert was sent				
UPDATE master.dbo.DiskSpace
SET EmailSent = ''Y''  
WHERE Alert = 1 and EmailSent is null and not exists
		(Select 1 
		from	(Select Drive, MAX(FreespaceTimestamp) as LastAlert
				from	master.dbo.DiskSpace
				Where	FreespaceTimestamp < @AlertTime and EmailSent = ''Y'' and
						DATEDIFF(mi, FreespaceTimestamp,  @AlertTime) < 60
				Group By Drive) as PASTAlert
		where DiskSpace.Drive = PASTAlert.Drive)
				
Update master.dbo.DiskSpace set EmailSent = ''N'' where EmailSent is null					

						
IF (Select COUNT(*) from master.dbo.DiskSpace where EmailSent = ''Y'' and FreespaceTimestamp = @AlertTime) >0
BEGIN

DECLARE ResultsCursor scroll cursor FOR
	SELECT	D.Drive, D.Drive+''   Total Space = ''+CAST(D.TotalSize as varchar(20))+''MB''+
	        ''     Free Space =  ''+CAST(D.FreeSpace as varchar(20))+''MB (''+CAST(PercentFree as varchar(2))+''%)''+
			''     The Alert Threshold is set to ''+CAST(D.Threshold as varchar(20))+
			CASE WHEN D.Threshold < 100 THEN ''%'' ELSE ''MB'' END+CHAR(10)+ 
			CASE WHEN CAST((MF.FreeSpace - D.FreeSpace)/(MF.FreeSpace*1.0)*100 as int) > 9 THEN 
			''FreeSpace has dropped  ''+CAST(MF.FreeSpace - D.FreeSpace as varchar(10))+''MB (''+
			CAST(CAST((MF.FreeSpace - D.FreeSpace)/(MF.FreeSpace*1.0)*100 as int) as varchar(3))+''%) in the last 10 minutes.''  ELSE '' '' END
	FROM master.dbo.DiskSpace as D, 
			(Select Drive, MAX(FreeSpace) as FreeSpace 
			from master.dbo.DiskSpace 
			where DATEDIFF(mi, FreespaceTimestamp, @AlertTime) <11
			Group by Drive)
		 as MF
	WHERE	 D.FreespaceTimestamp = @AlertTime and D.Drive = MF.Drive and EmailSent = ''Y''

OPEN ResultsCursor
FETCH First from ResultsCursor into @Drive,  @Results

WHILE @@FETCH_STATUS = 0
BEGIN
SET  @Sbjct = @Sbjct  +''  ''+@Drive
SET @EmailBody = @EmailBody+@Results+CHAR(13)

Fetch Next from ResultsCursor into @Drive,  @Results
END
Close ResultsCursor
DEALLOCATE ResultsCursor


SET  @EmailTo =  ''CSDBA-Alerts@hcsc.com''
SET  @EmailBody = LTRIM(@EmailBody)

EXEC  msdb.dbo.sp_send_dbmail  @profile_name =''CSDBA-Alerts'',@recipients=@EmailTo, @subject= @Sbjct, @body=@EmailBody
END', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [5 - PURGE OLD DATA]    Script Date: 10/25/2014 12:49:01 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'5 - PURGE OLD DATA', 
		@step_id=5, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=4, 
		@on_fail_step_id=6, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'Delete from master.dbo.DiskSpace 
where EmailSent = ''N'' and DATEDIFF(mi, FreespaceTimestamp, getdate()) >90

Delete from master.dbo.DiskSpace
Where DATEDIFF(dd,FreespaceTimestamp, getdate()) > 179', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Email DBAs on Failure]    Script Date: 10/25/2014 12:49:01 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Email DBAs on Failure', 
		@step_id=6, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @mailbody varchar(255)
set @mailbody = ''Alert - Disk Space Enhanced job failure on: ''+@@servername
EXEC msdb.dbo.sp_send_dbmail @profile_name = ''CSDBA-Alerts'', @recipients = ''CSDBA-Alerts@hcsc.com'', @subject =  ''Alert - Disk Space Enhanced DB job failure'', @body =  @mailbody', 
		@database_name=N'msdb', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Remove zero freespace from master.dbo.DiskSpace]    Script Date: 10/25/2014 12:49:01 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Remove zero freespace from master.dbo.DiskSpace', 
		@step_id=7, 
		@cmdexec_success_code=0, 
		@on_success_action=2, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'delete from DiskSpace where FreeSpace=0', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'DiskSpaceAlertSched', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=4, 
		@freq_subday_interval=1, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20140212, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959--, 
--		@schedule_uid=N'5fa22388-c6c2-492a-a303-1f059fb46ca4'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO


