
USE master;
GO
EXEC sp_configure 'show advanced options', 1;
GO
RECONFIGURE WITH OVERRIDE;
GO

EXEC sp_configure 'xp_cmdshell', 1;
GO
RECONFIGURE WITH OVERRIDE;
GO

EXEC sp_configure 'Ole Automation Procedures', 1;
GO
RECONFIGURE WITH OVERRIDE;
GO

-- The following enables DAC from a remote computer 

EXEC sp_configure 'remote admin connections', 1;
GO
RECONFIGURE WITH OVERRIDE;
GO

EXEC sp_configure 'Database Mail XPs', 1;
GO
RECONFIGURE WITH OVERRIDE;
GO

EXEC sp_configure 'max worker threads', 0;
GO
RECONFIGURE WITH OVERRIDE;
GO

EXEC sp_configure 'Ad Hoc Distributed Queries', 1;
GO
RECONFIGURE WITH OVERRIDE;
GO

-- Below Config option should be applied only if Server has more than 4 GB RAM.

--EXEC sp_configure 'awe enabled', 1;
--G O
--RECONFIGURE WITH OVERRIDE;
--G O

EXEC sp_configure 'show advanced options', 1;
RECONFIGURE with OVERRIDE;
EXEC sp_configure 'lightweight pooling', 0;
EXEC sp_configure 'max worker threads', 0;
EXEC sp_configure 'blocked process threshold (s)', 0;
RECONFIGURE with OVERRIDE;
EXEC sp_configure 'show advanced options', 0;
RECONFIGURE with OVERRIDE

