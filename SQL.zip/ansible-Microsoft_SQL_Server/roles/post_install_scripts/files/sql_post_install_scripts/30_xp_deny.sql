USE master
GO
SET NOCOUNT ON
GO
--Variables/Temp table
DECLARE @xsp_object VARCHAR(50)
DECLARE @loop INT

IF OBJECT_ID('tempdb..#temp') IS NOT NULL
	DROP TABLE #temp

CREATE TABLE #temp
	(
	xsp_object VARCHAR(50),
	ID_Num INT NOT NULL IDENTITY(1,1)
	)

--List of sp and xp to search for
INSERT INTO #temp(xsp_object)
VALUES ('sp_readwebtask')
INSERT INTO #temp(xsp_object)
VALUES ('sp_OACreate')
INSERT INTO #temp(xsp_object)
VALUES ('sp_OADestroy')
INSERT INTO #temp(xsp_object)
VALUES ('sp_OAGetErrorInfo')
INSERT INTO #temp(xsp_object)
VALUES ('sp_OAGetProperty')
INSERT INTO #temp(xsp_object)
VALUES ('sp_OAMethod')
INSERT INTO #temp(xsp_object)
VALUES ('sp_OASetProperty')
INSERT INTO #temp(xsp_object)
VALUES ('sp_OAStop')
INSERT INTO #temp(xsp_object)
VALUES ('sp_replcmds')
INSERT INTO #temp(xsp_object)
VALUES ('sp_replcounters')
INSERT INTO #temp(xsp_object)
VALUES ('sp_repldone')
INSERT INTO #temp(xsp_object)
VALUES ('sp_replflush')
INSERT INTO #temp(xsp_object)
VALUES ('sp_repltrans')
INSERT INTO #temp(xsp_object)
VALUES ('xp_availablemedia')
INSERT INTO #temp(xsp_object)
VALUES ('xp_cmdshell')
INSERT INTO #temp(xsp_object)
VALUES ('xp_dirtree')
INSERT INTO #temp(xsp_object)
VALUES ('xp_dropwebtask')
INSERT INTO #temp(xsp_object)
VALUES ('xp_enumerrorlogs')
INSERT INTO #temp(xsp_object)
VALUES ('xp_findnextmsg')
INSERT INTO #temp(xsp_object)
VALUES ('xp_fixeddrives')
INSERT INTO #temp(xsp_object)
VALUES ('xp_getnetname')
INSERT INTO #temp(xsp_object)
VALUES ('xp_logevent')
INSERT INTO #temp(xsp_object)
VALUES ('xp_makewebtask')
INSERT INTO #temp(xsp_object)
VALUES ('xp_msver')
INSERT INTO #temp(xsp_object)
VALUES ('xp_readerrorlog')
INSERT INTO #temp(xsp_object)
VALUES ('xp_readmail')
INSERT INTO #temp(xsp_object)
VALUES ('xp_regaddmultistring')
INSERT INTO #temp(xsp_object)
VALUES ('xp_regdeletevalue')
INSERT INTO #temp(xsp_object)
VALUES ('xp_regenumvalues')
INSERT INTO #temp(xsp_object)
VALUES ('xp_regremovemultistring')
INSERT INTO #temp(xsp_object)
VALUES ('xp_runwebtask')
INSERT INTO #temp(xsp_object)
VALUES ('xp_sendmail')
INSERT INTO #temp(xsp_object)
VALUES ('xp_servicecontrol')
INSERT INTO #temp(xsp_object)
VALUES ('xp_sprintf')
INSERT INTO #temp(xsp_object)
VALUES ('xp_sscanf')
INSERT INTO #temp(xsp_object)
VALUES ('xp_startmail')
INSERT INTO #temp(xsp_object)
VALUES ('xp_stopmail')
INSERT INTO #temp(xsp_object)
VALUES ('xp_subdirs')


--Deny logic
SELECT @loop = MAX(ID_Num) FROM #temp

WHILE @loop > 0

	BEGIN	
		SELECT	@xsp_object = xsp_object 
		FROM 	#temp 
		WHERE 	ID_Num = @loop
	
		IF OBJECT_ID(@xsp_object) IS NOT NULL
			BEGIN
				EXEC ('Revoke  EXECUTE  ON [dbo].[' + @xsp_object + '] TO [public] CASCADE')
				PRINT @xsp_object + ' Revoked'
			END
		ELSE
				PRINT @xsp_object + ' Not Found'
	
		
	SET @loop = @loop - 1
		
	END


