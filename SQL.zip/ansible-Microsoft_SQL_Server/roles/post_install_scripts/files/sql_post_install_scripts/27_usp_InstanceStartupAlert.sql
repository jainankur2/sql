USE master
go
CREATE PROCEDURE usp_InstanceStartupAlert
AS


DECLARE @sbjct varchar(255),@instance varchar(128), @server varchar(128)
Select @instance = @@servername
Select @server = CAST(SERVERPROPERTY('ComputerNamePhysicalNetBIOS') as varchar(128))
set @sbjct = 'MSSQL Instance = '+@instance+' has just started up on Server = '+@server

EXEC msdb.dbo.sp_send_dbmail  @profile_name = 'CSDBA-Alerts' 
    , @recipients = 'CSDBA-Alerts@hcsc.com'
    , @subject =  @sbjct
    , @body = 'Please check the DBs and determine the cause for the restart.'
    
GO
Exec sp_procoption 'usp_InstanceStartupAlert', 'startup', 'on'