SET NOCOUNT ON
DECLARE @DOMAIN CHAR(9)
DECLARE @NPID   VARCHAR(20) = '67310004' -- Monitoring
DECLARE @SQL    VARCHAR(MAX)

SET @DOMAIN = DEFAULT_DOMAIN() 

SELECT @SQL ='USE [master];
IF EXISTS (SELECT 1 FROM MASTER.SYS.SYSLOGINS WHERE NAME = ''' + @DOMAIN + '\' + @NPID + ''')
 BEGIN
  DROP LOGIN [' + @DOMAIN + '\' + @NPID + ']
 END;
CREATE LOGIN [' + @DOMAIN + '\' + @NPID + '] FROM WINDOWS WITH DEFAULT_DATABASE=[master];
use [master];
grant select on master.sys.databases to [' + @DOMAIN + '\' + @NPID + '];
grant select on master.sys.sysperfinfo to [' + @DOMAIN + '\' + @NPID + '];
grant select on master.sys.database_files to [' + @DOMAIN + '\' + @NPID + '];
grant select on master.sys.partitions to [' + @DOMAIN + '\' + @NPID + '];
grant select on master.sys.allocation_units to [' + @DOMAIN + '\' + @NPID + '];
grant select on master.sys.internal_tables to [' + @DOMAIN + '\' + @NPID + '];
grant select on master.sys.filegroups to [' + @DOMAIN + '\' + @NPID + '];
use [msdb];
grant select on msdb.dbo.sysjobsteps to [' + @DOMAIN + '\' + @NPID + '];
grant select on msdb.dbo.sysjobs to [' + @DOMAIN + '\' + @NPID + '];
grant select on msdb.dbo.syscategories to [' + @DOMAIN + '\' + @NPID + '];
grant select on msdb.dbo.log_shipping_monitor_secondary to [' + @DOMAIN + '\' + @NPID + '];
grant select on msdb.dbo.log_shipping_monitor_primary to [' + @DOMAIN + '\' + @NPID + '];
grant select on msdb.dbo.sysjobhistory to [' + @DOMAIN + '\' + @NPID + '];
Use [master];
Grant execute on xp_msver to [' + @DOMAIN + '\' + @NPID + '];'

EXEC(@SQL);
