create table #directory (dirname varchar(1000))

insert into #directory
Exec xp_cmdshell 'DIR D:\SQLServer_DR\*.*'

If (Select count(*) from #directory)=2
Begin
	Exec xp_cmdshell 'MKDIR D:\SQLServer_DR'
	Print 'Directory created'
End

drop table #directory

GO
USE MASTER
GO

IF EXISTS (SELECT * FROM DBO.SYSOBJECTS WHERE ID = OBJECT_ID(N'[DBO].[SP_CREATEDATABASEBACKUP_DR]') AND OBJECTPROPERTY(ID, N'ISPROCEDURE') = 1)
DROP PROCEDURE [DBO].[SP_CREATEDATABASEBACKUP_DR]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO
CREATE PROCEDURE SP_CREATEDATABASEBACKUP_DR   
	@SOURCEFOLDER VARCHAR(200)='D:\SQlServer_DR\',  
	@DBNAME VARCHAR(100),  
	@BACKUPTYPE VARCHAR(20) ='FULL',  
	@ENVIRONMENT VARCHAR(20) = NULL,  
	@DBBACKUPFILERETENTIONS INT =0
AS  
SET NOCOUNT ON  
  

	-- CHECK FOR VALID DATA INPUT   

	IF  @BACKUPTYPE NOT IN('FULL')   
	BEGIN  
		PRINT 'PLEASE PASS VALIDATE BACKUP DATABASE TYPE (FULL)'  
		RETURN(1)  
	END  

	IF  @ENVIRONMENT IS NOT NULL AND @ENVIRONMENT !=''  
		SELECT @ENVIRONMENT ='_' + @ENVIRONMENT+'_'  
	ELSE   
		SELECT @ENVIRONMENT ='_'  
  
    
   
  
	DECLARE @DEVICE			NVARCHAR(200), 
			@NAME			NVARCHAR(200),
			@DELETE			NVARCHAR(1000), 
			@ERROR			INT, 
			@SERVERNAME		VARCHAR(200),  
			@ERRDESCRIPTION VARCHAR(1000),
			@SQL			NVARCHAR(2000),
			@ROWCNT			INT   

	DECLARE @EMAILFROM		VARCHAR(25), 
			@SUBJECT		VARCHAR(100),
			@EMAILBODY		VARCHAR(4000),
			@EMAILTO		VARCHAR(50)   
			
	DECLARE @DBOFFLINE		INT ,
			@DBSUSPECT		INT   
	IF CHARINDEX('\', @@SERVERNAME) >0  
		BEGIN   
			SELECT   @SERVERNAME=LEFT( @@SERVERNAME,(CHARINDEX('\', @@SERVERNAME) -1)) + '_' + RIGHT(@@SERVERNAME, LEN(@@SERVERNAME) - CHARINDEX('\', @@SERVERNAME))  
		END  
	ELSE  
		BEGIN   
			SELECT   @SERVERNAME=@@SERVERNAME  
		END  

  
	IF RIGHT(LTRIM(RTRIM(@SOURCEFOLDER)),1)!='\'  
		SET @SOURCEFOLDER = @SOURCEFOLDER+'\'  
    
 
	SELECT  @DBOFFLINE= DATABASEPROPERTY(@DBNAME,'ISOFFLINE')   
	SELECT  @DBSUSPECT = DATABASEPROPERTY(@DBNAME,'ISSUSPECT')   
  
	IF @DBOFFLINE !=0 OR @DBOFFLINE IS NULL  
	BEGIN  
		PRINT 'PLEASE VALIDATE DATABASE NAME/STATUS'  
		RETURN(1)  
	END  
   
 	IF @BACKUPTYPE IS NULL OR @BACKUPTYPE  ='' OR @BACKUPTYPE ='FULL'  
	BEGIN  
		SET  @BACKUPTYPE = 'FULL'  
		IF @DBBACKUPFILERETENTIONS = 0 OR @DBBACKUPFILERETENTIONS IS  NULL  
		BEGIN  
			SET @DELETE = 'DEL ' +'"' + @SOURCEFOLDER +@SERVERNAME  +'_'+ @DBNAME+@ENVIRONMENT +   '*.BAK' + '"'+' /Q '   
			EXEC @ERROR = XP_CMDSHELL @DELETE  
		END  
	END
       
  
   
	SET @DEVICE =    @SOURCEFOLDER+ @SERVERNAME  +'_'+ @DBNAME+@ENVIRONMENT+   
		RIGHT('0'+CAST(DAY(GETDATE()) AS NVARCHAR(4)),2) +   
		RIGHT('0'+CAST(MONTH(GETDATE()) AS NVARCHAR(4)),2) +   
		CAST(YEAR(GETDATE()) AS NVARCHAR(8))  +  
		CAST(DATEPART( HH,GETDATE())  AS NVARCHAR(2))+  
		RIGHT('0' + CAST(DATEPART( MI,GETDATE())  AS NVARCHAR(2)),2)  + N'.BAK'   
   
  
	BACKUP DATABASE @DBNAME TO DISK = @DEVICE WITH  INIT ,  NOUNLOAD ,   
		NAME = @DBNAME,  NOSKIP ,  STATS = 10,  NOFORMAT    
      
    SET @ERROR = @@ERROR  
	IF @ERROR <> 0  
	BEGIN  
		SELECT @ERRDESCRIPTION= 'UNABLE TO COMPLETE DATABASE BACKUP OPERATION  ERROR NUMBER:  '  + CONVERT(VARCHAR,@ERROR) + ' DATABASE NAME:' + @DBNAME      
		GOTO ERRORHANDLER  
	END  
  
    RETURN(0)  
  
 ERRORHANDLER:  
	BEGIN  
		SELECT @ERRDESCRIPTION= @ERRDESCRIPTION  + ' ERROR MESSAGE(SYSTEM TEMPLATE MESSAGE) ' + DESCRIPTION  FROM MASTER..SYSMESSAGES WHERE ERROR = @ERROR  
		SELECT @ERRDESCRIPTION  
		RAISERROR ('DATABASE BACKUP OPERATION FAILED', 16, 1) WITH LOG  
		-- SEND EMAIL ON FAILURE BACKUP OPERATION  

		SET @EMAILFROM=  'DATABASEBACKUP@BCBS.COM'  
		SET @EMAILTO =    'CSDBA-ALERTS.HCSC'  
		SET @SUBJECT =  'ALERT -' + @@SERVERNAME +' - DATABASEBACKUP OPERATION FAILED'  
		SET @EMAILBODY= @ERRDESCRIPTION   

		--    EXEC      @EMAILFROM,@EMAILTO,@SUBJECT,@EMAILBODY, ''  

		RETURN(1)  

	END  
   
   
Go

USE [msdb]
GO

IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'Backup System Database for DR')
EXEC msdb.dbo.sp_delete_job @job_name=N'Backup System Database for DR', @delete_unused_schedule=1

/****** Object:  Job [Backup System Database for DR]    Script Date: 09/27/2016 16:17:59 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
DECLARE @sqlcmd varchar(max) = N'sqlcmd  -y0 -S' + @@ServerName + ' -E -dmaster -Q"set nocount on select HTML_info from master.dbo.HTML_code  where HTML_info is not NULL order by ID" -o"D:\SQLServer_DR\' + REPLACE(@@ServerName,'\','_') + '_ServerDatabaseDocument.html"'
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 09/27/2016 16:17:59 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Backup System Database for DR', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DR Master database native backup to local drive]    Script Date: 09/27/2016 16:17:59 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DR Master database native backup to local drive', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=4, 
		@on_success_step_id=2, 
		@on_fail_action=4, 
		@on_fail_step_id=6, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'SP_CREATEDATABASEBACKUP_DR @DBNAME = ''master''', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DR Model database native backup to local drive]    Script Date: 09/27/2016 16:17:59 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DR Model database native backup to local drive', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=4, 
		@on_success_step_id=3, 
		@on_fail_action=4, 
		@on_fail_step_id=6, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'SP_CREATEDATABASEBACKUP_DR @DBNAME = ''model''', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DR Msdb database native backup to local drive]    Script Date: 09/27/2016 16:17:59 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DR Msdb database native backup to local drive', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=4, 
		@on_success_step_id=4, 
		@on_fail_action=4, 
		@on_fail_step_id=6, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'SP_CREATEDATABASEBACKUP_DR @DBNAME = ''msdb''', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Create HTML Code]    Script Date: 09/27/2016 16:17:59 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Create HTML Code', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=4, 
		@on_success_step_id=5, 
		@on_fail_action=4, 
		@on_fail_step_id=6, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'set nocount on

-- Declaration sections
DECLARE @StringHTML varchar(max)

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''master.dbo.HTML_code'') AND type in (N''U''))
begin
     create table master.dbo.HTML_code (ID int identity(1,1), HTML_info varchar(max))
end

truncate table master.dbo.HTML_code

-- Header
SET @StringHTML = ''''

SELECT @StringHTML = @StringHTML + ''<HTML><HEAD><TITLE>Server / Database Informations</TITLE><STYLE>TD.Sub{FONT-WEIGHT:bold;BORDER-BOTTOM: 0pt solId #000000;BORDER-LEFT: 1pt solId #000000;BORDER-RIGHT: 0pt solId #000000;BORDER-TOP: 0pt solId #000000; FONT-FAMILY: Tahoma;FONT-SIZE: 8pt} BODY{FONT-FAMILY: Tahoma;FONT-SIZE: 8pt} TABLE{BORDER-BOTTOM: 1pt solId #000000;BORDER-LEFT: 0pt solId #000000;BORDER-RIGHT: 1pt solId #000000;BORDER-TOP: 0pt solId #000000; FONT-FAMILY: Tahoma;FONT-SIZE: 8pt} TD{BORDER-BOTTOM: 0pt solId #000000;BORDER-LEFT: 1pt solId #000000;BORDER-RIGHT: 0pt solId #000000;BORDER-TOP: 1pt solId #000000; FONT-FAMILY: Tahoma;FONT-SIZE: 8pt} TD.Title{FONT-WEIGHT:bold;BORDER-BOTTOM: 0pt solId #000000;BORDER-LEFT: 1pt solId #000000;BORDER-RIGHT: 0pt solId #000000;BORDER-TOP: 1pt solId #000000; FONT-FAMILY: Tahoma;FONT-SIZE: 12pt} A.Index{FONT-WEIGHT:bold;FONT-SIZE:8pt;COLOR:#000099;FONT-FAMILY:Tahoma;TEXT-DECORATION:none} A.Index:HOVER{FONT-WEIGHT:bold;FONT-SIZE:8pt;COLOR:#990000;FONT-FAMILY:Tahoma;TEXT-DECORATION:none}</STYLE></HEAD><BODY><A NAME="_top"></A><BR>''
INSERT INTO master.dbo.HTML_code values(@StringHTML)
SELECT @StringHTML = ''<BR><CENTER><FONT SIZE="5"><B>Server / Database Informations</B></FONT></CENTER><BR>''
INSERT INTO master.dbo.HTML_code values(@StringHTML)
INSERT INTO master.dbo.HTML_code values(''<CENTER><A HREF="#_ServerOptions" CLASS="Index">Server Settings<A>  |  <A HREF="#_ListDatabases" CLASS="Index">Database List<A>  |  <A HREF="#_ListJobs" CLASS="Index">Job List<A>  </CENTER><BR>'')

-- Server information

INSERT INTO master.dbo.HTML_code values(''<DIV ALIGN="center"><TABLE BORDER="0" CELLPADDING="2" CELLSPACING="0" BORDERCOLOUR="003366" WIdTH="60%">'')
INSERT INTO master.dbo.HTML_code values(''<TR BGCOLOR="EEEEEE"><TD CLASS="Title" COLSPAN="2" ALIGN="center"><B><A NAME="_ServerOptions">Server Settings</A></B> </TD></TR>'')
INSERT INTO master.dbo.HTML_code values(''<TR BGCOLOR="EEEEEE"><TD ALIGN="left" WIdTH="30%"><B>Database Name</B> </TD><TD ALIGN="left" WIdTH="70%"><B>Row Count</B> </TD></TR>'')

Declare @ServerName		varchar(100),
		@InstanceName	varchar(100),
		@SQL			Varchar(1000),
		@InstanceIP		Varchar(100),
		@portNo		varchar(10),
		@SQLVersion		Varchar(250),
		@DB_ServicePack	Varchar(10)
		
		
-- SQL Version
Select @SQLVersion = Left(@@version, charindex(''-'', @@version)-1) 
		+ Convert(Varchar(100), ServerProperty(''Edition''))
		+ ''( '' + convert(Varchar(100), (ServerProperty(''ProductVersion'') )) +'' )''
		
Select @DB_ServicePack = Convert(varchar(10), ServerProperty(''ProductLevel''))

Create table #GeneralInfo (Details varchar(8000))

Set @ServerName = Convert(Varchar(100), ServerProperty(''ComputerNamePhysicalNetBIOS''))

-- To get Instance Name and IP
Set @InstanceName = case When @ServerName=@@Servername then ''Default'' Else @@Servername end

Set @SQL = ''exec master.dbo.xp_cmdshell '''''' +''ping''+ '' ''+ @ServerName +'' -n 1''+''''''''

Insert into #GeneralInfo
Exec(@SQL)

-- Cleanup records
delete from #GeneralInfo where Details Not like ''Pinging %'' 
delete from #GeneralInfo where IsNull(Details,'''')=''''


-- Get Instance IP

create table #tmp2 (ID int identity(1,1), ipval varchar(200))
declare @instnc_ip varchar(200)
if @@SERVERNAME like ''%\%''
begin
set @instnc_ip = ''nslookup '' +  SUBSTRING(@@servername, 1,CHARINDEX(''\'', @@servername) - 1)
end
if @@SERVERNAME not like ''%\%''
begin
set @instnc_ip = ''nslookup '' +  @@servername
end
insert into #tmp2 exec master..xp_cmdshell @instnc_ip
 
delete from #tmp2 where ipval is null
if (select COUNT(*) from #tmp2 where ipval like ''%Address:%'') > 1
begin
select top 1 @InstanceIP =  REPLACE(IPVAL, ''Address:  '' ,'''') from #tmp2 where ipval LIKE ''%Address:%'' order by ID desc
end
if (select COUNT(*) from #tmp2 where ipval like ''%Address:%'') = 1
begin
select @InstanceIP =  ''NSLOOKUP for instance is not resolving. Check DNS entry''
end
drop table #tmp2
 
-- Get Port Number

EXEC   xp_instance_regread
@rootkey    = ''HKEY_LOCAL_MACHINE'',
@key        =
''Software\Microsoft\Microsoft SQL Server\MSSQLServer\SuperSocketNetLib\Tcp\IpAll'',
@value_name = ''TcpPort'',
@value      = @portNo OUTPUT
  

-- OS info
delete from #GeneralInfo 
insert into  #GeneralInfo
exec master..xp_cmdshell ''systeminfo''

Declare @OSName			Varchar(150),
		@OSVersion		Varchar(150),
		@InstallDate	Varchar(150),
		@SystemUpTime	Varchar(150),
		@NoOfProcessors	Varchar(100),
		@TotalMemory	Varchar(100),
		@Domain			Varchar(100),
		@IsClustered	Varchar(100)
		
Select @OSName = Convert(Varchar(150), LTRIM(RTRIM(REPLACE(Details, ''OS Name:'', ''''))))
		from #GeneralInfo Where Details like ''OS Name:%''
Select @OSVersion = Convert(Varchar(150), LTRIM(RTRIM(REPLACE(Details, ''OS Version:'', '''')))) 
		from #GeneralInfo Where Details like ''OS Version:%''
Select @InstallDate = Convert(Varchar(150), LTRIM(RTRIM(REPLACE(Details, ''Original Install Date:'', ''''))))  
		from #GeneralInfo Where Details like ''Original Install Date:%''
Select @SystemUpTime = Convert(Varchar(150), LTRIM(RTRIM(REPLACE(Details, ''System Up Time:'', ''''))))  
		from #GeneralInfo Where Details like ''System Up Time:%''
Select @NoOfProcessors = Convert(Varchar(150), LTRIM(RTRIM(REPLACE(Details, ''Processor(s):'', ''''))))  
		from #GeneralInfo Where Details like ''Processor(s):%''
Select @TotalMemory = Convert(Varchar(150), LTRIM(RTRIM(REPLACE(Details, ''Total Physical Memory:'', '''')))) 
		from #GeneralInfo Where Details like ''Total Physical Memory:%''
Select @Domain = Convert(Varchar(150), LTRIM(RTRIM(REPLACE(Details, ''Domain:'', ''''))))  
		from #GeneralInfo Where Details like ''Domain:%''
Set @IsClustered = Case When  ServerProperty(''IsClustered'') =1 then ''YES'' Else ''No'' End

INSERT INTO master.dbo.HTML_code values(''<TR><TD><B>Server Name</B> </TD><TD>'' + @ServerName + '' </TD></TR>'')
INSERT INTO master.dbo.HTML_code values(''<TR><TD><B>Instance Name</B> </TD><TD>'' + @InstanceName + '' </TD></TR>'')
INSERT INTO master.dbo.HTML_code values(''<TR><TD><B>Instance IP</B> </TD><TD>'' + @InstanceIP + '' </TD></TR>'')
INSERT INTO master.dbo.HTML_code values(''<TR><TD><B>Instance Port Number</B> </TD><TD>'' + @portNo + '' </TD></TR>'')
INSERT INTO master.dbo.HTML_code values(''<TR><TD><B>OS Name</B> </TD><TD>'' + @OSName + '' </TD></TR>'')
INSERT INTO master.dbo.HTML_code values(''<TR><TD><B>OS Version</B> </TD><TD>'' + @OSVersion + '' </TD></TR>'')
INSERT INTO master.dbo.HTML_code values(''<TR><TD><B>SQL Server Version </B> </TD><TD>'' + @SQLVersion + '' </TD></TR>'')
INSERT INTO master.dbo.HTML_code values(''<TR><TD><B>SQL Server Service Pack</B> </TD><TD>'' + @DB_ServicePack + '' </TD></TR>'')
INSERT INTO master.dbo.HTML_code values(''<TR><TD><B>Domain</B> </TD><TD>'' + @Domain + '' </TD></TR>'')
INSERT INTO master.dbo.HTML_code values(''<TR><TD><B>No Of Processors</B> </TD><TD>'' + @NoOfProcessors + '' </TD></TR>'')
INSERT INTO master.dbo.HTML_code values(''<TR><TD><B>Total Memory</B> </TD><TD>'' + @TotalMemory + '' </TD></TR>'')
INSERT INTO master.dbo.HTML_code values(''<TR><TD><B>Is Clustered</B> </TD><TD>'' + CONVERT(CHAR(1), @IsClustered) + '' </TD></TR>'')
INSERT INTO master.dbo.HTML_code values(''<TR><TD><B>System Up Time</B> </TD><TD>'' + @SystemUpTime + '' </TD></TR>'')

-- To display drive info
Declare @DriveLetter	Varchar(1), 
		@FreeSpace		Varchar(25)
SET NOCOUNT ON 
DECLARE @hr int 
DECLARE @fso int 
DECLARE @size float 
DECLARE @mbtotal int 
DECLARE @drive char(1) 
DECLARE @fso_Method varchar(255) 
SET @mbTotal = 0 

CREATE TABLE #space (drive char(1), mbfree int, mbtotalSpace int) 
INSERT INTO #space (drive, mbfree) EXEC master.dbo.xp_fixeddrives 

EXEC @hr = master.dbo.sp_OACreate ''Scripting.FilesystemObject'', @fso OUTPUT 

DECLARE cDrives CURSOR FAST_FORWARD FOR SELECT drive FROM #space 
OPEN cDrives 
FETCH NEXT FROM cDrives INTO @drive 

WHILE @@FETCH_STATUS = 0 
BEGIN 
SET @fso_Method = ''Drives("'' + @drive + '':").TotalSize'' 
EXEC @hr = sp_OAMethod @fso, @fso_method, @size OUTPUT 

update #space set mbtotalSpace = @size/(1024*1024)
where drive = @drive
FETCH NEXT FROM cDrives INTO @drive 
END 
CLOSE cDrives 
DEALLOCATE cDrives 
EXEC @hr = sp_OADestroy @fso 

DECLARE driveinfo cursor 
For
Select drive, rtrim(mbtotalspace) +'' ( ''+ ltrim(rtrim(mbfree)) + '' Free)'' from #space order by drive
Open driveinfo
Fetch next from driveinfo into @DriveLetter, @FreeSpace
While @@fetch_status=0
Begin
	INSERT INTO master.dbo.HTML_code values(''<TR><TD><B>Drive '' + @DriveLetter + '' </B> </TD><TD>'' + @FreeSpace + '' MB </TD></TR>'')
	Fetch next from driveinfo into  @DriveLetter, @FreeSpace 
End
close driveinfo
deallocate driveinfo

drop table #space
INSERT INTO master.dbo.HTML_code values(''</TABLE><BR><A CLASS="Index" HREF="#_top">Back To Top ^</A><BR><BR>'')
Drop table #GeneralInfo

-- Database list
INSERT INTO master.dbo.HTML_code values(''<DIV ALIGN="center"><TABLE BORDER="0" CELLPADDING="2" CELLSPACING="0" BORDERCOLOUR="003366" WIdTH="60%">'')
INSERT INTO master.dbo.HTML_code values(''<TR BGCOLOR="EEEEEE"><TD CLASS="Title" COLSPAN="2" ALIGN="center"><B><A NAME="_ListDatabases">List of Databases</A></B> </TD></TR>'')
INSERT INTO master.dbo.HTML_code values(''<TR BGCOLOR="EEEEEE"><TD ALIGN="left" WIdTH="100%"><B>Database Name</B> </TD>'')

Declare @DBName		Varchar(100)
DECLARE dblist cursor For
Select name from sys.sysdatabases order by dbid
Open dbList
Fetch next from dblist into @DBName
While @@fetch_status=0
Begin
	INSERT INTO master.dbo.HTML_code values(''<TR><TD VALIGN="top"><A CLASS="Index" HREF="#_DB_''+@DBName + ''">'' + @DBName + ''</A> </TD><TD BGCOLOR="EEEEEE" COLSPAN="5">  </TD></TR>'')
	Fetch next from dblist into @DBName 
End
close dblist
deallocate dblist
	INSERT INTO master.dbo.HTML_code values(''</TABLE><BR><A CLASS="Index" HREF="#_top">Back To Top ^</A><BR><BR>'')
	
-- Each database details
DECLARE @Recovery			Varchar(20),
		@DBLastBackup		VARCHAR(100),
		@DBLastBackupDays	VARCHAR(100)

DECLARE dblist cursor 
For
Select name from sys.sysdatabases order by dbid
Open dbList
Fetch next from dblist into @DBName
While @@fetch_status=0
Begin
	SET @StringHTML = ''<DIV ALIGN="center"><TABLE BORDER="0" CELLPADDING="2" CELLSPACING="0" BORDERCOLOUR="003366" WIdTH="60%">
				<TR BGCOLOR="EEEEEE"><TD CLASS="Title" COLSPAN="2" ALIGN="center" VALIGN="top"><A NAME="_DB_''+ @DBName +''"><B>Database Settings - '' + @DBName + ''</B></A> </TD></TR>
				<TR BGCOLOR="EEEEEE">
				  <TD ALIGN="left" WIdTH="30%"><B>Option</B> </TD>
				  <TD ALIGN="left" WIdTH="70%"><B>Setting</B> </TD>
				</TR>''

	INSERT INTO master.dbo.HTML_code values(@StringHTML)
	Set @Recovery = CONVERT(Varchar(20), DATABASEPROPERTYEX(@DBName, ''Recovery''))
	SELECT @StringHTML = 	''<TR><TD><B>Name</B> </TD><TD>'' +[Name]+ '' </TD></TR>'' +
				''<TR><TD><B>Recovery Model</B> </TD><TD>'' + @Recovery + '' </TD></TR>'' +
				''<TR><TD><B>autoclose</B> </TD><TD>'' + MIN(CASE [Status] & 1 WHEN 1 THEN ''True'' ELSE ''False'' END) + '' </TD></TR>'' +
				''<TR><TD><B>offline</B> </TD><TD>'' + MIN(CASE [Status] & 512 WHEN 512 THEN ''True'' ELSE ''False'' END) + '' </TD></TR>'' +
				''<TR><TD><B>read only</B> </TD><TD>'' + MIN(CASE [Status] & 1024 WHEN 1024 THEN ''True'' ELSE ''False'' END) + '' </TD></TR>'' +
				''<TR><TD><B>dbo use only</B> </TD><TD>'' + min(CASE [Status] & 2048 WHEN 2048 THEN ''True'' ELSE ''False'' END) + '' </TD></TR>'' +
				''<TR><TD><B>single user</B> </TD><TD>'' + MIN(CASE [Status] & 4096 WHEN 4096 THEN ''True'' ELSE ''False'' END) + '' </TD></TR>'' +
				''<TR><TD><B>autoshrink</B> </TD><TD>'' + MIN(CASE [Status] & 4194304 WHEN 4194304 THEN ''True'' ELSE ''False'' END) + '' </TD></TR>'' +
				''<TR><TD><B>full text enabled</B> </TD><TD>'' + MIN(CASE status2 & 536870912 WHEN 536870912 THEN ''True'' ELSE ''False'' END) + '' </TD></TR>''
	FROM Master..SysDatabases
	WHERE [Name] = @DBName
	GROUP BY [Name]

	SELECT 	@StringHTML = @StringHTML + ''<TR><TD><B>'' +CONVERT(VARCHAR(128),[Name])+ ''</B> </TD><TD>'' +CONVERT(VARCHAR(255),[FileName])+ '' </TD></TR>'' 
	FROM 	Master.dbo.SysAltFiles 
	WHERE 	DBId = DB_Id(@DBName)
	ORDER BY [FileId]

	INSERT INTO master.dbo.HTML_code values(@StringHTML)
	SELECT @DBLastBackup = (SELECT CONVERT(SMALLDATETIME,MAX(Backup_Finish_Date)) FROM MSDB.dbo.BackupSet WHERE Type = ''d'' AND Database_Name = @DBName)

	INSERT INTO master.dbo.HTML_code values(''<TR><TD><B>Last Backup</B> </TD><TD>'' + ISNULL(CONVERT(VARCHAR(50),@DBLastBackup),''None'') + '' </TD></TR>'')

	SELECT @DBLastBackupDays = (SELECT DATEDIFF(d, MAX(Backup_Finish_Date), GETDATE()) FROM MSDB.dbo.BackupSet WHERE Type = ''d'' AND Database_Name = @DBName)
	IF ISNULL(@DBLastBackupDays,0)> 1 
		INSERT INTO master.dbo.HTML_code values(''<TR><TD BGCOLOR="#FF0000"><B>Days Since Last Backup</B> </TD><TD BGCOLOR="#FF0000">'' + ISNULL(CONVERT(VARCHAR(10),@DBLastBackupDays),''None'') + '' </TD></TR>'')
	ELSE 
		INSERT INTO master.dbo.HTML_code values(''<TR><TD><B>Days Since Last Backup</B> </TD><TD>'' + ISNULL(CONVERT(VARCHAR(10),@DBLastBackupDays),''None'') + '' </TD></TR>'')
	    INSERT INTO master.dbo.HTML_code values(''</TABLE><BR><A CLASS="Index" HREF="#_top" ALIGN="left">Back To Top ^</A><BR><BR>'')

	Fetch next from dblist into @DBName 
End
close dblist
deallocate dblist

-- Job list
INSERT INTO master.dbo.HTML_code values(''<DIV ALIGN="center"><TABLE BORDER="0" CELLPADDING="2" CELLSPACING="0" BORDERCOLOUR="003366" WIdTH="60%">'')
INSERT INTO master.dbo.HTML_code values(''<TR BGCOLOR="EEEEEE"><TD CLASS="Title" COLSPAN="2" ALIGN="center"><B><A NAME="_ListJobs">List of Jobs</A></B> </TD></TR>'')
INSERT INTO master.dbo.HTML_code values(''<TR BGCOLOR="EEEEEE"><TD ALIGN="left" WIdTH="70%"><B>Job Name</B> </TD><TD ALIGN="left" WIdTH="30%"><B>Status</B> </TD></TR>'')
Declare @JobName		Varchar(100), 
		@Status			Varchar(30)
DECLARE dblist cursor 
For
Select Name, Case when Enabled =1 then ''Enabled'' else ''Disabled'' end 
from msdb..sysjobs order by Name
Open dbList
Fetch next from dblist into @JobName, @Status
While @@fetch_status=0
Begin
	INSERT INTO master.dbo.HTML_code values(''<TR><TD><B>''+ @JobName + ''</B> </TD><TD>'' + @Status + '' </TD></TR>'')
	Fetch next from dblist into @JobName, @Status
End
close dblist
deallocate dblist
INSERT INTO master.dbo.HTML_code values(''</TABLE><BR><A CLASS="Index" HREF="#_top">Back To Top ^</A><BR><BR>'')
INSERT INTO master.dbo.HTML_code values(''<TR><TD VALIGN="top"><A CLASS="Index" HREF="#_DB_">Name</A> </TD><TD BGCOLOR="EEEEEE" COLSPAN="5">  </TD></TR>'')
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Create HTML Report]    Script Date: 09/27/2016 16:17:59 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Create HTML Report', 
		@step_id=5, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'CmdExec', 
		@command=@sqlcmd, 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Send failure email notification]    Script Date: 09/27/2016 16:18:00 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Send failure email notification', 
		@step_id=6, 
		@cmdexec_success_code=0, 
		@on_success_action=2, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @mailbody varchar(255)
set @mailbody = ''Backup System Database for DR job failed on: '' + @@servername

EXEC sp_send_dbmail  @profile_name = ''CSDBA-Alerts'' 
    , @recipients = ''CSDBA-Alerts@hcsc.com''
    , @subject =  ''Backup System Database for DR job failure''
    , @body =  @mailbody', 
		@database_name=N'msdb', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Run Every day at 8:30 PM', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20110531, 
		@active_end_date=99991231, 
		@active_start_time=203200, 
		@active_end_time=235959--, 
		--@schedule_uid=N'd6280680-cf20-4050-ad1b-e6cffa4fe11c'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO


