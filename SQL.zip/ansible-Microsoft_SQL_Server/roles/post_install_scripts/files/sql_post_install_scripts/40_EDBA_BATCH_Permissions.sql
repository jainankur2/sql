SET NOCOUNT ON

USE [master];
DECLARE @role varchar(50) = ''
IF EXISTS (select name from master.dbo.sa_logins where name like 'DEV%' AND LoginName = 'ENVIRONMENT')
  BEGIN
    SELECT @role = 'DEV_APP_RD'
  END
IF EXISTS (select name from master.dbo.sa_logins where name like 'TEST%' AND LoginName = 'ENVIRONMENT')
  BEGIN
    SELECT @role = 'TEST_APP_RD'
  END
IF EXISTS (select name from master.dbo.sa_logins where name like 'PROD%' AND LoginName = 'ENVIRONMENT')
  BEGIN
    SELECT @role = 'PROD_APP_RD'
  END

If not EXISTS (Select name from syslogins where name = 'EDBA_BATCH')
EXEC SP_ADDLOGIN 'EDBA_BATCH',  0x0100D9EF92269B82B5615681FB73EE069305D421C04E85EC7344, @encryptopt = 'skip_encryption';
USE [msdb];
CREATE USER [EDBA_BATCH] FOR LOGIN [EDBA_BATCH] WITH DEFAULT_SCHEMA= dbo
GRANT EXECUTE ON dbo.agent_datetime TO [EDBA_BATCH];

EXEC sp_addrolemember @rolename = @role, @membername = 'EDBA_BATCH';


