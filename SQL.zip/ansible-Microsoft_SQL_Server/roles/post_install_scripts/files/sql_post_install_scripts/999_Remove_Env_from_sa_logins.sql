if exists (select 1 from master.dbo.sa_logins where LoginName = 'Environment')
begin
delete from master.dbo.sa_logins where LoginName = 'Environment'
end