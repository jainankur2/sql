
USE [msdb]
GO

IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'APP_Imperva & mercuryprobe automation - PROD')
EXEC msdb.dbo.sp_delete_job @job_name='APP_Imperva & mercuryprobe automation - PROD', @delete_unused_schedule=1

/****** Object:  Job [APP_Imperva & mercuryprobe automation - PROD]    Script Date: 06/11/2009 17:37:59 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 06/11/2009 17:37:59 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'APP_Imperva & mercuryprobe automation - PROD', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'Weekly job to ensure APP_Imperva & mercuryprobe logins/users/roles exist for each database', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [APP_Imperva & mercuryprobe setup]    Script Date: 06/11/2009 17:38:00 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'APP_Imperva & mercuryprobe setup', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=4, 
		@on_fail_step_id=2, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @sql1 varchar(5000)
declare @sql2 varchar(5000)

if not exists(select name from sys.sql_logins where name = ''APP_Imperva'')
begin

 set @sql1 = ''USE [master]
    CREATE LOGIN [APP_Imperva] WITH PASSWORD = 0x0100476B06331E1058E2C3AB14BF3ABE630C51253A9F79A6A4C3 HASHED, DEFAULT_DATABASE = [master], CHECK_POLICY = ON, CHECK_EXPIRATION = OFF;
    grant VIEW ANY DEFINITION to APP_Imperva;''
  exec(@sql1)
end
else
begin
    set @sql1 = ''USE [master]
    grant VIEW ANY DEFINITION to APP_Imperva;''
  exec(@sql1)
end

if not exists(select name from sys.sql_logins where name = ''mercuryprobe'')
begin
   set @sql1 = ''USE [master]
    CREATE LOGIN [mercuryprobe] WITH PASSWORD = 0x010065776D679FBC8BCFA62AE0CD3B83F2DF16D9DD0999FF8B00 HASHED, DEFAULT_DATABASE = [master], CHECK_POLICY = ON, CHECK_EXPIRATION = OFF
    grant VIEW ANY DEFINITION to mercuryprobe;''
  exec(@sql1)
end
else
begin
    set @sql1 = ''USE [master]
    grant VIEW ANY DEFINITION to mercuryprobe;''
  exec(@sql1)
end



declare @dbname sysname
declare @sql3 varchar(5000)
declare @sql4 varchar(5000)

declare db_cursor cursor for
  select name from master.sys.sysdatabases
    where DATABASEPROPERTYEX(name, ''STATUS'') = ''ONLINE'' 
    and DATABASEPROPERTYEX(name, ''Updateability'') = ''READ_WRITE''
  order by name
for read only			


open db_cursor
fetch db_cursor into @dbname
while (@@fetch_status = 0)
  begin
		    
	
	set @sql3 = ''use ['' + @dbname + '']
                if not exists (select name from ['' + @dbname + ''].sys.database_principals where type = ''''R'''' and name = ''''PROD_Imperva_SelSysTbls'''')  
				begin

					CREATE ROLE PROD_Imperva_SelSysTbls AUTHORIZATION [dbo];

					if ''''[''+ @dbname +'']'''' = ''''master''''
						begin
							GRANT SELECT ON sys.syslogins TO PROD_Imperva_SelSysTbls;
						end

					GRANT SELECT ON sys.sysusers TO PROD_Imperva_SelSysTbls;
       		        GRANT SELECT ON sys.objects TO PROD_Imperva_SelSysTbls;					
				end
			else
				begin
					if ''''[''+ @dbname +'']'''' = ''''master''''
						begin					
							GRANT SELECT ON sys.syslogins TO PROD_Imperva_SelSysTbls;
						end

					GRANT SELECT ON sys.sysusers TO PROD_Imperva_SelSysTbls;
   					GRANT SELECT ON sys.objects TO PROD_Imperva_SelSysTbls;					
					
				end

			if not exists(select name from ['' + @dbname + ''].sys.database_principals where type = ''''S'''' and name = ''''APP_Imperva'''')  
				begin
					CREATE USER  APP_Imperva FOR LOGIN APP_Imperva WITH DEFAULT_SCHEMA = dbo;
					exec sp_addrolemember @rolename = ''''PROD_Imperva_SelSysTbls'''', @membername = ''''APP_Imperva'''' 		
				end 
			else
				begin
					exec sp_addrolemember @rolename = ''''PROD_Imperva_SelSysTbls'''', @membername = ''''APP_Imperva'''' 
				end
                exec sp_change_users_login ''''Update_One'''', ''''APP_Imperva'''', ''''APP_Imperva''''''
    exec (@sql3)

    if (@dbname <> ''SSISConfigDB'')
    begin
        set @sql4 = ''use ['' + @dbname + '']
                if not exists (select name from ['' + @dbname + ''].sys.database_principals where type = ''''R'''' and name = ''''PROD_APP_RD'''')  
				begin

					CREATE ROLE PROD_APP_RD AUTHORIZATION [dbo];

					exec sp_addrolemember @rolename = [db_datareader], @membername = [PROD_APP_RD]
				end
            else
                begin
					exec sp_addrolemember @rolename = [db_datareader], @membername = [PROD_APP_RD]
                end 

			if not exists(select name from ['' + @dbname + ''].sys.database_principals where type = ''''S'''' and name = ''''mercuryprobe'''')  
				begin
					CREATE USER  mercuryprobe FOR LOGIN mercuryprobe WITH DEFAULT_SCHEMA = dbo;
					exec sp_addrolemember @rolename = ''''PROD_APP_RD'''', @membername = ''''mercuryprobe'''' 		
				end 
			else
				begin
					exec sp_addrolemember @rolename = ''''PROD_APP_RD'''', @membername = ''''mercuryprobe'''' 
				end
                exec sp_change_users_login ''''Update_One'''', ''''mercuryprobe'''', ''''mercuryprobe''''''
    exec (@sql4)
    end

    fetch db_cursor into @dbname
  end
close db_cursor
deallocate db_cursor
', 
		@database_name=N'master', 
		@output_file_name=N'D:\EDBA\Output\APP_Imperva & mercuryprobe automation.log', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Email DBAs on Failure]    Script Date: 06/11/2009 17:38:00 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Email DBAs on Failure', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=2, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @mailbody varchar(255)
set @mailbody = ''APP_Imperva & mercuryprobe automation:  '' + @@servername

EXEC sp_send_dbmail  @profile_name = ''CSDBA-Alerts'' 
    , @recipients = ''CSDBA-Alerts@hcsc''
    , @subject =  ''APP_Imperva & mercuryprobe automation job failure''
    , @body =  @mailbody', 
		@database_name=N'msdb', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Sunday Schedule', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20090611, 
		@active_end_date=99991231, 
		@active_start_time=150000, 
		@active_end_time=235959
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

USE [msdb]
GO
/****** Object:  Job [APP_Imperva & mercuryprobe automation - WTC]    Script Date: 06/30/2009 11:37:12 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0

IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'APP_Imperva & mercuryprobe automation - WTC')
EXEC msdb.dbo.sp_delete_job @job_name=N'APP_Imperva & mercuryprobe automation - WTC', @delete_unused_schedule=1

/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 06/30/2009 11:37:12 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'APP_Imperva & mercuryprobe automation - WTC', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'Weekly job to ensure APP_Imperva & mercuryprobe logins/users/roles exist for each database', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [APP_Imperva & mercuryprobe setup]    Script Date: 06/30/2009 11:37:13 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'APP_Imperva & mercuryprobe setup', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=4, 
		@on_fail_step_id=2, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @sql1 varchar(5000)
declare @sql2 varchar(5000)

if not exists(select name from sys.sql_logins where name = ''APP_Imperva'')
begin

 set @sql1 = ''USE [master]
    CREATE LOGIN [APP_Imperva] WITH PASSWORD = 0x0100476B06331E1058E2C3AB14BF3ABE630C51253A9F79A6A4C3 HASHED, DEFAULT_DATABASE = [master], CHECK_POLICY = ON, CHECK_EXPIRATION = OFF;
    grant VIEW ANY DEFINITION to APP_Imperva;''
  exec(@sql1)
end
else
begin
    set @sql1 = ''USE [master]
    grant VIEW ANY DEFINITION to APP_Imperva;''
  exec(@sql1)
end

if not exists(select name from sys.sql_logins where name = ''mercuryprobe'')
begin
   set @sql1 = ''USE [master]
    CREATE LOGIN [mercuryprobe] WITH PASSWORD = 0x010065776D679FBC8BCFA62AE0CD3B83F2DF16D9DD0999FF8B00 HASHED, DEFAULT_DATABASE = [master], CHECK_POLICY = ON, CHECK_EXPIRATION = OFF
    grant VIEW ANY DEFINITION to mercuryprobe;''
  exec(@sql1)
end
else
begin
    set @sql1 = ''USE [master]
    grant VIEW ANY DEFINITION to mercuryprobe;''
  exec(@sql1)
end



declare @dbname sysname
declare @sql3 varchar(5000)
declare @sql4 varchar(5000)

declare db_cursor cursor for
  select name from master.sys.sysdatabases
    where DATABASEPROPERTYEX(name, ''STATUS'') = ''ONLINE'' 
    and DATABASEPROPERTYEX(name, ''Updateability'') = ''READ_WRITE''
  order by name
for read only			


open db_cursor
fetch db_cursor into @dbname
while (@@fetch_status = 0)
  begin
		    
	
	set @sql3 = ''use ['' + @dbname + '']
                if exists (select name from ['' + @dbname + ''].sys.database_principals where type = ''''R'''' and name = ''''PROD_Imperva_SelSysTbls'''') 
                                                                begin
                       if exists(select name from ['' + @dbname + ''].sys.database_principals where type = ''''S'''' and name = ''''APP_Imperva'''')  
                                                                               begin
                                       if exists (select name from ['' + @dbname + ''].sys.schemas where name = N''''APP_Imperva'''')
                                                                                  begin
	                         				DROP SCHEMA [APP_Imperva]
                                                                                  end


                                       if exists (select name from ['' + @dbname + ''].sys.schemas where name = N''''PROD_Imperva_SelSysTbls'''')
                                                                                  begin
	                         				DROP SCHEMA [PROD_Imperva_SelSysTbls]
                                                                                  end

                                                                                     DROP USER APP_Imperva
                                                                               end

                                                                                DROP ROLE PROD_Imperva_SelSysTbls;
                                                                end 
                if not exists (select name from ['' + @dbname + ''].sys.database_principals where type = ''''R'''' and name = ''''TEST_Imperva_SelSysTbls'''')  
				begin

					CREATE ROLE TEST_Imperva_SelSysTbls AUTHORIZATION [dbo];

					if ''''[''+ @dbname +'']'''' = ''''master''''
						begin
							GRANT SELECT ON sys.syslogins TO TEST_Imperva_SelSysTbls;
						end

					GRANT SELECT ON sys.sysusers TO TEST_Imperva_SelSysTbls;
       		        GRANT SELECT ON sys.objects TO TEST_Imperva_SelSysTbls;					
				end
			else
				begin
					if ''''[''+ @dbname +'']'''' = ''''master''''
						begin					
							GRANT SELECT ON sys.syslogins TO TEST_Imperva_SelSysTbls;
						end

					GRANT SELECT ON sys.sysusers TO TEST_Imperva_SelSysTbls;
   					GRANT SELECT ON sys.objects TO TEST_Imperva_SelSysTbls;					
					
				end

			if not exists(select name from ['' + @dbname + ''].sys.database_principals where type = ''''S'''' and name = ''''APP_Imperva'''')  
				begin
					CREATE USER  APP_Imperva FOR LOGIN APP_Imperva WITH DEFAULT_SCHEMA = dbo;
					exec sp_addrolemember @rolename = ''''TEST_Imperva_SelSysTbls'''', @membername = ''''APP_Imperva'''' 		
				end 
			else
				begin
					exec sp_addrolemember @rolename = ''''TEST_Imperva_SelSysTbls'''', @membername = ''''APP_Imperva'''' 
				end
                exec sp_change_users_login ''''Update_One'''', ''''APP_Imperva'''', ''''APP_Imperva''''''
    exec (@sql3)

    if (@dbname <> ''SSISConfigDB'')
    begin
      set @sql4 = ''use ['' + @dbname + '']
                if not exists (select name from ['' + @dbname + ''].sys.database_principals where type = ''''R'''' and name = ''''TEST_APP_RD'''')  
				begin

					CREATE ROLE TEST_APP_RD AUTHORIZATION [dbo];

					exec sp_addrolemember @rolename = [db_datareader], @membername = [TEST_APP_RD]
				end
            else
                begin
					exec sp_addrolemember @rolename = [db_datareader], @membername = [TEST_APP_RD]
                end 

			if not exists(select name from ['' + @dbname + ''].sys.database_principals where type = ''''S'''' and name = ''''mercuryprobe'''')  
				begin
					CREATE USER  mercuryprobe FOR LOGIN mercuryprobe WITH DEFAULT_SCHEMA = dbo;
					exec sp_addrolemember @rolename = ''''TEST_APP_RD'''', @membername = ''''mercuryprobe'''' 		
				end 
			else
				begin
					exec sp_addrolemember @rolename = ''''TEST_APP_RD'''', @membername = ''''mercuryprobe'''' 
				end
                exec sp_change_users_login ''''Update_One'''', ''''mercuryprobe'''', ''''mercuryprobe''''''
    exec (@sql4)
   end

    fetch db_cursor into @dbname
  end
close db_cursor
deallocate db_cursor
', 
		@database_name=N'master', 
		@output_file_name=N'D:\EDBA\Output\APP_Imperva & mercuryprobe automation.log', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Email DBAs on Failure]    Script Date: 06/30/2009 11:37:13 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Email DBAs on Failure', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=2, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @mailbody varchar(255)
set @mailbody = ''APP_Imperva & mercuryprobe automation:  '' + @@servername

EXEC sp_send_dbmail  @profile_name = ''CSDBA-Alerts'' 
    , @recipients = ''CSDBA-Alerts@hcsc''
    , @subject =  ''APP_Imperva & mercuryprobe automation job failure''
    , @body =  @mailbody', 
		@database_name=N'msdb', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Sunday Schedule', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20090611, 
		@active_end_date=99991231, 
		@active_start_time=150000, 
		@active_end_time=235959
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

USE [msdb]
GO
/****** Object:  Job [APP_Imperva & mercuryprobe automation - DEV]    Script Date: 07/27/2009 11:50:21 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0

IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'APP_Imperva & mercuryprobe automation - DEV')
EXEC msdb.dbo.sp_delete_job @job_name=N'APP_Imperva & mercuryprobe automation - DEV', @delete_unused_schedule=1

/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 07/27/2009 11:50:21 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'APP_Imperva & mercuryprobe automation - DEV', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'Weekly job to ensure APP_Imperva & mercuryprobe logins/users/roles exist for each database', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [APP_Imperva & mercuryprobe setup]    Script Date: 07/27/2009 11:50:22 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'APP_Imperva & mercuryprobe setup', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=4, 
		@on_fail_step_id=2, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @sql1 varchar(5000)
declare @sql2 varchar(5000)

if not exists(select name from sys.sql_logins where name = ''APP_Imperva'')
begin

 set @sql1 = ''USE [master]
    CREATE LOGIN [APP_Imperva] WITH PASSWORD = 0x0100476B06331E1058E2C3AB14BF3ABE630C51253A9F79A6A4C3 HASHED, DEFAULT_DATABASE = [master], CHECK_POLICY = ON, CHECK_EXPIRATION = OFF;
    grant VIEW ANY DEFINITION to APP_Imperva;''
  exec(@sql1)
end
else
begin
    set @sql1 = ''USE [master]
    grant VIEW ANY DEFINITION to APP_Imperva;''
  exec(@sql1)
end

if not exists(select name from sys.sql_logins where name = ''mercuryprobe'')
begin
   set @sql1 = ''USE [master]
    CREATE LOGIN [mercuryprobe] WITH PASSWORD = 0x010065776D679FBC8BCFA62AE0CD3B83F2DF16D9DD0999FF8B00 HASHED, DEFAULT_DATABASE = [master], CHECK_POLICY = ON, CHECK_EXPIRATION = OFF
    grant VIEW ANY DEFINITION to mercuryprobe;''
  exec(@sql1)
end
else
begin
    set @sql1 = ''USE [master]
    grant VIEW ANY DEFINITION to mercuryprobe;''
  exec(@sql1)
end



declare @dbname sysname
declare @sql3 varchar(5000)
declare @sql4 varchar(5000)

declare db_cursor cursor for
  select name from master.sys.sysdatabases
    where DATABASEPROPERTYEX(name, ''STATUS'') = ''ONLINE'' 
    and DATABASEPROPERTYEX(name, ''Updateability'') = ''READ_WRITE''
  order by name
for read only			


open db_cursor
fetch db_cursor into @dbname
while (@@fetch_status = 0)
  begin
		    
	
	set @sql3 = ''use ['' + @dbname + '']
                if exists (select name from ['' + @dbname + ''].sys.database_principals where type = ''''R'''' and name = ''''PROD_Imperva_SelSysTbls'''') 
                                                                begin
                       if exists(select name from ['' + @dbname + ''].sys.database_principals where type = ''''S'''' and name = ''''APP_Imperva'''')  
                                                                               begin
                                       if exists (select name from ['' + @dbname + ''].sys.schemas where name = N''''APP_Imperva'''')
                                                                                  begin
	                         				DROP SCHEMA [APP_Imperva]
                                                                                  end

                                       if exists (select name from ['' + @dbname + ''].sys.schemas where name = N''''PROD_Imperva_SelSysTbls'''')
                                                                                  begin
	                         				DROP SCHEMA [PROD_Imperva_SelSysTbls]
                                                                                  end

                                                                                     DROP USER APP_Imperva
                                                                               end

                                                                                DROP ROLE PROD_Imperva_SelSysTbls;
                                                                end 
                if not exists (select name from ['' + @dbname + ''].sys.database_principals where type = ''''R'''' and name = ''''DEV_Imperva_SelSysTbls'''')  
				begin

					CREATE ROLE DEV_Imperva_SelSysTbls AUTHORIZATION [dbo];

					if ''''[''+ @dbname +'']'''' = ''''master''''
						begin
							GRANT SELECT ON sys.syslogins TO DEV_Imperva_SelSysTbls;
						end

					GRANT SELECT ON sys.sysusers TO DEV_Imperva_SelSysTbls;
       		        GRANT SELECT ON sys.objects TO DEV_Imperva_SelSysTbls;					
				end
			else
				begin
					if ''''[''+ @dbname +'']'''' = ''''master''''
						begin					
							GRANT SELECT ON sys.syslogins TO DEV_Imperva_SelSysTbls;
						end

					GRANT SELECT ON sys.sysusers TO DEV_Imperva_SelSysTbls;
   					GRANT SELECT ON sys.objects TO DEV_Imperva_SelSysTbls;					
					
				end

			if not exists(select name from ['' + @dbname + ''].sys.database_principals where type = ''''S'''' and name = ''''APP_Imperva'''')  
				begin
					CREATE USER  APP_Imperva FOR LOGIN APP_Imperva WITH DEFAULT_SCHEMA = dbo;
					exec sp_addrolemember @rolename = ''''DEV_Imperva_SelSysTbls'''', @membername = ''''APP_Imperva'''' 		
				end 
			else
				begin
					exec sp_addrolemember @rolename = ''''DEV_Imperva_SelSysTbls'''', @membername = ''''APP_Imperva'''' 
				end
                exec sp_change_users_login ''''Update_One'''', ''''APP_Imperva'''', ''''APP_Imperva''''''
    exec (@sql3)

    if (@dbname <> ''SSISConfigDB'')
    begin
	set @sql4 = ''use ['' + @dbname + '']

                if exists (select name from ['' + @dbname + ''].sys.database_principals where type = ''''R'''' and name = ''''DEV_APP_RD'''') 
                                                                begin
                       if exists(select name from ['' + @dbname + ''].sys.database_principals where type = ''''S'''' and name = ''''mercuryprobe'''')  
                                                                               begin
                                       if exists (select name from ['' + @dbname + ''].sys.schemas where name = N''''mercuryprobe'''')
                                                                                  begin
	                         				DROP SCHEMA [mercuryprobe]
                                                                                  end

                                                                                     DROP USER mercuryprobe
                                                                               end

                                                                --                DROP ROLE DEV_APP_RD;
                                                                end 

                if not exists (select name from ['' + @dbname + ''].sys.database_principals where type = ''''R'''' and name = ''''DEV_APP_RD'''')  
				begin

					CREATE ROLE DEV_APP_RD AUTHORIZATION [dbo];

					exec sp_addrolemember @rolename = [db_datareader], @membername = [DEV_APP_RD]
				end
            else
                begin
					exec sp_addrolemember @rolename = [db_datareader], @membername = [DEV_APP_RD]
                end 

			if not exists(select name from ['' + @dbname + ''].sys.database_principals where type = ''''S'''' and name = ''''mercuryprobe'''')  
				begin
					CREATE USER  mercuryprobe FOR LOGIN mercuryprobe WITH DEFAULT_SCHEMA = dbo;
					exec sp_addrolemember @rolename = ''''DEV_APP_RD'''', @membername = ''''mercuryprobe'''' 		
				end 
			else
				begin
					exec sp_addrolemember @rolename = ''''DEV_APP_RD'''', @membername = ''''mercuryprobe'''' 
				end
                exec sp_change_users_login ''''Update_One'''', ''''mercuryprobe'''', ''''mercuryprobe''''''
    exec (@sql4)
  end

    fetch db_cursor into @dbname
  end
close db_cursor
deallocate db_cursor
', 
		@database_name=N'master', 
		@output_file_name=N'D:\EDBA\Output\APP_Imperva & mercuryprobe automation.log', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Email DBAs on Failure]    Script Date: 07/27/2009 11:50:22 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Email DBAs on Failure', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=2, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @mailbody varchar(255)
set @mailbody = ''APP_Imperva & mercuryprobe automation:  '' + @@servername

EXEC sp_send_dbmail  @profile_name = ''CSDBA-Alerts'' 
    , @recipients = ''CSDBA-Alerts@hcsc''
    , @subject =  ''APP_Imperva & mercuryprobe automation job failure''
    , @body =  @mailbody', 
		@database_name=N'msdb', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Sunday Schedule', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20090611, 
		@active_end_date=99991231, 
		@active_start_time=150000, 
		@active_end_time=235959
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO


use master

set nocount on
declare @domain char(9)


set @domain = default_domain()

if @domain = 'ADHCSCDEV'
BEGIN

IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'APP_Imperva & mercuryprobe automation - PROD')
EXEC msdb.dbo.sp_delete_job @job_name='APP_Imperva & mercuryprobe automation - PROD', @delete_unused_schedule=1

IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'APP_Imperva & mercuryprobe automation - WTC')
EXEC msdb.dbo.sp_delete_job @job_name=N'APP_Imperva & mercuryprobe automation - WTC', @delete_unused_schedule=1

exec msdb.dbo.sp_start_job @job_name = 'APP_Imperva & mercuryprobe automation - DEV'

END

if @domain = 'ADHCSCTST'
BEGIN

IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'APP_Imperva & mercuryprobe automation - PROD')
EXEC msdb.dbo.sp_delete_job @job_name='APP_Imperva & mercuryprobe automation - PROD', @delete_unused_schedule=1

IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'APP_Imperva & mercuryprobe automation - DEV')
EXEC msdb.dbo.sp_delete_job @job_name=N'APP_Imperva & mercuryprobe automation - DEV', @delete_unused_schedule=1

exec msdb.dbo.sp_start_job @job_name = 'APP_Imperva & mercuryprobe automation - WTC'

END

if @domain = 'ADHCSCINT'
BEGIN

IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'APP_Imperva & mercuryprobe automation - WTC')
EXEC msdb.dbo.sp_delete_job @job_name=N'APP_Imperva & mercuryprobe automation - WTC', @delete_unused_schedule=1

IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'APP_Imperva & mercuryprobe automation - DEV')
EXEC msdb.dbo.sp_delete_job @job_name=N'APP_Imperva & mercuryprobe automation - DEV', @delete_unused_schedule=1

exec msdb.dbo.sp_start_job @job_name = 'APP_Imperva & mercuryprobe automation - PROD'


END
