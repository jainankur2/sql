declare @directory table (dirname varchar(1000))

insert into @directory
Exec xp_cmdshell 'DIR D:\EDBA\*.*'

If (Select count(*) from @directory)=2
Begin
       Exec xp_cmdshell 'MKDIR D:\EDBA\Alerts'
       Exec xp_cmdshell 'MKDIR D:\EDBA\Cmd'
       Exec xp_cmdshell 'MKDIR D:\EDBA\Err'
       Exec xp_cmdshell 'MKDIR D:\EDBA\Files'
       Exec xp_cmdshell 'MKDIR D:\EDBA\Misc'
       Exec xp_cmdshell 'MKDIR D:\EDBA\Output'
       Exec xp_cmdshell 'MKDIR D:\EDBA\Scripts'
       Print 'EDBA directories created'
End
