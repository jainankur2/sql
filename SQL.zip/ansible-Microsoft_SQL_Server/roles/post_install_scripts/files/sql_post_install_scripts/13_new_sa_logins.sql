USE [msdb]
GO
/****** Object:  Job [Warning - New sa logins]    Script Date: 03/04/2010 09:36:35 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 03/04/2010 09:36:35 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Warning - New sa logins', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Send email]    Script Date: 03/04/2010 09:36:36 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Send email', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=1, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @LoginName varchar(30), @LoginList varchar(1000)
declare @EmailFrom varchar(25), @subject varchar(100),@EmailBody varchar(2000) , @emailpath varchar(200),@EmailTo varchar(50)

declare sa_logins CURSOR FOR

select sl.name
FROM syslogins sl
LEFT JOIN sa_logins sal ON sl.name = sal.LoginName
WHERE sal.LoginName IS NULL
AND sl.name <> ''sa''
AND RIGHT(sl.name, 7) <> ''dbadmin''
AND RIGHT(sl.name, 22) <> ''MSSQL_ADHCSCINT_Admins''
AND RIGHT(sl.name, 31) <> ''MSSQL_ADHCSCINT_OffShore_Admins''
AND RIGHT(sl.name, 30) <> ''MSSQL_ADHCSCINT_OnShore_Admins''
AND RIGHT(sl.name, 22) <> ''MSSQL_ADHCSCTST_Admins''
AND RIGHT(sl.name, 31) <> ''MSSQL_ADHCSCTST_OffShore_Admins''
AND RIGHT(sl.name, 30) <> ''MSSQL_ADHCSCTST_OnShore_Admins''
AND RIGHT(sl.name, 22) <> ''MSSQL_ADHCSCDEV_Admins''
AND RIGHT(sl.name, 31) <> ''MSSQL_ADHCSCDEV_OffShore_Admins''
AND RIGHT(sl.name, 30) <> ''MSSQL_ADHCSCDEV_OnShore_Admins''
AND sl.sysadmin = 1

OPEN sa_logins

fetch NEXT FROM sa_logins INTO @LoginName

WHILE @@fetch_status = 0
begin
	
	IF @LoginList IS NULL
	begin
		SET @LoginList = @LoginName
	END
	ELSE
	begin
		SET @LoginList = @LoginList + '', '' + @LoginName
	END

	fetch NEXT FROM sa_logins INTO @LoginName

END

CLOSE sa_logins
DEALLOCATE sa_logins

IF @LoginList IS NOT NULL
begin

	Set @EmailFrom= ''NewsaLogin@BCBS.COM''
	Set @EmailTo =  ''CSDBA-Alerts.hcsc''
	set @subject =  ''Warning - '' + @@servername + '' have user(s) with improper sa permissions''
	Set @EmailBody = @LoginList + '' user(s), which have sa access, should not.''

  	exec  msdb.dbo.sp_send_dbmail  @profile_name =''CSDBA-Warnings'',@recipients=@EmailTo, @subject= @subject,@body=@EmailBody
END', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Daily', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20060914, 
		@active_end_date=99991231, 
		@active_start_time=80000, 
		@active_end_time=235959
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
