USE [msdb]
GO

/****** Object:  Job [sp_purge_jobhistory]    Script Date: 5/17/2017 2:12:41 PM ******/
EXEC msdb.dbo.sp_delete_job @job_name=N'sp_purge_jobhistory', @delete_unused_schedule=1
GO

/****** Object:  Job [sp_delete_backuphistory]    Script Date: 5/17/2017 2:12:41 PM ******/
EXEC msdb.dbo.sp_delete_job @job_name=N'sp_delete_backuphistory', @delete_unused_schedule=1
GO

/****** Object:  Job [Output File Cleanup]    Script Date: 5/17/2017 2:12:41 PM ******/
EXEC msdb.dbo.sp_delete_job @job_name=N'Output File Cleanup', @delete_unused_schedule=1
GO

/****** Object:  Job [IndexOptimize - USER_DATABASES]    Script Date: 5/17/2017 2:12:41 PM ******/
EXEC msdb.dbo.sp_delete_job @job_name=N'IndexOptimize - USER_DATABASES', @delete_unused_schedule=1
GO

/****** Object:  Job [DatabaseIntegrityCheck - USER_DATABASES]    Script Date: 5/17/2017 2:12:41 PM ******/
EXEC msdb.dbo.sp_delete_job @job_name=N'DatabaseIntegrityCheck - USER_DATABASES', @delete_unused_schedule=1
GO

/****** Object:  Job [DatabaseIntegrityCheck - SYSTEM_DATABASES]    Script Date: 5/17/2017 2:12:41 PM ******/
EXEC msdb.dbo.sp_delete_job @job_name=N'DatabaseIntegrityCheck - SYSTEM_DATABASES', @delete_unused_schedule=1
GO

/****** Object:  Job [DatabaseBackup - USER_DATABASES - LOG]    Script Date: 5/17/2017 2:12:41 PM ******/
EXEC msdb.dbo.sp_delete_job @job_name=N'DatabaseBackup - USER_DATABASES - LOG', @delete_unused_schedule=1
GO

/****** Object:  Job [DatabaseBackup - USER_DATABASES - FULL]    Script Date: 5/17/2017 2:12:41 PM ******/
EXEC msdb.dbo.sp_delete_job @job_name=N'DatabaseBackup - USER_DATABASES - FULL', @delete_unused_schedule=1
GO

/****** Object:  Job [DatabaseBackup - USER_DATABASES - DIFF]    Script Date: 5/17/2017 2:12:41 PM ******/
EXEC msdb.dbo.sp_delete_job @job_name=N'DatabaseBackup - USER_DATABASES - DIFF', @delete_unused_schedule=1
GO

/****** Object:  Job [DatabaseBackup - SYSTEM_DATABASES - FULL]    Script Date: 5/17/2017 2:12:41 PM ******/
EXEC msdb.dbo.sp_delete_job @job_name=N'DatabaseBackup - SYSTEM_DATABASES - FULL', @delete_unused_schedule=1
GO

/****** Object:  Job [CommandLog Cleanup]    Script Date: 5/17/2017 2:12:41 PM ******/
EXEC msdb.dbo.sp_delete_job @job_name=N'CommandLog Cleanup', @delete_unused_schedule=1
GO


