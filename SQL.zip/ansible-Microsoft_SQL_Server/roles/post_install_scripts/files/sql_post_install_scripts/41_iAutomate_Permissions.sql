SET NOCOUNT ON

USE [master];



IF (SUSER_ID('A6668004') IS NULL) 
BEGIN 
	CREATE LOGIN [A6668004] WITH PASSWORD = 0x01006BCB3E89C9E5D9C282988976FFBA3FDBA6C866D587BBB7BD HASHED, CHECK_EXPIRATION = OFF, CHECK_POLICY = ON, DEFAULT_DATABASE=[master], DEFAULT_LANGUAGE=[us_english] 
END;
USE [msdb]
GO

CREATE USER [iAutomate] FOR LOGIN [A6668004]
GO
USE [msdb]
GO
EXEC sp_addrolemember N'db_datareader', N'iAutomate'
GO
USE [msdb]
GO
EXEC sp_addrolemember N'SQLAgentOperatorRole', N'iAutomate'
GO
USE [msdb]
GO
EXEC sp_addrolemember N'SQLAgentReaderRole', N'iAutomate'
GO
USE [msdb]
GO
EXEC sp_addrolemember N'SQLAgentUserRole', N'iAutomate'
GO


/*DECLARE @SQL varchar(max)
DECLARE @role varchar(50) = ''
IF EXISTS (select name from master.dbo.sa_logins where name like 'DEV%' AND LoginName = 'ENVIRONMENT')
  BEGIN
    SELECT @role = 'DEV_APP_RD'
  END
IF EXISTS (select name from master.dbo.sa_logins where name like 'TEST%' AND LoginName = 'ENVIRONMENT')
  BEGIN
    SELECT @role = 'TEST_APP_RD'
  END
IF EXISTS (select name from master.dbo.sa_logins where name like 'PROD%' AND LoginName = 'ENVIRONMENT')
  BEGIN
    SELECT @role = 'PROD_APP_RD'
  END

If NOT EXISTS (Select name from syslogins where name = 'A6668004')
BEGIN
  
CREATE LOGIN [A6668004] WITH PASSWORD=N'q/DP5bJFPArCq426/km0Lcx8Sd9hBgzjix4KYaoNdmA=', DEFAULT_DATABASE=[master], DEFAULT_LANGUAGE=[us_english], CHECK_EXPIRATION=OFF, CHECK_POLICY=ON;

END

SELECT @SQL = '
USE msdb;
IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name =  ''iAutomate'')
CREATE USER [iAutomate]   FOR  LOGIN [a6668004]  WITH DEFAULT_SCHEMA = dbo;
EXEC sp_addrolemember @rolename = ''SQLAgentOperatorRole'', @membername = ''iAutomate'';
EXEC sp_addrolemember @rolename = ''' + @role + ''', @membername = ''iAutomate'';'

EXEC(@SQL)
*/