USE master ;

set nocount on
declare @domain char(9)


set @domain = default_domain()


ALTER DATABASE model SET RECOVERY SIMPLE ;

IF @domain = 'ADHCSCINT'
BEGIN
ALTER DATABASE model SET RECOVERY FULL 
END