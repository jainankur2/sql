USE [msdb]
GO

/****** Object:  Job [Alert - Backups not run in 24hrs]    Script Date: 2/22/2017 2:38:39 PM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 2/22/2017 2:38:39 PM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Alert - Backups not run in 24hrs', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'This job checks to see that a backup has completed within the last 24 hours.', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Check for backups]    Script Date: 2/22/2017 2:38:39 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Check for backups', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @maximum_finish_date datetime
declare @maximum_start_date  datetime
declare @counter int
declare @dbname3 char(128)
declare @numbackups int

Create Table #Backup_tbl
 (COL1 varchar(200) not null)

declare db_cursor cursor for
  select name from master.sys.sysdatabases
  where name NOT IN (''tempdb'',''DN_DataStore_LS_Recipient'') 
    and DATABASEPROPERTY(name, ''IsOffline'') = 0 
    and DATABASEPROPERTY(name, ''IsSuspect'') = 0
    and DATABASEPROPERTY(name, ''IsReadOnly'') = 0   
  order by name
for read only

open db_cursor
fetch db_cursor into @dbname3
while (@@fetch_status = 0)
  begin


select @maximum_finish_date = max(backup_finish_date) from msdb..backupset
 where type in (''d'',''i'')
    and database_name = @dbname3

select @maximum_start_date = max(backup_start_date) from msdb..backupset
 where type in (''d'',''i'')
    and database_name = @dbname3

insert into #Backup_tbl (COL1)
select ''Database Name = '' + @dbname3 + ''     Last Backup Start Date = '' + cast(@maximum_start_date as varchar) from msdb..backupset
 where @maximum_finish_date < dateadd (hh, -24, getdate())
   and database_name = @dbname3


select @numbackups = count(*) from msdb..backupset
 where database_name = @dbname3
   and type in (''D'',''I'',''L'',''F'')


if @numbackups = 0
   begin 
      insert into #Backup_tbl (COL1)
      select ''Database Name = '' + @dbname3 + ''     HAS NO BACKUPS ''
   end

fetch db_cursor into @dbname3
  end
close db_cursor
deallocate db_cursor


select @counter = count(*) from #Backup_tbl

if @counter > 0
begin
declare @EmailFrom varchar(25), 
 @subject varchar(100),
 @EmailBody varchar(4000) , 
 @EmailTo varchar(50),
        @column varchar(2000)
set @EmailBody = ''''

declare column_cursor scroll cursor for
  select col1 from #Backup_tbl
  group by col1
  order by col1

open column_cursor
fetch first from column_cursor into @column
while (@@fetch_status = 0)
  begin
  select @EmailBody = @EmailBody + char(13) + @column
fetch next from  column_cursor into @column
  end
close column_cursor
deallocate column_cursor

declare @subjectbody varchar(255)
set @subjectbody = ''Alert - Backup job(s) have not run in last 24 hours on '' + @@servername
EXEC sp_send_dbmail  @profile_name = ''CSDBA-Alerts'' 
    , @recipients = ''CSDBA-Alerts@hcsc.com''
    , @subject =  @subjectbody
    , @body =  @EmailBody


 
end

drop table #Backup_tbl', 
		@database_name=N'msdb', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Backup Report Schedule', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20080605, 
		@active_end_date=99991231, 
		@active_start_time=80000, 
		@active_end_time=235959
		IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

