use [master]
go

declare @domain char(9)

set @domain = default_domain()

if not exists (select name from sys.syslogins where name = 'NT AUTHORITY\SYSTEM')
CREATE LOGIN [NT AUTHORITY\SYSTEM] FROM WINDOWS WITH DEFAULT_DATABASE=[master], DEFAULT_LANGUAGE=[us_english]
GO
sp_addsrvrolemember [NT AUTHORITY\SYSTEM],'sysadmin'
go

declare @sql varchar(2000)
select @sql = 'INSERT INTO [master].[dbo].[sa_logins] ([LoginName],[Name]) VALUES (''NT AUTHORITY\SYSTEM'',''NT AUTHORITY\SYSTEM'');'
exec (@sql)
select @sql = 'INSERT INTO [master].[dbo].[sa_logins] ([LoginName],[Name]) VALUES (''NT SERVICE\MSSQLSERVER'',''NT SERVICE\MSSQLSERVER'');'
exec (@sql)
select @sql = 'INSERT INTO [master].[dbo].[sa_logins] ([LoginName],[Name]) VALUES (''NT SERVICE\SQLSERVERAGENT'',''NT SERVICE\SQLSERVERAGENT'');'
exec (@sql)
