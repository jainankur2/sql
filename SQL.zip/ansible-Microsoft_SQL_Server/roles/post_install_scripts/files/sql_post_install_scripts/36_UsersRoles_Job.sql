USE [msdb]
GO

DECLARE @COUNTER TINYINT

SELECT @COUNTER = COUNT(*) FROM MSDB.DBO.SYSJOBS WHERE NAME = '~DBA - UsersRoles'

IF @COUNTER = 0
BEGIN 
/****** Object:  Job [~DBA - UsersRoles]    Script Date: 6/27/2016 2:30:46 PM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Database Maintenance]]    Script Date: 6/27/2016 2:30:46 PM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Database Maintenance]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Database Maintenance]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'~DBA - UsersRoles', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'1) Create [master].[dbo].[UsersRoles] table if it doesn''t exist.    2) Load  [master].[dbo].[UsersRoles]  3) Purge > 60 days   4) Email failure', 
		@category_name=N'[Database Maintenance]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Create table UsersRoles]    Script Date: 6/27/2016 2:30:46 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Create table UsersRoles', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=4, 
		@on_success_step_id=2, 
		@on_fail_action=4, 
		@on_fail_step_id=4, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'IF NOT EXISTS (select 1 from master.sys.objects where name = N''UsersRoles'' and type = ''U'')
BEGIN

SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
SET ANSI_PADDING ON

CREATE TABLE [master].[dbo].[UsersRoles](
	[ID] [bigint] IDENTITY(1,1) NOT NULL,
	[NBR_DAILY_RUNS] [tinyint] NOT NULL,
	[DB_NM] [varchar](80) NOT NULL,
	[INSERT_DT] [datetime] NOT NULL CONSTRAINT [DF_UsersRoles_INSERT_DT]  DEFAULT (getdate()),
	[COMMAND] [varchar](max) NOT NULL,
 CONSTRAINT [PK_UsersRoles] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

CREATE NONCLUSTERED INDEX [IX_UsersRoles] ON [master].[dbo].[UsersRoles]
(
	[INSERT_DT] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

SET ANSI_PADDING OFF
END


', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Insert data into master.dbo.UsersRoles]    Script Date: 6/27/2016 2:30:47 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Insert data into master.dbo.UsersRoles', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=4, 
		@on_success_step_id=3, 
		@on_fail_action=4, 
		@on_fail_step_id=4, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

set nocount on

declare	@dbname	sysname
declare @sql varchar(max) = ''''
declare @ID int = 1
declare @max_ID int
declare @nbr_daily_runs varchar(3)
declare @date varchar(26)
declare @workdate date

set @date = left(convert(varchar(20), getdate(), 20), 16) + '':00.000''
set @nbr_daily_runs = ''1''
select @workdate = cast(@date as date)

if exists (select 1 from master.dbo.UsersRoles where cast(insert_dt as date) = @workdate)
begin
   select @nbr_daily_runs = cast(max(NBR_DAILY_RUNS) + 1 as varchar) FROM master.dbo.UsersRoles where cast(insert_dt as date) = @workdate
end

CREATE TABLE #UsersRoles (ID int identity(1,1),  NBR_DAILY_RUNS varchar(3), DB_NM varchar(256), insert_dt varchar(26), UsersRoles VARCHAR(MAX)) 

declare dbcursor cursor for
	    select name
	    from master..sysdatabases
            where name not in (''tempdb'')
            and DATABASEPROPERTY(name, ''IsOffline'') = 0 
            and DATABASEPROPERTY(name, ''IsSuspect'') = 0
            and DATABASEPROPERTY(name, ''IsReadOnly'') = 0   
            for read only
	
	open dbcursor
	
	fetch next from dbcursor into @dbname
	while (@@fetch_status = 0)
	begin


select @sql = ''USE ['' + @dbname + '']; SELECT '''''' + @nbr_daily_runs + '''''', '''''' + @dbname + '''''', '''''' + @date + '''''', ''''USE ['' + @dbname + ''];''''''

insert into #UsersRoles
exec(@sql)

select @sql = ''USE ['' + @dbname + '']; SELECT '''''' + @nbr_daily_runs + '''''', '''''' + @dbname + '''''', '''''' + @date + '''''', ''''-- Database schema''''''

insert into #UsersRoles
exec (@sql)



select @sql = ''USE ['' + @dbname + '']; SELECT DISTINCT '''''' + @nbr_daily_runs + '''''', '''''' + @dbname + '''''', '''''' + @date + '''''', ''''IF  EXISTS (SELECT * FROM sys.schemas WHERE name =  ''''+ '''''''''''''''' + a.name + '''''''''''''''' +'''')  DROP Schema ''''+ ''''['''' + a.name + ''''];''''+''''''''
from  sys.schemas a
inner join sys.database_principals b
on a.principal_id  =b.principal_id 
where b.is_fixed_role =0
and a.name COLLATE SQL_Latin1_General_CP1_CI_AS not in(''''dbo'''',''''sys'''',''''guest'''',''''INFORMATION_SCHEMA'''',''''sys'''')''

insert into #UsersRoles
exec (@sql)


select @sql =  ''USE ['' + @dbname + '']; SELECT '''''' + @nbr_daily_runs + '''''', '''''' + @dbname + '''''', '''''' + @date + '''''',  ''''--Database users''''''

insert into #UsersRoles
exec (@sql)


select @sql = ''USE ['' + @dbname + '']; SELECT DISTINCT '''''' + @nbr_daily_runs + '''''', '''''' + @dbname + '''''', '''''' + @date + '''''',  ''''IF  EXISTS (SELECT * FROM sys.database_principals WHERE name =  ''''+ '''''''''''''''' + u.name  COLLATE SQL_Latin1_General_CP1_CI_AS + '''''''''''') DROP USER ['''' + u.name COLLATE SQL_Latin1_General_CP1_CI_AS + ''''] CREATE USER '''' + ''''['''' + u.name COLLATE SQL_Latin1_General_CP1_CI_AS + '''']   FOR  LOGIN ['''' + l.name COLLATE SQL_Latin1_General_CP1_CI_AS  + ''''] WITH DEFAULT_SCHEMA = dbo;''''+''''''''
              from sys.database_principals u  
         left join (sys.database_role_members m join sys.database_principals r on m.role_principal_id = r.principal_id) on m.member_principal_id = u.principal_id  
         left join sys.server_principals l on u.sid = l.sid  
         where u.type COLLATE SQL_Latin1_General_CP1_CI_AS <> ''''R''''  
and l.name COLLATE SQL_Latin1_General_CP1_CI_AS is not null
and u.name COLLATE SQL_Latin1_General_CP1_CI_AS != ''''dbo''''''

insert into #UsersRoles
exec (@sql)


select @sql =  ''USE ['' + @dbname + '']; SELECT '''''' + @nbr_daily_runs + '''''', '''''' + @dbname + '''''', '''''' + @date + '''''', ''''--Database Roles''''''

insert into #UsersRoles
exec (@sql)


select @sql = ''USE ['' + @dbname + '']; SELECT DISTINCT '''''' + @nbr_daily_runs + '''''', '''''' + @dbname + '''''', '''''' + @date + '''''',  ''''IF  EXISTS (SELECT * FROM sys.database_principals WHERE name = '''''''''''' + '''''''' + dp.name COLLATE SQL_Latin1_General_CP1_CI_AS + '''''''''''') DROP ROLE '''' ++ ''''['''' + dp.name COLLATE SQL_Latin1_General_CP1_CI_AS + '''']  CREATE ROLE '''' + ''''['''' + dp.name COLLATE SQL_Latin1_General_CP1_CI_AS + '''']'''' + '''' AUTHORIZATION ['''' + (select dr.name COLLATE SQL_Latin1_General_CP1_CI_AS  from ['' + @dbname + ''].sys.database_principals dr where dr.principal_id = dp.owning_principal_id)  +''''];''''+''''''''
 from sys.database_principals dp 
  where (dp.type COLLATE SQL_Latin1_General_CP1_CI_AS = ''''R'''' or dp.type COLLATE SQL_Latin1_General_CP1_CI_AS = ''''A'''')
and dp.name COLLATE SQL_Latin1_General_CP1_CI_AS not like ''''public''''
and dp.is_fixed_role !=1''

insert into #UsersRoles
exec (@sql)

select @sql =  ''USE ['' + @dbname + '']; SELECT '''''' + @nbr_daily_runs + '''''', '''''' + @dbname + '''''', '''''' + @date + '''''', ''''--Database Roles and Members'''''' 

insert into #UsersRoles
exec (@sql)

select @sql = ''USE ['' + @dbname + '']; SELECT '''''' + @nbr_daily_runs + '''''', '''''' + @dbname + '''''', '''''' + @date + '''''', ''''EXEC sp_addrolemember @rolename =''''
	+ SPACE(1) + '''''''''''''''' + USER_NAME(rm.role_principal_id) + '''''''''''''''' + '''', @membername ='''' + SPACE(1) + '''''''''''''''' + USER_NAME(rm.member_principal_id) + ''''''''''''''''
FROM	sys.database_role_members AS rm
where USER_NAME(rm.member_principal_id)  !=''''dbo'''';''

insert into #UsersRoles
exec (@sql)

select @sql = ''USE ['' + @dbname + '']; SELECT '''''' + @nbr_daily_runs + '''''', '''''' + @dbname + '''''', '''''' + @date + '''''', ''''-- User Object Level Permissions'''''' 

insert into #UsersRoles
exec (@sql)

select @sql = ''USE ['' + @dbname + '']; SELECT '''''' + @nbr_daily_runs + '''''', '''''' + @dbname + '''''', '''''' + @date + '''''',  '''''''' +	CASE WHEN perm.state <> ''''W'''' THEN perm.state_desc ELSE ''''GRANT'''' END 
	+ SPACE(1) + perm.permission_name + SPACE(1) + ''''ON '''' + QUOTENAME(SCHEMA_NAME(obj.schema_id)) + ''''.'''' + QUOTENAME(obj.name) 
	+ CASE WHEN cl.column_id IS NULL THEN SPACE(0) ELSE ''''('''' + QUOTENAME(cl.name) + '''')'''' END
	+ SPACE(1) + ''''TO'''' + SPACE(1) + QUOTENAME(usr.name) COLLATE database_default
	+ CASE WHEN perm.state <> ''''W'''' THEN SPACE(0) ELSE SPACE(1) + ''''WITH GRANT OPTION'''' END + ''''''''+''''''''
FROM	sys.database_permissions AS perm
	INNER JOIN
	sys.objects AS obj
	ON perm.major_id = obj.[object_id]
	INNER JOIN
	sys.database_principals AS usr
	ON perm.grantee_principal_id = usr.principal_id
	LEFT JOIN
	sys.columns AS cl
	ON cl.column_id = perm.minor_id AND cl.[object_id] = perm.major_id''

insert into #UsersRoles
exec (@sql)

select @sql = ''USE ['' + @dbname + '']; SELECT '''''' + @nbr_daily_runs + '''''', '''''' + @dbname + '''''', '''''' + @date + '''''', ''''-- System Object Level Permissions'''''' 

insert into #UsersRoles
exec (@sql)

select @sql = ''USE ['' + @dbname + '']; SELECT '''''' + @nbr_daily_runs + '''''', '''''' + @dbname + '''''', '''''' + @date + '''''',  '''''''' +	CASE WHEN perm.state <> ''''W'''' THEN perm.state_desc ELSE ''''GRANT'''' END
	+ SPACE(1) + perm.permission_name + SPACE(1) + ''''ON '''' + QUOTENAME(SCHEMA_NAME(obj.schema_id)) + ''''.'''' + QUOTENAME(obj.name) 
	+ SPACE(1) + ''''TO'''' + SPACE(1) + QUOTENAME(usr.name) COLLATE database_default
	+ CASE WHEN perm.state <> ''''W'''' THEN SPACE(0) ELSE SPACE(1) + ''''WITH GRANT OPTION'''' END + ''''''''+''''''''    
FROM	 sys.database_permissions AS perm
	INNER JOIN
	sys.all_objects AS obj
	ON perm.major_id = obj.[object_id]
	INNER JOIN
	sys.database_principals AS usr
	ON perm.grantee_principal_id = usr.principal_id
where  obj.SCHEMA_ID =4''

insert into #UsersRoles
exec (@sql)

select @sql = ''USE ['' + @dbname + '']; SELECT '''''' + @nbr_daily_runs + '''''', '''''' + @dbname + '''''', '''''' + @date + '''''', ''''--Database Level Permissions'''''' 

insert into #UsersRoles
exec (@sql)

 select @sql = ''USE ['' + @dbname + '']; SELECT DISTINCT '''''' + @nbr_daily_runs + '''''', '''''' + @dbname + '''''', '''''' + @date + '''''', '''''''' + CASE WHEN perm.state <> ''''W'''' THEN perm.state_desc ELSE ''''GRANT'''' END
	+ SPACE(1) + perm.permission_name + SPACE(1)
	+ SPACE(1) + ''''TO'''' + SPACE(1) + QUOTENAME(usr.name) COLLATE database_default
	+ CASE WHEN perm.state <> ''''W'''' THEN SPACE(0) ELSE SPACE(1) + ''''WITH GRANT OPTION'''' END  + ''''''''+'''''''' 
FROM	sys.database_permissions AS perm
	INNER JOIN
	sys.database_principals AS usr
	ON perm.grantee_principal_id  = usr.principal_id 
and usr.name COLLATE SQL_Latin1_General_CP1_CI_AS !=''''dbo''''
and class_desc COLLATE SQL_Latin1_General_CP1_CI_AS =''''DATABASE''''
and perm.type COLLATE SQL_Latin1_General_CP1_CI_AS !=''''sl''''''

insert into #UsersRoles
exec (@sql)



		fetch next from dbcursor into @dbname
	  end
	close dbcursor
	deallocate dbcursor

select @max_ID = max(ID) from #UsersRoles

while (@ID <= @max_ID)
begin

  insert into master.dbo.UsersRoles select cast(NBR_DAILY_RUNS as tinyint), DB_NM, cast(insert_dt as datetime), UsersRoles from #UsersRoles where ID = @ID
 
set @ID = @ID + 1
end

drop table #UsersRoles
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Purge data 2 months old from master.dbo.UsersRoles]    Script Date: 6/27/2016 2:30:47 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Purge data 2 months old from master.dbo.UsersRoles', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=4, 
		@on_fail_step_id=4, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'DELETE FROM master.dbo.UsersRoles WHERE INSERT_DT <= dateadd(mm, -2, cast(GETDATE() as date))', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Email Failure]    Script Date: 6/27/2016 2:30:47 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Email Failure', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=2, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'IF DATEPART(hour, getdate()) between 6 and 18 

BEGIN
declare @mailbody varchar(255)
declare @domain char(9)
declare @env char(4)

set @domain = DEFAULT_DOMAIN()
If @domain = ''ADHCSCINT'' begin set @env = ''PROD'' end
If @domain = ''ADHCSCTST'' begin set @env = ''TEST'' end
If @domain = ''ADHCSCDEV'' begin set @env = ''DEV '' end
If @domain not in (''ADHCSCDEV'', ''ADHCSCTST'',''ADHCSCINT'')  begin set @env = ''N/A  '' end

set @mailbody = ''ENV: '' + @env + '' - ~DBA - UsersRoles job failure on: '' + @@servername

EXEC sp_send_dbmail  @profile_name = ''CSDBA-Alerts'' 
    , @recipients = ''CSDBA-Alerts@hcsc.com''
    , @subject = @mailbody
    , @body =  @mailbody

END', 
		@database_name=N'msdb', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N's1', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=62, 
		@freq_subday_type=8, 
		@freq_subday_interval=6, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20160404, 
		@active_end_date=99991231, 
		@active_start_time=60000, 
		@active_end_time=180001--, 
	--	@schedule_uid=N'0f177cf3-6830-42a3-a10f-4e759199fd4a'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

END

GO

