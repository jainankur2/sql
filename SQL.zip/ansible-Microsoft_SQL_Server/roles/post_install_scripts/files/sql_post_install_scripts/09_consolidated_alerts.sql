USE [master]
GO
/****** Object:  StoredProcedure [dbo].[usp_logfilecapacity]    Script Date: 02/27/2008 08:54:10 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_logfilecapacity]') and OBJECTPROPERTY(id, N'Isprocedure ') = 1)
drop procedure [dbo].[usp_logfilecapacity]
GO
CREATE  procedure [dbo].[usp_logfilecapacity] AS
begin

Set nocount on
declare @Logspacevalidation int
declare @DBName sysname, @DBList varchar(4000)
declare @Sql varchar(2000),@EmailFrom varchar(25), @subject varchar(100),@EmailBody varchar(4000) , @emailpath varchar(200),@EmailTo varchar(50)
declare @logsize nvarchar(100),@percentagelogspaceused nvarchar(255),@LogFiledrive char(1), @availabledrivespace  dec(18,0)

Set @Sql ='DBCC sqlperf(logspace)'
Set @Logspacevalidation= 75

Create TABLE #Logspace (
databasename nvarchar(128) NOT NULL,
logsize nvarchar(100) null, 
percentagelogspaceused nvarchar(255) null,
status int)

Create  TABLE #DriveFreespace
		(driveletter char(1),
		Freespace dec(18,0))
		insert into #DriveFreespace
		exec('master..xp_fixeddrives')
 
INSERT INTO #Logspace (databasename, logsize, PercentageLogspaceused,Status)
	exec(@Sql)

If (select count(*) from #Logspace
Where  percentagelogspaceused > convert(numeric(12,2), @Logspacevalidation)) > 0
begin
declare CheckLogspace CURSOR FOR
select DISTINCT sd.name, logsize, percentagelogspaceused 
FROM  #Logspace sa
INNER JOIN master..sysdatabases sd on sa.databasename = sd.name
WHERE  percentagelogspaceused > convert(numeric(12,2), @Logspacevalidation)   
AND  DatabasePropertyEx(sd.name,'Status') = 'ONLINE'   
AND DatabasePropertyEx(sd.name,'Updateability')='READ_WRITE'
OPEN CheckLogspace

fetch NEXT FROM CheckLogspace INTO @DBName, @logsize,@percentagelogspaceused
WHILE @@fetch_status = 0
begin
     If @DBName is not null
	begin
 -- CHECK FOR AVAILABLE DRIVE SPACE
 		select distinct @LogFiledrive=   substring(sa.filename,1,charindex(':\',sa.filename)-1)  from sysaltfiles sa   inner join    sysdatabases sd
		on  sa.dbid = sd.dbid 
		where   sa.status & 0x40 = 0x40  and sd.name = @DBName
		select @availabledrivespace =Freespace From #DriveFreespace where driveletter = @LogFiledrive
	IF  CONVERT(dec(18,0),@logsize)  < @availabledrivespace 
		begin
	-- CHECK FOR AUTO GROW 	
	    IF (select COUNT(*)
			FROM master..sysaltfiles sa
			INNER JOIN sysdatabases sd on sa.dbid = sd.dbid
			WHERE (maxsize > -1 OR growth = 0)
			AND DatabasePropertyEx(sd.name,'Status') = 'ONLINE'   
			AND DatabasePropertyEx(sd.name,'Updateability')='READ_WRITE' 
			AND sa.status & 0x40 = 0x40  and sd.name = @DBName 
			AND DatabasePropertyEx(sd.name,'recovery') !='SIMPLE' ) > 0
		begin
		 	IF @DBList IS NULL
			begin
				SET @DBList =   'Database Name =' + @DBName + CHAR(13)  + 'logsize =' + @logsize  + ' MB' + CHAR(13) + 'Percentage of Log Used =' + @percentagelogspaceused + CHAR(13) + 'Available Drive Space = ' + CONVERT(VARCHAR,@availabledrivespace)  + ' MB'  + CHAR(13) 
			END
			ELSE
			begin
				SET @DBList = @DBList + CHAR(13) +   'Database Name =' + @DBName + CHAR(13)  + 'logsize =' + @logsize  + CHAR(13) + 'Percentage of Log Used ='   + CHAR(13)+ @percentagelogspaceused  + CHAR(13) + 'Available Drive Space = ' + CONVERT(VARCHAR,@availabledrivespace) + ' MB'  + CHAR(13) 
			END
		END
	END
	IF  CONVERT(dec(18,0),@logsize)  > @availabledrivespace 
    	 begin
		IF @DBList IS NULL
			begin
				SET @DBList =   'Database Name =' + @DBName + CHAR(13)  + 'logsize =' + @logsize  + ' MB' + CHAR(13) + 'Percentage of Log Used =' + @percentagelogspaceused + CHAR(13) + 'Available Drive Space = ' + CONVERT(VARCHAR,@availabledrivespace)  + ' MB'  + CHAR(13) 
			END
			ELSE
			begin
				SET @DBList = @DBList + CHAR(13) +   'Database Name =' + @DBName + CHAR(13)  + 'logsize =' + @logsize  + CHAR(13) + 'Percentage of Log Used ='   + CHAR(13)+ @percentagelogspaceused + CHAR(13) + 'Available Drive Space = ' + CONVERT(VARCHAR,@availabledrivespace) + ' MB'  + CHAR(13) 
			END
     	END
END
fetch NEXT FROM CheckLogspace INTO @DBName, @logsize,@percentagelogspaceused
END
CLOSE CheckLogspace
DEALLOCATE CheckLogspace
 IF @DBList IS NOT  NULL
begin
	Set @EmailTo =    'CSDBA-Alerts@hcsc.com'
	set @subject =  'Warning -' + @@servername+' - Log File Capacity'
    exec  msdb.dbo.sp_send_dbmail  @profile_name = 'CSDBA-Warnings',@recipients=@EmailTo, @subject= @subject,@body=@EmailBody
	 
END  
Drop table #Logspace 
Drop table #DriveFreespace
END

END

go
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SystemSP]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[SystemSP]
GO

Create TABLE [dbo].[SystemSP] (
	[id] [int] NOT NULL ,
	[name] [varchar] (27) NOT NULL,
	[number] [smallint] NOT NULL ,
	[colid] [smallint] NOT NULL ,
	[text] [nvarchar] (4000) NOT NULL 
) ON [PRIMARY]
GO

INSERT INTO SystemSP (id, name, number, colid, text)
select so.id, left(so.name, 27), sc.number, sc.colid, sc.text
from sysobjects so
inner join syscomments sc on so.id = sc.id
where xtype in ('P', 'X')
and number > 0 
GO

ALTER TABLE [dbo].[SystemSP] ADD 
	CONSTRAINT [PK_SystemSP] PRIMARY KEY  CLUSTERED 
	(
		[id],
		[number],
		[colid]
	)  ON [PRIMARY] 
GO
Print 'Dropping previous alerts'
go
USE [msdb]
GO
/****** Object:  Alert [Alert - Deadlock]    Script Date: 02/27/2008 09:06:23 ******/
IF  EXISTS (SELECT name FROM msdb.dbo.sysalerts WHERE name = N'Alert - Deadlock')
EXEC msdb.dbo.sp_delete_alert @name=N'Alert - Deadlock'
GO
/****** Object:  Alert [Alert - Log File Capacity]    Script Date: 02/27/2008 09:06:23 ******/
IF  EXISTS (SELECT name FROM msdb.dbo.sysalerts WHERE name = N'Alert - Log File Capacity')
EXEC msdb.dbo.sp_delete_alert @name=N'Alert - Log File Capacity'
GO
/****** Object:  Alert [Alert - Low Disk Space]    Script Date: 02/27/2008 09:06:23 ******/
IF  EXISTS (SELECT name FROM msdb.dbo.sysalerts WHERE name = N'Alert - Low Disk Space')
EXEC msdb.dbo.sp_delete_alert @name=N'Alert - Low Disk Space'
GO
/****** Object:  Alert [Demo: Sev. 19 Errors]    Script Date: 02/27/2008 09:06:23 ******/
IF  EXISTS (SELECT name FROM msdb.dbo.sysalerts WHERE name = N'Demo: Sev. 19 Errors')
EXEC msdb.dbo.sp_delete_alert @name=N'Demo: Sev. 19 Errors'
GO
/****** Object:  Alert [Demo: Sev. 21 Errors]    Script Date: 02/27/2008 09:06:23 ******/
IF  EXISTS (SELECT name FROM msdb.dbo.sysalerts WHERE name = N'Demo: Sev. 21 Errors')
EXEC msdb.dbo.sp_delete_alert @name=N'Demo: Sev. 21 Errors'
GO
/****** Object:  Alert [Demo: Sev. 22 Errors]    Script Date: 02/27/2008 09:06:23 ******/
IF  EXISTS (SELECT name FROM msdb.dbo.sysalerts WHERE name = N'Demo: Sev. 22 Errors')
EXEC msdb.dbo.sp_delete_alert @name=N'Demo: Sev. 22 Errors'
GO
/****** Object:  Alert [Demo: Sev. 23 Errors]    Script Date: 02/27/2008 09:06:23 ******/
IF  EXISTS (SELECT name FROM msdb.dbo.sysalerts WHERE name = N'Demo: Sev. 23 Errors')
EXEC msdb.dbo.sp_delete_alert @name=N'Demo: Sev. 23 Errors'
GO
/****** Object:  Alert [Demo: Sev. 24 Errors]    Script Date: 02/27/2008 09:06:23 ******/
IF  EXISTS (SELECT name FROM msdb.dbo.sysalerts WHERE name = N'Demo: Sev. 24 Errors')
EXEC msdb.dbo.sp_delete_alert @name=N'Demo: Sev. 24 Errors'
GO
/****** Object:  Alert [Demo: Sev. 25 Errors]    Script Date: 02/27/2008 09:06:23 ******/
IF  EXISTS (SELECT name FROM msdb.dbo.sysalerts WHERE name = N'Demo: Sev. 25 Errors')
EXEC msdb.dbo.sp_delete_alert @name=N'Demo: Sev. 25 Errors'
GO
/****** Object:  Alert [Warning - Average Wait Time]    Script Date: 02/27/2008 09:06:23 ******/
IF  EXISTS (SELECT name FROM msdb.dbo.sysalerts WHERE name = N'Warning - Average Wait Time')
EXEC msdb.dbo.sp_delete_alert @name=N'Warning - Average Wait Time'
go
USE [msdb]
GO
/****** Object:  Job [Alarm - Fatal Error]    Script Date: 02/27/2008 09:07:57 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'Alarm - Fatal Error')
EXEC msdb.dbo.sp_delete_job @job_name=N'Alarm - Fatal Error', @delete_unused_schedule=1
GO
/****** Object:  Job [Alert - Deadlock]    Script Date: 02/27/2008 09:07:57 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'Alert - Deadlock')
EXEC msdb.dbo.sp_delete_job @job_name=N'Alert - Deadlock', @delete_unused_schedule=1
GO
/****** Object:  Job [Alert - Disk Space]    Script Date: 02/27/2008 09:07:57 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'Alert - Disk Space')
EXEC msdb.dbo.sp_delete_job @job_name= N'Alert - Disk Space', @delete_unused_schedule=1
GO
/****** Object:  Job [Alert - Log File Capacity]    Script Date: 02/27/2008 09:07:57 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'Alert - Log File Capacity')
EXEC msdb.dbo.sp_delete_job @job_name= N'Alert - Log File Capacity' , @delete_unused_schedule=1
GO
/****** Object:  Job [Alert - Low Disk Space]    Script Date: 02/27/2008 09:07:57 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'Alert - Low Disk Space')
EXEC msdb.dbo.sp_delete_job @job_name=N'Alert - Low Disk Space' , @delete_unused_schedule=1
GO
/****** Object:  Job [Warning - Average Wait Time]    Script Date: 02/27/2008 09:07:57 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'Warning - Average Wait Time')
EXEC msdb.dbo.sp_delete_job @job_name=N'Warning - Average Wait Time' , @delete_unused_schedule=1
GO
/****** Object:  Job [Warning - Change system sp]    Script Date: 02/27/2008 09:07:57 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'Warning - Change system sp')
EXEC msdb.dbo.sp_delete_job @job_name=N'Warning - Change system sp' , @delete_unused_schedule=1
GO
/****** Object:  Job [Warning - Check Autogrow]    Script Date: 02/27/2008 09:07:57 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'Warning - Check Autogrow')
EXEC msdb.dbo.sp_delete_job @job_name=N'Warning - Check Autogrow' , @delete_unused_schedule=1
GO
/****** Object:  Job [Warning - Long Running Process]    Script Date: 02/27/2008 09:07:57 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'Warning - Long Running Process')
EXEC msdb.dbo.sp_delete_job @job_name= N'Warning - Long Running Process' , @delete_unused_schedule=1
GO
/****** Object:  Job [Warning - New sa logins]    Script Date: 02/27/2008 09:07:57 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'Warning - New sa logins')
EXEC msdb.dbo.sp_delete_job @job_name=N'Warning - New sa logins' , @delete_unused_schedule=1
GO
/****** Object:  Job [Warning - Number of Blocks]    Script Date: 02/27/2008 09:07:57 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'Warning - Number of Blocks')
EXEC msdb.dbo.sp_delete_job @job_name =N'Warning - Number of Blocks', @delete_unused_schedule=1
go


 
/****** Object:  Job [Alarm - Fatal Error]    Script Date: 02/27/2008 08:50:25 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 02/27/2008 08:50:25 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Alarm - Fatal Error', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Send Email]    Script Date: 02/27/2008 08:50:26 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Send Email', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=1, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @sql varchar(2000),@EmailFrom varchar(25), @subject varchar(100),@EmailBody varchar(100) , @emailpath varchar(200),@EmailTo varchar(50)
set @EmailTo =  ''CSDBA-Alerts@hcsc.com''
set @subject =  ''Alarm - '' +@@servername+'' -  Fatal Error''
set @EmailBody= @subject 
exec  msdb.dbo.sp_send_dbmail  @profile_name =''CSDBA-Alerts'',@recipients=@EmailTo, @subject= @subject,@body=@EmailBody


 

 
 


', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO
/****** Object:  Job [Alert - Deadlock]    Script Date: 02/27/2008 08:50:26 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 02/27/2008 08:50:26 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Alert - Deadlock', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Send Email]    Script Date: 02/27/2008 08:50:26 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Send Email', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=1, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare   @EmailTo varchar(50),@subject varchar(100),@EmailBody varchar(100) 
	set @EmailTo =  ''CSDBA-Alerts@hcsc.com''
	set @subject = ''Alert - ''+@@servername+'' - Deadlock''
	set @EmailBody= ''DBA Monitor - Deadlock''
 

 	exec  msdb.dbo.sp_send_dbmail  @profile_name =''CSDBA-Alerts'',@recipients=@EmailTo, @subject= @subject,@body=@EmailBody', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO
/****** Object:  Job [Alert - Disk Space]    Script Date: 10/22/2009 09:37:45 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 10/22/2009 09:37:45 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Alert - Disk Space', 
		@enabled=0, 
		@notify_level_eventlog=2, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Diskspace]    Script Date: 10/22/2009 09:37:45 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Diskspace', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=1, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'Set nocount on 
 begin 
  declare  @rs INTEGER, @fso Integer, @getdrive Varchar(13),    @drv Integer, @drivesize Varchar(20),@driveletter Char(1), @Outputresult Varchar(8000),@idriveletter Char(1),@iTotalAllocatedSpace Varchar(200),@iFreeSpace Varchar(200)
  declare @Diskspacevalidation Integer, @DiskCalc numeric(12,2), @CdriveFreespace smallint
  declare @sql varchar(2000),@EmailFrom varchar(25), @subject varchar(100),@EmailBody varchar(2000) , @emailpath varchar(200),@EmailTo varchar(50)
  Set @Diskspacevalidation= 15
  Set @CdriveFreespace = 1024  -- In MB. Default set to 1 GB freespace.
	Create  TABLE #DriveFreespace
		(driveletter char(1),
		Freespace dec(18,0))
		insert into #DriveFreespace
		exec(''master..xp_fixeddrives'')
	Create  TABLE #DriveTotalSpace
	(driveletter char(1),
	TotalSpace dec(18,0))
 declare  C1 Cursor For
select driveletter from #DriveFreespace
OPEN C1
fetch next from C1 into  @driveletter
WHILE @@fetch_status = 0
   begin
  SET @getdrive = ''GetDrive("'' + @driveletter + ''")'' 
  exec @rs = sp_OACreate ''Scripting.FileSystemObject'', @fso OUTPUT 
  IF @rs = 0 
   exec @rs = sp_OAMethod @fso, @getdrive, @drv OUTPUT 
  IF @rs = 0 
   exec @rs = sp_OAGetProperty @drv,''TotalSize'', @drivesize OUTPUT 
  IF @rs<> 0 
   SET @drivesize = NULL 
insert into #DriveTotalSpace
values(@driveletter,@drivesize)
  exec sp_OADestroy @drv 
  exec sp_OADestroy @fso 
fetch next from C1 into  @driveletter
End
CLOSE C1
DEALLOCATE C1
declare C2 cursor For
select a.driveletter, Convert(decimal(18,2), (TotalSpace /1024.0)/1024.0)   TotalAllocatedSpace,Convert(Varchar,Freespace)  FreeSpace  
 from #DriveFreespace a, #DriveTotalSpace b where a.driveletter=b.driveletter 
Open C2
fetch next from C2 into @idriveletter,@iTotalAllocatedSpace,@iFreeSpace
WHILE @@fetch_status = 0
begin
select  @DiskCalc  =   CONVERT(decimal(18,2),@iFreeSpace)/CONVERT(decimal(18,2), @iTotalAllocatedSpace) *100  

 If   (@Outputresult  is null and  @DiskCalc <= @Diskspacevalidation and @idriveletter <> ''C'')
 Begin
Set @Outputresult =  @idriveletter +'' Drive has '' +  ''Total Space = '' + convert(varchar, @iTotalAllocatedSpace) +''MB '' +  ''; Free Space = '' +  convert(varchar,@iFreeSpace)  + ''MB ; Free Space = '' +  LEFT(CONVERT(VARCHAR,( (CONVERT(decimal(18,2),@iFreeSpace)/CONVERT(decimal(18,2), @iTotalAllocatedSpace))*100) ) , 2) + ''% of available space.'' + char(13)
 End
 Else
 If   (@Outputresult  is null and @idriveletter = ''C'' and convert(varchar,@iFreeSpace) < @CdriveFreespace)
 Begin
Set @Outputresult =  @idriveletter +'' Drive has '' +  ''Total Space = '' + convert(varchar, @iTotalAllocatedSpace) +''MB '' +  ''; Free Space = '' +  convert(varchar,@iFreeSpace)  + ''MB ; Free Space = '' +  LEFT(CONVERT(VARCHAR,( (CONVERT(decimal(18,2),@iFreeSpace)/CONVERT(decimal(18,2), @iTotalAllocatedSpace))*100) ) , 2) + ''% of available space.'' + char(13)
 End
 Else
if  @DiskCalc <= @Diskspacevalidation and @idriveletter <> ''C''
 Begin
Set @Outputresult =@Outputresult +@idriveletter +'' Drive has '' +  ''Total Space = '' + convert(varchar, @iTotalAllocatedSpace) +''MB '' +  ''; Free Space = '' +  convert(varchar,@iFreeSpace)  + ''MB ; Free Space = '' +  LEFT(CONVERT(VARCHAR,( (CONVERT(decimal(18,2),@iFreeSpace)/CONVERT(decimal(18,2), @iTotalAllocatedSpace))*100) ) , 2) + ''% of available space.'' + char(13)
 End
 Else
 if  @idriveletter = ''C'' and convert(varchar,@iFreeSpace) < @CdriveFreespace
 Begin
Set @Outputresult =@Outputresult +@idriveletter +'' Drive has '' +  ''Total Space = '' + convert(varchar, @iTotalAllocatedSpace) +''MB '' +  ''; Free Space = '' +  convert(varchar,@iFreeSpace)  + ''MB ; Free Space = '' +  LEFT(CONVERT(VARCHAR,( (CONVERT(decimal(18,2),@iFreeSpace)/CONVERT(decimal(18,2), @iTotalAllocatedSpace))*100) ) , 2) + ''% of available space.'' + char(13)
 End
fetch next from C2 into @idriveletter,@iTotalAllocatedSpace,@iFreeSpace
End
Close C2
Deallocate C2
If  rtrim(rtrim(@Outputresult)) !='''' and @Outputresult  is not null
begin
	set @EmailTo =  ''CSDBA-Alerts@hcsc.com''
   	 set @subject =''Alert -'' + @@servername+'' - Disk Space''
	set @EmailBody= @Outputresult
  	exec  msdb.dbo.sp_send_dbmail  @profile_name =''CSDBA-Alerts'',@recipients=@EmailTo, @subject= @subject,@body=@EmailBody




End
Drop TABLE #DriveFreespace
Drop TABLE #DriveTotalSpace
END', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Diskspace', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=8, 
		@freq_subday_interval=1, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20051206, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO
/****** Object:  Job [Alert - Log File Capacity]    Script Date: 02/27/2008 08:50:27 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 02/27/2008 08:50:27 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Alert - Log File Capacity', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Send Email]    Script Date: 02/27/2008 08:50:28 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Send Email', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=1, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec master..usp_logfilecapacity', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO
/****** Object:  Job [Alert - Low Disk Space]    Script Date: 02/27/2008 08:50:28 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 02/27/2008 08:50:28 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Alert - Low Disk Space', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Send Email]    Script Date: 02/27/2008 08:50:28 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Send Email', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=1, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare   @EmailTo varchar(50),@subject varchar(100),@EmailBody varchar(100) 
 Set @EmailTo =  ''CSDBA-Alerts@hcsc.com''
set @subject =   ''Alert -'' + @@servername+''  - Low Disk Space''
Set @EmailBody=   ''DBA Monitor - Low Disk Space''

exec  msdb.dbo.sp_send_dbmail  @profile_name =''CSDBA-Alerts'',@recipients=@EmailTo, @subject= @subject,@body=@EmailBody



', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO
USE [msdb]
GO
/****** Object:  Job [Warning - Average Wait Time]    Script Date: 05/08/2008 13:37:31 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 05/08/2008 13:37:31 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Warning - Average Wait Time', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Send Email]    Script Date: 05/08/2008 13:37:31 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Send Email', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=1, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare  @EmailFrom varchar(50), @subject varchar(100),@EmailBody varchar(4000) , @emailpath varchar(200),@EmailTo varchar(50),
	 @sql varchar(2000), @spid varchar(10), @inputbuffer varchar(4000)
declare   Blocks CURSOR FOR
select convert(varchar,SPid)
from master..sysprocesses
where waittime >  60000
and spid > 10
and status !=''background''

Create TABLE #InputBuffer (
EventType nvarchar(30) NOT NULL,
Parameters int,
EventInfo nvarchar(4000)
)

 
Set @EmailBody=''''
  

OPEN Blocks

fetch NEXT FROM Blocks INTO @spid

WHILE @@fetch_status = 0
begin

select TOP 1 @EmailBody=  @EmailBody + ''Spid = '' + CONVERT(varchar(10), @spid) + CHAR(13)  + ''Host Name = '' + sp.HostName + CHAR(13)  + 
''Database Name = '' + sd.name + CHAR(13)  + ''Program Name = '' + sp.program_name + CHAR(13) + ''User Name = '' + sp.loginame + CHAR(13) + 
''Command Name = '' + sp.cmd + CHAR(13) + ''Last Batch = '' + CONVERT(varchar, sp.last_batch) + CHAR(13) + 
''Wait time = '' +  convert(varchar,datediff(hour,''1/1/1900'', dateadd(ms,waittime,''1/1/1900''))) +'' Hours:'' +
convert(varchar, DATEDIFF(MI, convert(datetime,convert(varchar,dateadd(ms,waittime,''1/1/1900''),110) +'' ''+ convert(varchar, datepart(hh,dateadd(ms,waittime,''1/1/1900'')))+ '':00:00:000'' ),dateadd(ms,waittime,''1/1/1900'')) ) + '' Minutes:'' +
convert(varchar, DATEDIFF(SS, CONVERT(DATETIME, convert(varchar,dateadd(ms,waittime,''1/1/1900''),110)  +'' ''+ convert(varchar, datepart(hh,dateadd(ms,waittime,''1/1/1900''))) +'':''+ convert(varchar, datepart(mi,dateadd(ms,waittime,''1/1/1900'')))+'':00:000'') , dateadd(ms,waittime,''1/1/1900''))) + ''Seconds''

FROM master..sysprocesses sp
INNER JOIN sysdatabases sd ON sp.dbid = sd.dbid
WHERE  spid = @spid
and sp.status !=''background''
 
 INSERT INTO #InputBuffer (EventType, Parameters, EventInfo)
	exec(''DBCC INPUTBUFFER('' + @spid + '')'')
select @EmailBody = @EmailBody + CHAR(13) + ''Input Buffer = '' + EventInfo
	FROM #InputBuffer

DELETE FROM  #InputBuffer

Set @EmailBody=@EmailBody+char(13)

fetch NEXT FROM Blocks INTO @spid     



END
CLOSE Blocks
DEALLOCATE Blocks

IF @EmailBody <> ''''
begin
set @EmailTo =  ''CSDBA-Alerts@hcsc.com''
 set @subject =    ''Warning - '' + @@servername + '' - Average Wait Time''
Set @EmailBody=    ''Warning - '' + @@servername + '' - Average Wait Time''
exec  msdb.dbo.sp_send_dbmail  @profile_name =''CSDBA-Warnings'',@recipients=@EmailTo, @subject= @subject,@body=@EmailBody

 



DROP TABLE #InputBuffer
END


', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/****** Object:  Job [Warning - Change system sp]    Script Date: 02/27/2008 08:50:29 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 02/27/2008 08:50:29 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Warning - Change system sp', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Send email]    Script Date: 02/27/2008 08:50:29 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Send email', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=1, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @SPname sysname, @SPList varchar(2000)
declare @EmailFrom varchar(25), @subject varchar(100),@EmailBody varchar(2000) , @emailpath varchar(200),@EmailTo varchar(50)

declare System_sp CURSOR FOR

select distinct ss.name
from SystemSP ss
left join syscomments sc ON  ss.id = sc.id
			 AND ss.number = sc.number
			 AND ss.colid = sc.colid
			 AND ss.text = sc.text
WHERE sc.id IS NULL


OPEN System_sp

fetch NEXT FROM System_sp INTO @SPname

WHILE @@fetch_status = 0
begin
	
	IF @SPList IS NULL
	begin
		SET @SPList = @SPname
	END
	ELSE
	begin
		SET @SPList = @SPList + '', '' + @SPname
	END

	fetch NEXT FROM System_sp INTO @SPname

END

CLOSE System_sp
DEALLOCATE System_sp


IF @SPList IS NOT NULL
begin
	set @EmailTo =  ''CSDBA-Alerts@hcsc.com''
	set @subject =  ''Warning - '' + @@servername + '' has system stored procedure (s) which have changed.''
	Set @EmailBody = @SPList + '' system stored procedure (s) have been changed.''

	exec  msdb.dbo.sp_send_dbmail  @profile_name =''CSDBA-Warnings'',@recipients=@EmailTo, @subject= @subject,@body=@EmailBody

END
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Daily', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20061024, 
		@active_end_date=99991231, 
		@active_start_time=80000, 
		@active_end_time=235959
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO
/****** Object:  Job [Warning - Check Autogrow]    Script Date: 02/27/2008 08:50:29 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 02/27/2008 08:50:30 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Warning - Check Autogrow', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Send Email]    Script Date: 02/27/2008 08:50:30 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Send Email', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=1, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'IF (select COUNT(*)
FROM master..sysaltfiles sa
INNER JOIN sysdatabases sd on sa.dbid = sd.dbid
WHERE (maxsize > -1 OR growth = 0)
AND DatabasePropertyEx(sd.name,''Status'') = ''ONLINE''   
AND DatabasePropertyEx(sd.name,''Updateability'')=''READ_WRITE'' 
) > 0
begin



declare @DBName sysname, @DBList varchar(2000)
declare @sql varchar(2000),@EmailFrom varchar(25), @subject varchar(100),@EmailBody varchar(2000) , @emailpath varchar(200),@EmailTo varchar(50)

declare AutogrowDB CURSOR FOR
select DISTINCT sd.name
FROM master..sysaltfiles sa
INNER JOIN master..sysdatabases sd on sa.dbid = sd.dbid
WHERE (maxsize > -1 OR growth = 0)
AND DatabasePropertyEx(sd.name,''Status'') = ''ONLINE''   
AND DatabasePropertyEx(sd.name,''Updateability'')=''READ_WRITE''

OPEN AutogrowDB

fetch NEXT FROM AutogrowDB INTO @DBName 

WHILE @@fetch_status = 0
begin

	IF @DBList IS NULL
	begin
		SET @DBList = @DBName
	END
	ELSE
	begin
		SET @DBList = @DBList + '', '' + @DBName
	END

	fetch NEXT FROM AutogrowDB INTO @DBName 

END

CLOSE AutogrowDB
DEALLOCATE AutogrowDB

IF @DBList IS NOT  NULL
begin

 
	Set @EmailTo =  ''CSDBA-Alerts@hcsc.com''
	set @subject =  ''Warning -'' + @@servername+'' - Autogrow or Maxsize turned off''
	Set @EmailBody= @DBList + '' Database(s)  Autogrow or Maxsize turned off''
	exec  msdb.dbo.sp_send_dbmail  @profile_name =''CSDBA-Warnings'',@recipients=@EmailTo, @subject= @subject,@body=@EmailBody

  	
END

END', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Daily', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=62, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20051128, 
		@active_end_date=99991231, 
		@active_start_time=80000, 
		@active_end_time=235959
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO
/****** Object:  Job [Warning - Long Running Process]    Script Date: 02/27/2008 08:50:30 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 02/27/2008 08:50:30 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Warning - Long Running Process', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Send Mail]    Script Date: 02/27/2008 08:50:31 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Send Mail', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=1, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare  @EmailFrom varchar(25), @subject varchar(100),@EmailBody varchar(4000) , @emailpath varchar(200),@EmailTo varchar(50),
	 @sql varchar(2000), @spid varchar(10), @inputbuffer varchar(4000) 
Create TABLE #InputBuffer (
EventType nvarchar(30) NOT NULL,
Parameters int,
EventInfo nvarchar(4000)
)

declare   Longrunningprocess CURSOR FOR
select convert(varchar,spid)
from master..sysprocesses sp
WHERE   DATEDIFF(minute, sp.last_batch, getdate()) > 60 AND
  sp.status NOT IN (''sleeping'', ''background'')
AND (sp.loginame NOT IN (''sa'',  ''NT AUTHORITY\SYSTEM'',''tdp_admin'') AND sp.loginame NOT LIKE ''%dbadmin%'')
AND sp.last_batch > ''1/1/1900''

OPEN Longrunningprocess
Set @EmailBody=''''


fetch NEXT FROM Longrunningprocess INTO @spid

WHILE @@fetch_status = 0
begin
select TOP 1 @EmailBody= @EmailBody + ''spid = '' + CONVERT(varchar(10), sp.spid) + CHAR(13)  + ''Host Name = '' + sp.hostname + CHAR(13)  + 
''Database Name = '' + sd.name + CHAR(13)  + ''Program Name = '' + sp.program_name + CHAR(13) + ''User Name = '' + sp.loginame + CHAR(13) + 
''Command Name = '' + sp.cmd + CHAR(13) + ''Last Batch = '' + CONVERT(varchar, sp.last_batch), @spid = CONVERT(varchar(10), sp.spid)
FROM master..sysprocesses sp
INNER JOIN sysdatabases sd ON sp.dbid = sd.dbid
WHERE  spid = @spid

 INSERT INTO #InputBuffer (EventType, Parameters, EventInfo)
	exec(''DBCC INPUTBUFFER('' + @spid + '')'')
select @EmailBody = @EmailBody + CHAR(13) + ''Input Buffer = '' + EventInfo
	FROM #InputBuffer

DELETE FROM  #InputBuffer

Set @EmailBody=@EmailBody+char(13)

fetch NEXT FROM Longrunningprocess INTO @spid     
END


CLOSE Longrunningprocess
DEALLOCATE Longrunningprocess


IF @EmailBody <> ''''
begin

	 
	Set @EmailTo =  ''CSDBA-Alerts@hcsc.com''

	Set @subject =   ''Warning -'' + @@servername+'' - LongRunningProcess''
	Set @EmailBody=@subject 
	exec  msdb.dbo.sp_send_dbmail  @profile_name =''CSDBA-Warnings'',@recipients=@EmailTo, @subject= @subject,@body=@EmailBody

END 

DROP TABLE #InputBuffer', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Hourly', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=4, 
		@freq_subday_interval=60, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20051128, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [Warning - Number of Blocks]    Script Date: 02/27/2008 08:50:32 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 02/27/2008 08:50:32 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Warning - Number of Blocks', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Send Email]    Script Date: 02/27/2008 08:50:32 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Send Email', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=1, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'IF (select COUNT(*) FROM sysprocesses WHERE blocked > 0) >= 10
begin
	declare  @EmailFrom varchar(50), @subject varchar(100),@EmailBody varchar(4000) , @emailpath varchar(200),@EmailTo varchar(50),
		 @sql varchar(2000), @spid varchar(10), @inputbuffer varchar(255),@blockedspid int 
	
		
	declare   Blocks CURSOR FOR
	select convert(varchar,SPid)
	from master..sysprocesses
	where blocked <>0 and spid <> blocked
	 
	
	OPEN Blocks
	fetch NEXT FROM Blocks INTO @spid
	
	WHILE @@fetch_status = 0
	begin
	select TOP 1 @EmailBody=  ''Spid = '' + CONVERT(varchar(10), sp.spid) + CHAR(13)  + ''Host Name = '' + sp.HostName + CHAR(13)  + 
	''Database Name = '' + sd.name + CHAR(13)  + ''Program Name = '' + sp.program_name + CHAR(13) + ''User Name = '' + sp.loginame + CHAR(13) + 
	''Command Name = '' + sp.cmd + CHAR(13) + ''Last Batch = '' + CONVERT(varchar, sp.last_batch) + CHAR(13) + ''Blocked By = '' + CONVERT(varchar, sp.blocked) ,
	@blockedspid = sp.blocked
	FROM master..sysprocesses sp
	INNER JOIN sysdatabases sd ON sp.dbid = sd.dbid
	WHERE  spid = @spid
	
	
	select TOP 1 @EmailBody= @EmailBody + CHAR(13) +  ''Spid = '' + CONVERT(varchar(10), sp.spid) + CHAR(13)  + ''Host Name = '' + sp.HostName + CHAR(13)  + 
	''Database Name = '' + sd.name + CHAR(13)  + ''Program Name = '' + sp.program_name + CHAR(13) + ''User Name = '' + sp.loginame + CHAR(13) + 
	''Command Name = '' + sp.cmd + CHAR(13) + ''Last Batch = '' + CONVERT(varchar, sp.last_batch) + CHAR(13) + ''Blocked By = '' + CONVERT(varchar, sp.blocked) 
	FROM master..sysprocesses sp
	INNER JOIN sysdatabases sd ON sp.dbid = sd.dbid
	WHERE  spid = @blockedspid
	 
	 
	fetch NEXT FROM Blocks INTO @spid     
	
	
	
	END
	CLOSE Blocks
	DEALLOCATE Blocks
	
	IF @EmailBody IS NOT NULL
	begin
	set @EmailTo =    ''CSDBA-Alerts@hcsc.com''
	set @subject =    ''Warning - '' + @@servername + '' - Number of Blocks''
     	  exec  msdb.dbo.sp_send_dbmail  @profile_name =''CSDBA-Warnings'',@recipients=@EmailTo, @subject= @subject,@body=@EmailBody
	END
END', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Every 10 minutes', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=4, 
		@freq_subday_interval=10, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20051128, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
go
use msdb
go


IF (EXISTS (select name FROM msdb.dbo.sysalerts WHERE name = N'Alert - Deadlock'))
 ---- Delete the alert with the same name.
  execUTE msdb.dbo.sp_delete_alert @name = N'Alert - Deadlock' 
begin 
execUTE msdb.dbo.sp_add_alert @name = N'Alert - Deadlock', @message_id = 0, @severity = 0, @enabled = 1, @delay_between_responses = 3600, @performance_condition = N'SQLServer:Locks|Number of Deadlocks/sec|_Total|>|1', @include_event_description_in = 5, @job_name = N'Alert - Deadlock', @category_name = N'[Uncategorized]'
END
GO


IF (EXISTS (select name FROM msdb.dbo.sysalerts WHERE name = N'Alert - Log File Capacity'))
 ---- Delete the alert with the same name.
  execUTE msdb.dbo.sp_delete_alert @name = N'Alert - Log File Capacity' 
begin 
execUTE msdb.dbo.sp_add_alert @name = N'Alert - Log File Capacity', @message_id = 0, @severity = 0, @enabled = 1, @delay_between_responses = 3600, @performance_condition = N'SQLServer:Databases|Percent Log Used|_Total|>|75', @include_event_description_in = 5, @job_name = N'Alert - Log File Capacity', @category_name = N'[Uncategorized]'
END
GO


IF (EXISTS (select name FROM msdb.dbo.sysalerts WHERE name = N'Alert - Low Disk Space'))
 ---- Delete the alert with the same name.
  execUTE msdb.dbo.sp_delete_alert @name = N'Alert - Low Disk Space' 
begin 
execUTE msdb.dbo.sp_add_alert @name = N'Alert - Low Disk Space', @message_id = 3257, @severity = 0, @enabled = 1, @delay_between_responses = 3600, @include_event_description_in = 0, @job_name = N'Alert - Low Disk Space', @category_name = N'[Uncategorized]'
END
GO
IF (EXISTS (select name FROM msdb.dbo.sysalerts WHERE name = N'Demo: Sev. 19 Errors'))
 ---- Delete the alert with the same name.
  execUTE msdb.dbo.sp_delete_alert @name = N'Demo: Sev. 19 Errors' 
begin 
execUTE msdb.dbo.sp_add_alert @name = N'Demo: Sev. 19 Errors', @message_id = 0, @severity = 19, @enabled = 1, @delay_between_responses = 10, @include_event_description_in = 0, @job_name = N'Alarm - Fatal Error', @category_name = N'[Uncategorized]'
END

GO
IF (EXISTS (select name FROM msdb.dbo.sysalerts WHERE name = N'Demo: Sev. 21 Errors'))
 ---- Delete the alert with the same name.
  execUTE msdb.dbo.sp_delete_alert @name = N'Demo: Sev. 21 Errors' 
begin 
execUTE msdb.dbo.sp_add_alert @name = N'Demo: Sev. 21 Errors', @message_id = 0, @severity = 21, @enabled = 1, @delay_between_responses = 10, @include_event_description_in = 5, @job_name = N'Alarm - Fatal Error', @category_name = N'[Uncategorized]'
END

GO
IF (EXISTS (select name FROM msdb.dbo.sysalerts WHERE name = N'Demo: Sev. 22 Errors'))
 ---- Delete the alert with the same name.
  execUTE msdb.dbo.sp_delete_alert @name = N'Demo: Sev. 22 Errors' 
begin 
execUTE msdb.dbo.sp_add_alert @name = N'Demo: Sev. 22 Errors', @message_id = 0, @severity = 22, @enabled = 1, @delay_between_responses = 10, @include_event_description_in = 5, @job_name = N'Alarm - Fatal Error', @category_name = N'[Uncategorized]'
END

GO

IF (EXISTS (select name FROM msdb.dbo.sysalerts WHERE name = N'Demo: Sev. 23 Errors'))
 ---- Delete the alert with the same name.
  execUTE msdb.dbo.sp_delete_alert @name = N'Demo: Sev. 23 Errors' 
begin 
execUTE msdb.dbo.sp_add_alert @name = N'Demo: Sev. 23 Errors', @message_id = 0, @severity = 23, @enabled = 1, @delay_between_responses = 10, @include_event_description_in = 5, @job_name = N'Alarm - Fatal Error', @category_name = N'[Uncategorized]'
END

GO
IF (EXISTS (select name FROM msdb.dbo.sysalerts WHERE name = N'Demo: Sev. 24 Errors'))
 ---- Delete the alert with the same name.
  execUTE msdb.dbo.sp_delete_alert @name = N'Demo: Sev. 24 Errors' 
begin 
execUTE msdb.dbo.sp_add_alert @name = N'Demo: Sev. 24 Errors', @message_id = 0, @severity = 24, @enabled = 1, @delay_between_responses = 10, @include_event_description_in = 5, @job_name = N'Alarm - Fatal Error', @category_name = N'[Uncategorized]'
END

GO
IF (EXISTS (select name FROM msdb.dbo.sysalerts WHERE name = N'Demo: Sev. 25 Errors'))
 ---- Delete the alert with the same name.
  execUTE msdb.dbo.sp_delete_alert @name = N'Demo: Sev. 25 Errors' 
begin 
execUTE msdb.dbo.sp_add_alert @name = N'Demo: Sev. 25 Errors', @message_id = 0, @severity = 25, @enabled = 1, @delay_between_responses = 10, @include_event_description_in = 5, @job_name = N'Alarm - Fatal Error', @category_name = N'[Uncategorized]'
END

GO
IF (EXISTS (select name FROM msdb.dbo.sysalerts WHERE name = N'Warning - Average Wait Time'))
 ---- Delete the alert with the same name.
  execUTE msdb.dbo.sp_delete_alert @name = N'Warning - Average Wait Time' 
begin 
execUTE msdb.dbo.sp_add_alert @name = N'Warning - Average Wait Time', @message_id = 0, @severity = 0, @enabled = 1, @delay_between_responses = 3600, @performance_condition = N'SQLServer:Locks|Average Wait Time (ms)|_Total|>|60000', @include_event_description_in = 5, @job_name = N'Warning - Average Wait Time', @category_name = N'[Uncategorized]'
END


