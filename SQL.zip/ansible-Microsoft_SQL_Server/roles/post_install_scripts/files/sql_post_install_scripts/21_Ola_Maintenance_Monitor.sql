USE [msdb]
GO

/****** Object:  Job [Ola_Maintenance_Monitor]    Script Date: 11/7/2018 1:29:08 PM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Database Maintenance]]    Script Date: 11/7/2018 1:29:08 PM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Database Maintenance]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Database Maintenance]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Ola_Maintenance_Monitor', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Database Maintenance]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Populate DBA.dbo.OLA_work_table]    Script Date: 11/7/2018 1:29:08 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Populate DBA.dbo.OLA_work_table', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'SET NOCOUNT ON

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''DBA.dbo.OLA_work_table'') AND type in (N''U''))
begin
     create table DBA.dbo.OLA_work_table (ID int identity(1,1), 
	[WorkArea] varchar(max))
end

truncate table DBA.dbo.OLA_work_table

declare @maxcnt int

select @maxcnt = count(*) from [dbo].[CommandLog] where [ErrorNumber] <> 0 and [EndTime] between dateadd(mi, -15, getdate()) and getdate()

if @maxcnt >= 1
begin
         declare @mailbody NVARCHAR(255), @queryvar NVARCHAR(MAX)
         set @mailbody = ''[DBA].dbo.CommandLog error reported: ''+@@servername
		 set @queryvar = ''set nocount on;SELECT ''''** BEGIN** [DBA].dbo.CommandLog error reported: ''''+@@servername+'''':''''+'''' ID = ''''+ltrim(rtrim(convert(varchar(10),ID)))+'''', ''''+''''DatabaseName = ''''+rtrim(ISNULL(DatabaseName,''''N/A''''))+'''', ''''+''''SchemaName = ''''+rtrim(ISNULL(SchemaName,''''N/A''''))+'''', ''''+''''ObjectName = ''''+rtrim(ISNULL(ObjectName,''''N/A''''))+'''', ''''+''''ObjectType = ''''+rtrim(ISNULL(convert(varchar(10),ObjectType),''''N/A''''))+'''', ''''+''''IndexName = ''''+rtrim(ISNULL(IndexName,''''N/A''''))+'''', ''''+''''IndexType = ''''+rtrim(ISNULL(cast(IndexType as varchar),''''N/A''''))+'''', ''''+''''StatisticsName = ''''+rtrim(ISNULL(StatisticsName,''''N/A''''))+'''', ''''
		 +''''PartitionNumber = ''''+rtrim(ISNULL(cast(PartitionNumber as varchar),''''N/A''''))+'''', ''''+''''StartTime = ''''+rtrim(convert(varchar(25),StartTime))+'''', ''''+''''EndTime = ''''+rtrim(ISNULL(convert(varchar(25),EndTime),''''N/A''''))+'''', ''''+''''ErrorNumber = ''''+rtrim(ISNULL(convert(varchar(10),ErrorNumber),''''N/A''''))+'''', ''''+''''ErrorMessage = ''''+rtrim(ISNULL(ErrorMessage,''''N/A''''))+'''', ''''+''''Command = ''''+rtrim(ISNULL(Command,''''N/A''''))+'''' **END**''''  from [dbo].[CommandLog] where [ErrorNumber] <> 0 and [EndTime] between dateadd(mi, -15, getdate()) and getdate();''

         insert into DBA.dbo.OLA_work_table
       	 Exec (@queryvar)
end
', 
		@database_name=N'DBA', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [SQL Maintenance Fail Report]    Script Date: 11/7/2018 1:29:08 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'SQL Maintenance Fail Report', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'SET NOCOUNT ON

declare @reccount int
declare @cmdtotext as varchar(200)

select @reccount  = count(*) from DBA.dbo.OLA_work_table
	IF @reccount > 0 
		BEGIN
			set @cmdtotext = ''sqlcmd -S''+@@servername+'' -E -dDBA -y0 -Q"set nocount on select [WorkArea]  from DBA.dbo.OLA_work_table order by ID" -oD:\EDBA\Output\SQLMaintJobFailReport.Log''
			exec xp_cmdshell @cmdtotext
		END



', 
		@database_name=N'DBA', 
		@output_file_name=N'D:\EDBA\Output\SQLMaintJobMonitorLog.Log', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'maintjobmonitor', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=4, 
		@freq_subday_interval=15, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20180723, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959--, 
		--@schedule_uid=N'11eff24d-0570-45d7-9fec-e8e299e25869'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO


