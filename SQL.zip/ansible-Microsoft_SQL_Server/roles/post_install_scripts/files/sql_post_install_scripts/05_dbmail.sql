use [master]
go

sp_configure 'show advanced options', 1;
Go
reconfigure with override;
Go
sp_configure 'Database Mail XPs', 1;
Go
reconfigure with override
Go

declare @domain char(9)
declare @mailsrvr varchar(128)

set @domain = DEFAULT_DOMAIN()

if (@domain = 'ADHCSCINT')
begin
  set @mailsrvr = 'smtp.hcscint.net'
end

if (@domain = 'ADHCSCTST')
begin
  set @mailsrvr = 'smtp.hcscint.net'
end

if (@domain = 'ADHCSCDEV')
begin
-- set @mailsrvr = 'glsmtp01.hcscint.net'
set @mailsrvr = 'smtp.hcscint.net'
end


--if (@domain = 'ADHCSCDEV')
--begin
--  set @mailsrvr = 'smtp.fyiblue.com'
--end


if not exists( SELECT * FROM msdb.dbo.sysmail_account
where name = 'CSDBA-Alerts Mailbox')
begin
EXECUTE msdb.dbo.sysmail_add_account_sp 
@account_name = 'CSDBA-Alerts Mailbox', 
@description = 'Alerts on-call', 
@email_address = 'CSDBA-Alerts@hcsc.com', 
@replyto_address = 'CSDBA-Alerts@hcsc.com', 
@display_name = 'CSDBA-Alerts@hcsc', 
@mailserver_name = @mailsrvr  
end






-- Create a Database Mail profile 
if not exists( SELECT * FROM msdb.dbo.sysmail_profile  
where name = 'CSDBA-Alerts')
begin
EXECUTE msdb.dbo.sysmail_add_profile_sp 
@profile_name = 'CSDBA-Alerts', 
@description = 'For alerts which will page the on-call.'  
end
-- Create a Database Mail account
 
 
 

 


-- Add the account to the profile 
if not exists( select 1 from msdb.dbo.sysmail_profileaccount  mpa join msdb.dbo.sysmail_account a on mpa.account_id = a.account_id
join msdb.dbo.sysmail_profile mp on mpa.profile_id = mp.profile_id
where mp.name = 'CSDBA-Alerts' and a.name = 'CSDBA-Alerts Mailbox')
begin
EXECUTE msdb.dbo.sysmail_add_profileaccount_sp 
@profile_name = 'CSDBA-Alerts', 
@account_name = 'CSDBA-Alerts Mailbox', 
@sequence_number =1  
end
-- Grant access to the profile to the DBMailUsers role 
if not exists( SELECT 1 FROM msdb.dbo.sysmail_profile  
where name = 'CSDBA-Alerts')
begin
EXECUTE msdb.dbo.sysmail_add_principalprofile_sp 
@profile_name = 'CSDBA-Alerts', 
@principal_id = 0, 
@is_default = 1  
end

--Print create new profile for warning message.
if not exists( SELECT 1 FROM msdb.dbo.sysmail_profile
where name = 'CSDBA-Warnings')
begin
EXECUTE msdb.dbo.sysmail_add_profile_sp 
@profile_name = 'CSDBA-Warnings', 
@description = 'Warnings alerts which will page the on-call.'  
end
-- Create a Database Mail account 
if not exists( SELECT 1 FROM msdb.dbo.sysmail_account
where name = 'CSDBA-Warnings Mailbox')
begin
EXECUTE msdb.dbo.sysmail_add_account_sp 
@account_name = 'CSDBA-Warnings Mailbox', 
@description = 'Warnings message for on-call', 
@email_address = 'CSDBA-Alerts@hcsc.com', 
@replyto_address = 'CSDBA-Alerts@hcsc.com', 
@display_name = 'CSDBA-Warnings@hcsc.com', 
@mailserver_name = @mailsrvr  
end

 
-- Add the account to the profile 
if not exists( select 1 from msdb.dbo.sysmail_profileaccount  mpa join msdb.dbo.sysmail_account a on mpa.account_id = a.account_id
join msdb.dbo.sysmail_profile mp on mpa.profile_id = mp.profile_id
where mp.name = 'CSDBA-Alerts' and a.name = 'CSDBA-Alerts Mailbox')
begin
EXECUTE msdb.dbo.sysmail_add_profileaccount_sp 
@profile_name = 'CSDBA-Alerts', 
@account_name = 'CSDBA-Alerts Mailbox', 
@sequence_number =1  
end
if not exists ( select 1 from msdb.dbo.sysmail_profileaccount  mpa join msdb.dbo.sysmail_account a on mpa.account_id = a.account_id
join msdb.dbo.sysmail_profile mp on mpa.profile_id = mp.profile_id
where mp.name =  'CSDBA-Warnings' and a.name ='CSDBA-Warnings Mailbox')
begin
EXECUTE msdb.dbo.sysmail_add_profileaccount_sp 
@profile_name = 'CSDBA-Warnings', 
@account_name = 'CSDBA-Warnings Mailbox',  
@sequence_number =1  
end
 
 
if not exists( SELECT * FROM msdb.dbo.sysmail_profile  
where name = 'APPDBPROFILE')
begin
EXECUTE msdb.dbo.sysmail_add_profile_sp 
@profile_name = 'APPDBPROFILE', 
@description = 'For application team usage.'  
end
if not exists( SELECT * FROM msdb.dbo.sysmail_account
where name = 'APPDBPROFILE Mail box')
begin
EXECUTE msdb.dbo.sysmail_add_account_sp 
@account_name = 'APPDBPROFILE Mail box', 
@description = 'Application team usage', 
@email_address = 'App_DatabaseMail@hcsc.com', 
@display_name = 'APP Database Mail', 
@mailserver_name = @mailsrvr 
end

 

EXECUTE msdb.dbo.sysmail_configure_sp
    'MaxFileSize', 8388608 

-- Add the account to the profile 
if not exists( select 1 from msdb.dbo.sysmail_profileaccount  mpa join msdb.dbo.sysmail_account a on mpa.account_id = a.account_id
join msdb.dbo.sysmail_profile mp on mpa.profile_id = mp.profile_id
where mp.name = 'APPDBPROFILE' and a.name =  'APPDBPROFILE Mail box' )
begin
EXECUTE msdb.dbo.sysmail_add_profileaccount_sp 
@profile_name =  'APPDBPROFILE' , 
@account_name =  'APPDBPROFILE Mail box' , 
@sequence_number =1  
 
end
-- Grant access to the profile to the DBMailUsers role 
if not exists( SELECT 1 FROM msdb.dbo.sysmail_profile  
where name = 'APPDBPROFILE')
begin
EXECUTE msdb.dbo.sysmail_add_principalprofile_sp 
@profile_name ='APPDBPROFILE', 
@principal_id = 0, 
@is_default = 1  
end
--default public profile for users in 
if not exists(select   1  from msdb.dbo.sysmail_principalprofile  mpa join msdb.dbo.sysmail_profile mp on mpa.profile_id = mp.profile_id
where   mp.name =  'APPDBPROFILE' )
begin
EXECUTE msdb.dbo.sysmail_add_principalprofile_sp
    @principal_name = 'public',
    @profile_name ='APPDBPROFILE',
    @is_default = 1 
end

SELECT * FROM msdb.dbo.sysmail_profile 
SELECT * FROM msdb.dbo.sysmail_account 


Go

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[spm_sendmail]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[spm_sendmail]
Go


CREATE  PROCEDURE [dbo].[spm_sendmail]       
@From varchar(100),       
@To varchar(1000),       
@Subject varchar(256),       
@Body varchar(4000),    
@Attachments varchar(8000) = NULL  ,
@copyemail varchar(2000) =NULL,  
@BlindCopyrecipients   varchar(2000) = NULL  ,
@body_format   varchar(20) = 'TEXT'      -- valid values are  'TEXT' and 'HTML', default 'TEXT'  -- [added PRH 2/11/2008]   
       
AS  
Declare @iSubject  varchar(500)  

Set @iSubject= 'This Email was sent from Server :'+ @@servername+' ' +  @Subject  
if ltrim(rtrim(@Body ))is null or ltrim(rtrim(@Body ))=''
set @Body = @Subject
if ltrim(rtrim(@Attachments ))is not null or ltrim(rtrim(@Attachments ))=''
begin
  EXEC msdb.dbo.sp_send_dbmail  @profile_name = 'APPDBPROFILE' ,@recipients= @To ,  
    @subject =  @iSubject,
    @body = @Body,
	@file_attachments=@Attachments,
	@copy_recipients = @copyemail,
	@blind_copy_recipients  = @BlindCopyrecipients,
	@body_format = @body_format
 end
else 
	begin
	  EXEC msdb.dbo.sp_send_dbmail  @profile_name = 'APPDBPROFILE' ,@recipients= @To,  
    @subject =  @iSubject,
    @body = @Body ,
    @copy_recipients = @copyemail,
	@blind_copy_recipients  = @BlindCopyrecipients,
	@body_format = @body_format 
end

GO

/*

   EXEC msdb.dbo.sp_send_dbmail  @profile_name = 'APPDBPROFILE' ,@recipients= 'CSDBA-Alerts@hcsc.com',  
    @subject =  'This is Test Email for DB Mail configuration please ignore this email' ,  
    @body =  'This is Test Email for DB Mail configuration please ignore this email'   
*/

GRANT EXECUTE ON [dbo].[spm_sendmail] TO [public]
GO  
    
  
