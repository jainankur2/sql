USE [DBA]
GO

/****** Object:  Trigger [dbo].[CommandLog_tr_update]    Script Date: 4/17/2017 2:43:20 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



CREATE TRIGGER [dbo].[CommandLog_tr_update]
ON [dbo].[CommandLog]
AFTER UPDATE
AS
   declare @ID int, @counter int = 0
   select @ID = d.ID
      from deleted d
    join inserted i on (i.ID = d.ID)


   Select @counter = 1 from CommandLog where ID = @ID and ErrorNumber <> 0
   if @counter = 1
     begin
	   declare @mailbody NVARCHAR(255), @queryvar NVARCHAR(MAX)
          set @mailbody = '[DBA].dbo.CommandLog error reported: '+@@servername
		  set @queryvar = 'set nocount on; create table #tmp (ID int identity(1,1), col1 varchar(max)); 
	     insert into #tmp select top 1 ''ID = ''+convert(varchar(10),ID) from [DBA].dbo.CommandLog WITH (NOLOCK) where id ='+CAST(@ID AS VARCHAR)+' and ErrorNumber <> 0;
         insert into #tmp select top 1 ''DatabaseName = ''+ISNULL(DatabaseName,''N/A'') from [DBA].dbo.CommandLog WITH (NOLOCK) where id ='+CAST(@ID AS VARCHAR)+' and ErrorNumber <> 0;
         insert into #tmp select top 1 ''SchemaName = ''+ISNULL(SchemaName,''N/A'') from [DBA].dbo.CommandLog WITH (NOLOCK) where id ='+CAST(@ID AS VARCHAR)+' and ErrorNumber <> 0;
         insert into #tmp select top 1 ''ObjectName = ''+ISNULL(ObjectName,''N/A'') from [DBA].dbo.CommandLog WITH (NOLOCK) where id ='+CAST(@ID AS VARCHAR)+' and ErrorNumber <> 0;
         insert into #tmp select top 1 ''ObjectType = ''+ISNULL(convert(varchar(10),ObjectType),''N/A'') from [DBA].dbo.CommandLog WITH (NOLOCK) where id ='+CAST(@ID AS VARCHAR)+' and ErrorNumber <> 0;
         insert into #tmp select top 1 ''IndexName = ''+ISNULL(IndexName,''N/A'') from [DBA].dbo.CommandLog WITH (NOLOCK) where id ='+CAST(@ID AS VARCHAR)+' and ErrorNumber <> 0;
         insert into #tmp select top 1 ''IndexType = ''+ISNULL(cast(IndexType as varchar),''N/A'') from [DBA].dbo.CommandLog WITH (NOLOCK) where id ='+CAST(@ID AS VARCHAR)+' and ErrorNumber <> 0;
         insert into #tmp select top 1 ''StatisticsName = ''+ISNULL(StatisticsName,''N/A'') from [DBA].dbo.CommandLog WITH (NOLOCK) where id ='+CAST(@ID AS VARCHAR)+' and ErrorNumber <> 0;
         insert into #tmp select top 1 ''PartitionNumber = ''+ISNULL(cast(PartitionNumber as varchar),''N/A'') from [DBA].dbo.CommandLog WITH (NOLOCK) where id ='+CAST(@ID AS VARCHAR)+' and ErrorNumber <> 0;
         insert into #tmp select top 1 ''CommandType = ''+ISNULL(CommandType,''N/A'') from [DBA].dbo.CommandLog WITH (NOLOCK) where id ='+CAST(@ID AS VARCHAR)+' and ErrorNumber <> 0;
         insert into #tmp select top 1 ''StartTime = ''+convert(varchar(25),StartTime) from [DBA].dbo.CommandLog WITH (NOLOCK) where id ='+CAST(@ID AS VARCHAR)+' and ErrorNumber <> 0;
         insert into #tmp select top 1 ''EndTime = ''+ISNULL(convert(varchar(25),EndTime),''N/A'') from [DBA].dbo.CommandLog WITH (NOLOCK) where id ='+CAST(@ID AS VARCHAR)+' and ErrorNumber <> 0;
         insert into #tmp select top 1 ''ErrorNumber = ''+ISNULL(convert(varchar(10),ErrorNumber),''N/A'') from [DBA].dbo.CommandLog WITH (NOLOCK) where id ='+CAST(@ID AS VARCHAR)+' and ErrorNumber <> 0;
		 insert into #tmp select top 1 ''''
         insert into #tmp select top 1 ''ErrorMessage = ''+ISNULL(ErrorMessage,''N/A'')  from [DBA].dbo.CommandLog WITH (NOLOCK) where id ='+CAST(@ID AS VARCHAR)+' and ErrorNumber <> 0; 
		 insert into #tmp select top 1 ''''
	     insert into #tmp select top 1 ''Command = ''+ISNULL(Command,''N/A'') from [DBA].dbo.CommandLog WITH (NOLOCK) where id ='+CAST(@ID AS VARCHAR)+' and ErrorNumber <> 0; select col1 from #tmp order by ID; drop table #tmp'

         EXEC msdb.dbo.sp_send_dbmail  @profile_name = 'CSDBA-Alerts' 
    , @recipients = 'hcl_database_mssqlserver@bcbstx.com'
    , @subject =  @mailbody
	, @query = @queryvar
	, @query_result_header = 0
	, @query_result_width = 8192
	, @query_no_truncate = 1
	
	end

GO


