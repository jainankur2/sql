-- This script should be applied only in WTC and PROD servers.

use msdb
go

exec sp_addrole 'AllowJobHistory'
go

revoke exec on  sp_add_job	  to AllowJobHistory
go
revoke exec on  sp_add_jobstep      to AllowJobHistory
go
revoke exec on  sp_add_jobschedule  to AllowJobHistory 
go 
revoke exec on  sp_add_schedule     to AllowJobHistory 
go 
revoke exec on  sp_attach_schedule     to AllowJobHistory 
go 

revoke exec on  sp_update_job           to AllowJobHistory
go
revoke exec on  sp_update_jobstep       to AllowJobHistory
go
revoke exec on  sp_update_jobschedule   to AllowJobHistory 
go 
revoke exec on  sp_update_schedule      to AllowJobHistory 
go 

revoke exec  on  sp_delete_job    	to AllowJobHistory 
go
revoke exec  on  sp_delete_jobstep  	to AllowJobHistory
go
revoke exec  on  sp_delete_jobschedule    to AllowJobHistory 
go
revoke exec  on  sp_delete_schedule       to AllowJobHistory 
go 
revoke exec  on  sp_delete_jobsteplog  	to AllowJobHistory
go

revoke exec on sp_start_job  	to  AllowJobHistory
go
revoke exec on sp_stop_job 	to AllowJobHistory
go

drop schema AllowJobHistory
Go

ALTER ROLE [SQLAgentReaderRole] ADD MEMBER [AllowJobHistory]







