USE [master]
GO

IF   EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_deac_disable_logins_auto_imprv]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_deac_disable_logins_auto_imprv]
go


/****** Object:  StoredProcedure [dbo].[usp_deac_disable_logins_auto_imprv]    Script Date: 04/18/2012 13:26:09 ******/
  
 
 /*
Created by	:  Babu Kondragunta
Create Date :  2008/12/17 9.13am
Description	:  Disable imperva inactive Logins. (SQL2012)
Use			:  This SP is to disable imperva inactive logins
Parameters	: 
			: @servr_machn_id - Server Machine Id is for processing server. 
			: @servr_machn_nm - Server Machine name is for processing server.
			: @instnc_id - SQL Server Instance id for a machine.
			: @status_server_ip - SQL Server Instance IP address for 
									Centerlize server to save staus.
			: @sql_id - Login Id to connect Centerlize server.
			: @sql_pwd - Password to connect Centerlize server.
			: @prc_typ	- Process Tyep --2 for Imperva
			: @rpt_dt	- Report Date
			: @lgn_sta_id - Login Status ID
*/
		
--Example to exec stored procedure:

/*
exec dbo.usp_deac_disable_logins_auto_imprv 
	@servr_machn_id		= 451,
	@servr_machn_nm		= 'DVMSSQL02',	
	@instnc_id			= 587,			
	@status_server_ip	= '10.130.135.14',
	@sql_id				= 'DeacAdmin',
	@sql_pwd			= '',
	@prc_typ			= 2,
	@rpt_dt				= '8/25/2008',
	@lgn_sta_id			= '9,11'

--We need to create this stored procedure on master database on each  SQL2012 Server.
--Once this procedure is created on master database, 
--need to add entry in "systemsp" table on master database
--if we don't add entry on this table, alert will notify to on call DBA that 
--system sp has been modified on master database.

alter table SystemSP
alter column name varchar(50)

insert into master.dbo.SystemSP(id,name,number,colid,text)
select id,'usp_deac_disable_logins_auto_imprv' as name,number,colid,text
from syscomments where id  in ( select id from sysobjects where name = 'usp_deac_disable_logins_auto_imprv')

*/

create procedure [dbo].[usp_deac_disable_logins_auto_imprv]
	@servr_machn_id 	int,
	@servr_machn_nm		varchar(50),
	@instnc_id			int,
	@status_server_ip	varchar(50),
	@sql_id				varchar(10),
	@sql_pwd			varchar(20),
	@prc_typ			int = 2,
	@rpt_dt				smalldatetime,
	@lgn_sta_id			varchar(50)= null
as

set nocount on

declare @opendatasource varchar(250), 
		@openrowset		varchar(1000),
		@sql			varchar(1000),
		@lgn_id			varchar(50),
		@lgn_nm			varchar(50),
		@bdg_id			varchar(8),
		@new_lgn_pwd	varchar(10),
		@err_desc		varchar(255),
		@dbname			varchar(50)
		
/*
		@servr_machn_id 	int,
		@servr_machn_nm		varchar(50),
		@instnc_id			int,
		@status_server_ip	varchar(50),
		@sql_id				varchar(10),
		@sql_pwd			varchar(20),
		@prc_typ			int,
		@rpt_dt				smalldatetime,
		@lgn_sta_id			VARCHAR(50)


select 	@servr_machn_id		= 451,
		@servr_machn_nm		= 'DVMSSQL02',	
		@instnc_id			= 587,			
		@status_server_ip	= '10.130.135.14',
		@sql_id				= 'DeacAdmin',
		@sql_pwd			= '',
		@prc_typ			= 2	,
		@rpt_dt				= '12/09/2008',
		@lgn_sta_id			= '9,5'


*/	

select @err_desc = 'Please check the status file on R:\DEAC\AUTOTERM_IMPRV\TermServerStatus'

set @opendatasource = 'OPENDATASOURCE(''SQLOLEDB'',''Data Source='
						+@status_server_ip+';User ID='+@sql_id+';Password='
						+@sql_pwd+''').DEAC.dbo.'

--Create a  temp table to store inactive logins for processing server

/*
drop table #Imperva_180Days_logins
drop table #object_Owen_logins
drop table #deac_trm_lgn_sta
*/

create table #Imperva_180Days_logins(
	servr_machn_id 	int,
	servr_machn_nm	varchar(50),
	instnc_id		int,
	lgn_id			varchar(50),
	lgn_nm			varchar(60),
	bdg_id			varchar(8),
	rpt_dt			smalldatetime
)

set @sql = 'select '+cast(@servr_machn_id as varchar)+' as servr_machn_id,'''''+@servr_machn_nm+''''' as servr_machn_nm,'
					+cast(@instnc_id as varchar)+' instnc_id,lgn_id,lgn_nm,bdg_id,rpt_dt
			from	DEAC.dbo.deac_imprv_lgn 
			where	servr_machn_id = '+cast (@servr_machn_id as varchar)+' and instnc_id = '+cast (@instnc_id as varchar)+
					' AND CONVERT(VARCHAR(10),rpt_dt,101) = '''''+CONVERT(VARCHAR(10),@rpt_dt,101)+
					''''' and lgn_sta_id '+ CASE WHEN @lgn_sta_id IS NULL THEN 'IS NULL' ELSE  'in ('+@lgn_sta_id+')' END
					+' and lgn_sta is null'			

set @openrowset = 'insert into #Imperva_180Days_logins(servr_machn_id, servr_machn_nm,instnc_id,
						lgn_id,lgn_nm,bdg_id,rpt_dt) 
					select a.* from OPENROWSET('+''''+'SQLOLEDB'+''''+','
						+''''+@status_server_ip+''''+';'+''''
						+@sql_id+''';'''+@sql_pwd+''','''
						+@sql+''''+') as a'
--print 'Openrowset is: '+@openrowset

exec (@openrowset)

--select * from #Imperva_180Days_logins


--Create a temp table to store Login ID's which are own any objects. 
--Those id's should not be DISABLED or DELETED.

--drop table #object_Owen_logins

create table #object_Owen_logins(
	db_nm 	varchar(50),
	lgn_id	varchar(50),
	usr_id	varchar(50),
	own_typ	varchar(50)
)


--Check id's own any objects ...start
--DECLARE @dbname VARCHAR(50), @sql VARCHAR(1000)
DECLARE dbname_cursor CURSOR FOR     
SELECT name FROM sys.databases 
WHERE DATABASEPROPERTYEX(name,'STATUS') = 'ONLINE'
ORDER BY name
  
OPEN dbname_cursor    
FETCH next FROM dbname_cursor INTO @dbname    
    
WHILE @@FETCH_STATUS = 0    
	BEGIN    
		SELECT @sql = 'SELECT  DISTINCT '''+@dbname+''' AS db_nm, SUSER_SNAME(su.sid) AS lgn_id,
										USER_NAME(OBJECTPROPERTY( so.object_id, ''ownerid'' )) AS usr_id, ''Object'' AS own_typ 
						FROM ['+@dbname+'].sys.objects so (Nolock) INNER JOIN ['+@dbname+'].sys.database_principals su (Nolock) ON
								(user_name(objectproperty( so.object_id, ''ownerid'' )) = su.name and su.type = ''S'')
								AND SUSER_SNAME(su.sid) IS NOT NULL AND su.name <> ''dbo'' '
		INSERT INTO #object_Owen_logins (db_nm,lgn_id,usr_id,own_typ)
 		EXEC (@sql)   
 		--select @sql

		FETCH NEXT FROM dbname_cursor INTO @dbname    
    END    
    
CLOSE dbname_cursor    
DEALLOCATE dbname_cursor  
--Check id's own any objects ...over 


INSERT INTO #object_Owen_logins (db_nm,lgn_id,usr_id,own_typ)
--Check if id has any job
SELECT DISTINCT 'msdb' AS db_nm,
			CASE
			WHEN CHARINDEX('\',SUSER_SNAME(owner_sid)) = 0 THEN SUSER_SNAME(owner_sid) 
			ELSE SUBSTRING(SUSER_SNAME(owner_sid),CHARINDEX('\',SUSER_SNAME(owner_sid))+1,LEN(SUSER_SNAME(owner_sid))) 
			END AS lgn_id,NULL AS usr_id,'Job' AS own_typ 
FROM msdb.dbo.sysjobs (Nolock) 
UNION
--Check if id has any DTS 
SELECT DISTINCT 'msdb' AS db_nm,
			CASE
			WHEN CHARINDEX('\',ownersid) = 0 THEN SUSER_SNAME(ownersid )
			ELSE SUBSTRING(SUSER_SNAME(ownersid),CHARINDEX('\',SUSER_SNAME(ownersid))+1,LEN(SUSER_SNAME(ownersid))) 
			END AS lgn_id, NULL AS usr_id,'DTS' AS own_typ
FROM msdb.dbo.sysssispackages (Nolock)
UNION
--Check if id has any Database
SELECT name db_nm,
		CASE 
		WHEN CHARINDEX('\',SUSER_SNAME(sid)) = 0 THEN SUSER_SNAME(sid) 
		ELSE SUBSTRING(SUSER_SNAME(sid),CHARINDEX('\',SUSER_SNAME(sid))+1,LEN(SUSER_SNAME(sid)))
		END AS lgn_id, NULL AS usr_id,'DB_Owner' AS own_typ  
FROM master.sys.sysdatabases (Nolock)
ORDER BY own_typ,db_nm,lgn_id

--select * from #object_owen_logins

--Before either Disable or Delete process starts, we need to keep track of id's which are 
--own objects Id own Objects or deleted before statred cleaning process...
--need to insert in table DEAC.dbo.deac_trm_lgn_sta on MSSQL1

create table #deac_trm_lgn_sta(
	servr_machn_id	int,
	servr_machn_nm	varchar(100),
	instnc_id		int,
	lgn_id			varchar(50),
	lgn_nm			varchar(50),
	bdg_id			varchar(50),
	rpt_dt			smalldatetime,
	lgn_sta			varchar(50),
	hld_dt			smalldatetime,
	dis_dt			smalldatetime,
	prc_typ			tinyint,
	remarks			varchar(1000)
)

--Need to keep these id because used by application

INSERT INTO #deac_trm_lgn_sta (servr_machn_id,servr_machn_nm,instnc_id,lgn_id,lgn_nm,rpt_dt,lgn_sta,hld_dt,dis_dt,prc_typ,remarks)
SELECT 	servr_machn_id,servr_machn_nm,instnc_id,lgn_id,lgn_nm,rpt_dt, 'OnHold' AS lgn_sta,GETDATE() AS hld_dt,NULL AS dis_dt, 
		@prc_typ,'Id own objects. Pl. change object owner first.' AS remarks
FROM  #Imperva_180Days_logins 
WHERE lgn_id IN (SELECT lgn_id FROM  #object_Owen_logins)
UNION --Need to keep these id because used by application
SELECT servr_machn_id, servr_machn_nm,instnc_id,lgn_id,lgn_nm,rpt_dt, 'Deleted' AS lgn_sta,NULL AS hld_dt,NULL AS dis_dt,@prc_typ, 
			'Already deleted. Id deleted before start disabling process.' AS remarks
FROM  #Imperva_180Days_logins 
WHERE lgn_id NOT IN (SELECT name FROM sys.sql_logins (NoLock))
ORDER BY lgn_sta

--select * from #deac_trm_lgn_sta                   

--ID does not own any objects...need to be DISABLE(Change password)

DECLARE mtch_lgn_cursor CURSOR FOR 
SELECT DISTINCT servr_machn_id, servr_machn_nm,instnc_id,lgn_id,lgn_nm,rpt_dt 
FROM  	#Imperva_180Days_logins 
WHERE 	lgn_id NOT IN (SELECT DISTINCT lgn_id FROM  #object_Owen_logins WHERE lgn_id IS NOT NULL)
		AND lgn_id IN (SELECT name FROM sys.sql_logins (NoLock))


OPEN mtch_lgn_cursor
FETCH next FROM mtch_lgn_cursor INTO @servr_machn_id,@servr_machn_nm,@instnc_id,@lgn_id,@lgn_nm,@rpt_dt

WHILE @@FETCH_STATUS = 0
	BEGIN -- Start of cursor begin
		BEGIN TRY
			SELECT @sql = 'ALTER LOGIN '+@lgn_id+' DISABLE;'
			--PRINT @sql
			EXEC (@sql)
			INSERT INTO dbo.#deac_trm_lgn_sta(servr_machn_id,servr_machn_nm,instnc_id,lgn_id,lgn_nm,rpt_dt,lgn_sta,dis_dt,prc_typ,remarks)
			SELECT @servr_machn_id,@servr_machn_nm,@instnc_id,@lgn_id,@lgn_nm,@rpt_dt,'Imp_Disabled' AS lgn_sta,GETDATE()dis_dt, @prc_typ,@sql
		END TRY
		BEGIN CATCH
			INSERT INTO dbo.#deac_trm_lgn_sta(servr_machn_id,servr_machn_nm,instnc_id,lgn_id,lgn_nm,rpt_dt,lgn_sta,dis_dt,prc_typ,remarks)
			SELECT @servr_machn_id,@servr_machn_nm,@instnc_id,@lgn_id,@lgn_nm,@rpt_dt,'Error' AS lgn_sta,GETDATE()dis_dt, @prc_typ,
					LEFT(ERROR_MESSAGE(),900)+@err_desc AS remarks
		END CATCH

      FETCH next FROM mtch_lgn_cursor INTO @servr_machn_id,@servr_machn_nm,@instnc_id,@lgn_id,@lgn_nm,@rpt_dt
	END -- end of cursor begin

CLOSE mtch_lgn_cursor
DEALLOCATE mtch_lgn_cursor

--SELECT * FROM #deac_trm_lgn_sta

-- Below step will insert records into DEAC.dbo.deac_trm_lgn_sta which is on MSSQL1 server.
set nocount off

select @sql = '
insert into '+@opendatasource+'deac_trm_lgn_sta(SERVR_MACHN_ID,SERVR_MACHN_NM,INSTNC_ID,
								LGN_ID,LGN_NM,LGN_STA,TRM_DT,DIS_DT,HLD_DT,PRC_TYP,REMARKS)	
			select servr_machn_id, servr_machn_nm,instnc_id,lgn_id,lgn_nm,lgn_sta,rpt_dt as trm_dt,
							dis_dt,hld_dt,prc_typ,remarks 
			from #deac_trm_lgn_sta'

--print ' deac_trm_lgn_sta SQL is '+@sql
exec (@sql)

go
grant exec on usp_deac_disable_logins_auto_imprv to public
go