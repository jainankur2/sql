use master
go

declare @domain char(9)

set @domain = DEFAULT_DOMAIN()

if @domain = 'adhcscdev'
begin
 -- create [adhcscdev\command center] login 
 if not exists (select name from sys.syslogins where name = 'adhcscdev\command center')
 CREATE LOGIN [adhcscdev\command center] FROM WINDOWS 
 WITH DEFAULT_DATABASE=[msdb], 
 DEFAULT_LANGUAGE=[us_english]
end

if @domain = 'adhcsctst'
begin
 -- create [adhcsctst\command center] login 
 if not exists (select name from sys.syslogins where name = 'adhcsctst\command center')
 CREATE LOGIN [adhcsctst\command center] FROM WINDOWS 
 WITH DEFAULT_DATABASE=[msdb], 
 DEFAULT_LANGUAGE=[us_english]
end

if @domain = 'adhcscint'
begin
 -- create [adhcscint\command center] login 
 if not exists (select name from sys.syslogins where name = 'adhcscint\command center')
 CREATE LOGIN [adhcscint\command center] FROM WINDOWS 
 WITH DEFAULT_DATABASE=[msdb], 
 DEFAULT_LANGUAGE=[us_english]
end
GO

USE msdb
GO

declare @domain char(9)

set @domain = DEFAULT_DOMAIN()

if @domain = 'adhcscdev'
begin
 if not exists (select name from sysusers where name = 'adhcscdev\command center')
 CREATE USER [adhcscdev\command center] FOR LOGIN [adhcscdev\command center]
 EXEC SP_ADDROLEMEMBER 'sqlagentoperatorrole', 'adhcscdev\command center'
 EXEC SP_ADDROLEMEMBER 'DEV_APP_RD', 'adhcscdev\command center'
end

if @domain = 'adhcsctst'
begin
 if not exists (select name from sysusers where name = 'adhcsctst\command center')
 CREATE USER [adhcsctst\command center] FOR LOGIN [adhcsctst\command center]
 EXEC SP_ADDROLEMEMBER 'sqlagentoperatorrole', 'adhcsctst\command center'
 EXEC SP_ADDROLEMEMBER 'TEST_APP_RD', 'adhcsctst\command center'
end

if @domain = 'adhcscint'
begin
 if not exists (select name from sysusers where name = 'adhcscint\command center')
 CREATE USER [adhcscint\command center] FOR LOGIN [adhcscint\command center]
 EXEC SP_ADDROLEMEMBER 'sqlagentoperatorrole', 'adhcscint\command center'
 EXEC SP_ADDROLEMEMBER 'PROD_APP_RD', 'adhcscint\command center';
end
GO