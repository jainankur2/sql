/*
For Development Environment only
Pl. run this is in master database and it will create role in all databases other than System databases
Created by : Harsh sahal on 02/12/2009
*/

use master
go

-- DEV SP

create procedure dbo.sp_Add_Security_Roles_DEV
as

	--*******************************************DEVELOPERS***********************************************************************************
	--DEVELOPERS:
		
	--Read only Access

	if not exists (select name from sys.database_principals where type = 'R' and name = 'DEV_DEVEL_RD'  and is_fixed_role = 0)  
			begin
				CREATE ROLE DEV_DEVEL_RD AUTHORIZATION [dbo];
				exec sp_addrolemember @rolename = 'db_datareader', @membername = 'DEV_DEVEL_RD'
			end
		else
			begin
				print 'DEV_DEVEL_RD role already exists on database.'	
			end

	--Read/Write Access
		
		if not exists (select name from sys.database_principals where type = 'R' and name = 'DEV_DEVEL_RW'  and is_fixed_role = 0)  
			begin
				CREATE ROLE DEV_DEVEL_RW AUTHORIZATION [dbo];
				exec sp_addrolemember @rolename = 'db_datareader', @membername = 'DEV_DEVEL_RW'
				exec sp_addrolemember @rolename = 'db_datawriter', @membername = 'DEV_DEVEL_RW'
			end
		else
			begin
				print 'DEV_DEVEL_RW role already exists on database.'		
			end

	--Read/Write/Execute access --Not as per guidlines but Tiashia/Racquel wanted to keep in Dev only

	if not exists (select name from sys.database_principals where type = 'R' and name = 'DEV_DEVEL_RWX'  and is_fixed_role = 0)  
			begin
				CREATE ROLE DEV_DEVEL_RWX AUTHORIZATION [dbo];
				exec sp_addrolemember @rolename = 'db_datareader', @membername = 'DEV_DEVEL_RWX'
				exec sp_addrolemember @rolename = 'db_datawriter', @membername = 'DEV_DEVEL_RWX'
				GRANT EXECUTE TO DEV_DEVEL_RWX
			end
		else
			begin
				print 'DEV_DEVEL_RWX role already exists on database.'	
			end

	--Read/Write/DDLAdmin access

	if not exists (select name from sys.database_principals where type = 'R' and name = 'DEV_DEVEL_RWDDL'  and is_fixed_role = 0)  
			begin
				CREATE ROLE DEV_DEVEL_RWDDL AUTHORIZATION [dbo];
				exec sp_addrolemember @rolename = 'db_datareader', @membername = 'DEV_DEVEL_RWDDL'
				exec sp_addrolemember @rolename = 'db_datawriter', @membername = 'DEV_DEVEL_RWDDL'
				exec sp_addrolemember @rolename = 'db_ddladmin', @membername = 'DEV_DEVEL_RWDDL'
			end
		else
			begin
				print 'DEV_DEVEL_RWDDL role already exists on database.'	
			end

--Database Owner 

		if not exists (select name from sys.database_principals where type = 'R' and name = 'DEV_DEVEL_DBO'  and is_fixed_role = 0)  
			begin
				CREATE ROLE DEV_DEVEL_DBO AUTHORIZATION [dbo];
				exec sp_addrolemember @rolename = 'db_owner', @membername = 'DEV_DEVEL_DBO'
			end
		else
			begin
				print 'DEV_DEVEL_DBO role already exists on database.'
			end
		
	--*******************************************USER***********************************************************************************
	--USERS

	--Read only Access

	if not exists (select name from sys.database_principals where type = 'R' and name = 'DEV_USER_RD'  and is_fixed_role = 0)  
			begin
				CREATE ROLE DEV_USER_RD AUTHORIZATION [dbo];
				exec sp_addrolemember @rolename = 'db_datareader', @membername = 'DEV_USER_RD'
			end
		else
			begin
				print 'DEV_USER_RD role already exists on database.'	
			end
	--Read/Write Access
		
		if not exists (select name from sys.database_principals where type = 'R' and name = 'DEV_USER_RW'  and is_fixed_role = 0)  
			begin
				CREATE ROLE DEV_USER_RW AUTHORIZATION [dbo];
				exec sp_addrolemember @rolename = 'db_datareader', @membername = 'DEV_USER_RW'
				exec sp_addrolemember @rolename = 'db_datawriter', @membername = 'DEV_USER_RW'
			end
		else
			begin
				print 'DEV_USER_RW role already exists on database.'		
			end

	--***********************************************APPLICATION*******************************************************************************
	--APPLICATION IDs:

	--Read only Access

	if not exists (select name from sys.database_principals where type = 'R' and name = 'DEV_APP_RD'  and is_fixed_role = 0)  
			begin
				CREATE ROLE DEV_APP_RD AUTHORIZATION [dbo];
				exec sp_addrolemember  @rolename = 'db_datareader', @membername = 'DEV_APP_RD'
			end
		else
			begin
				print 'DEV_APP_RD role already exists on database.'		
			end

	--Read/Write Access
		
		if not exists (select name from sys.database_principals where type = 'R' and name = 'DEV_APP_RW'  and is_fixed_role = 0)  
			begin
				CREATE ROLE DEV_APP_RW AUTHORIZATION [dbo];
				exec sp_addrolemember @rolename = 'db_datareader', @membername = 'DEV_APP_RW'
				exec sp_addrolemember @rolename = 'db_datawriter', @membername = 'DEV_APP_RW'
			end
		else
			begin
				print 'DEV_APP_RW role already exists on database.'		
			end

	--Read/Execute Access -- not as per guidlines

	if not exists (select name from sys.database_principals where type = 'R' and name = 'DEV_APP_RX'  and is_fixed_role = 0)  
			begin
				CREATE ROLE DEV_APP_RX AUTHORIZATION [dbo];
				exec sp_addrolemember @rolename = 'db_datareader', @membername = 'DEV_APP_RX'
				GRANT EXECUTE TO DEV_APP_RX
			end
		else
			begin
				print 'DEV_APP_RX role already exists on database.'	
			end


	--Read/Write/Execute Access -- not as per guidlines

	if not exists (select name from sys.database_principals where type = 'R' and name = 'DEV_APP_RWX'  and is_fixed_role = 0)  
			begin
				CREATE ROLE DEV_APP_RWX AUTHORIZATION [dbo];
				exec sp_addrolemember @rolename = 'db_datareader', @membername = 'DEV_APP_RWX'
				exec sp_addrolemember @rolename = 'db_datawriter', @membername = 'DEV_APP_RWX'
				GRANT EXECUTE TO DEV_APP_RWX
			end
		else
			begin
				print 'DEV_APP_RWX role already exists on database.'	
			end


	--Read/Write/DDL

	if not exists (select name from sys.database_principals where type = 'R' and name = 'DEV_APP_RWDDL'  and is_fixed_role = 0)  
		begin
				CREATE ROLE DEV_APP_RWDDL AUTHORIZATION [dbo];
				exec sp_addrolemember @rolename = 'db_datareader', @membername = 'DEV_APP_RWDDL'
				exec sp_addrolemember @rolename = 'db_datawriter', @membername = 'DEV_APP_RWDDL'
				exec sp_addrolemember @rolename = 'db_ddladmin', @membername = 'DEV_APP_RWDDL'
			end
		else
			begin
				print 'DEV_APP_RWDDL role already exists on database.'		
			end
		
	--Database Owner 

		if not exists (select name from sys.database_principals where type = 'R' and name = 'DEV_APP_DBO'  and is_fixed_role = 0)  
			begin
				CREATE ROLE DEV_APP_DBO AUTHORIZATION [dbo];
				exec sp_addrolemember @rolename = 'db_owner', @membername = 'DEV_APP_DBO'
			end
		else
			begin
				print 'DEV_APP_DBO role already exists on database.'		
			end

GO  -- End of DEV SP

 


--  TEST SP
use master
go


create procedure dbo.sp_Add_Security_Roles_TST
as
--***************************************DEVELOPERS***************************************************************************************
--DEVELOPERS:

--Read only Access

if not exists (select name from sys.database_principals where type = 'R' and name = 'TEST_DEVEL_RD'  and is_fixed_role = 0)  
		begin
			CREATE ROLE TEST_DEVEL_RD AUTHORIZATION [dbo];
			exec sp_addrolemember @rolename = 'db_datareader', @membername = 'TEST_DEVEL_RD'
		end
	else
		begin
			print 'TEST_DEVEL_RD role already exists on database.'				
		end

--***************************************USERS***************************************************************************************

--USERS:

--Read only Access

if not exists (select name from sys.database_principals where type = 'R' and name = 'TEST_USER_RD'  and is_fixed_role = 0)  
		begin
			CREATE ROLE TEST_USER_RD AUTHORIZATION [dbo];
			exec sp_addrolemember @rolename = 'db_datareader', @membername = 'TEST_USER_RD'
		end
	else
		begin
			print 'TEST_USER_RD role already exists on database.'				
		end	

	
--Read/Write Access
	
	if not exists (select name from sys.database_principals where type = 'R' and name = 'TEST_USER_RW'  and is_fixed_role = 0)  
		begin
			CREATE ROLE TEST_USER_RW AUTHORIZATION [dbo];
			exec sp_addrolemember @rolename = 'db_datareader', @membername = 'TEST_USER_RW'
			exec sp_addrolemember @rolename = 'db_datawriter', @membername = 'TEST_USER_RW'
		end
	else
		begin
			print 'TEST_USER_RW role already exists on database.'
		end
--***************************************APPLICATION***************************************************************************************

--APPLICATION IDs:

--Read only Access

if not exists (select name from sys.database_principals where type = 'R' and name = 'TEST_APP_RD'  and is_fixed_role = 0)  
		begin
			CREATE ROLE TEST_APP_RD AUTHORIZATION [dbo];
			exec sp_addrolemember @rolename = 'db_datareader', @membername = 'TEST_APP_RD'
		end
	else
		begin
			print 'TEST_APP_RD role already exists on database.'	
		end
--Read/Write Access
	
	if not exists (select name from sys.database_principals where type = 'R' and name = 'TEST_APP_RW'  and is_fixed_role = 0)  
		begin
			CREATE ROLE TEST_APP_RW AUTHORIZATION [dbo];
			exec sp_addrolemember @rolename = 'db_datareader', @membername = 'TEST_APP_RW'
			exec sp_addrolemember @rolename = 'db_datawriter', @membername = 'TEST_APP_RW'
		end
	else
		begin
			print 'TEST_APP_RW role already exists on database.'
		end

--Read/Write Access/DDL Access..Application
	
	if not exists (select name from sys.database_principals where type = 'R' and name = 'TEST_APP_RWDDL'  and is_fixed_role = 0)  
		begin
			CREATE ROLE TEST_APP_RWDDL AUTHORIZATION [dbo];
			exec sp_addrolemember @rolename = 'db_datareader',	@membername = 'TEST_APP_RWDDL'
			exec sp_addrolemember @rolename = 'db_datawriter',	@membername = 'TEST_APP_RWDDL'
			exec sp_addrolemember @rolename = 'db_ddladmin',	@membername = 'TEST_APP_RWDDL'
		end
	else
		begin
			print 'TEST_APP_RWDDL role already exists on database.'
		end
--Read/Execute Access -- not as per guidlines

	if not exists (select name from sys.database_principals where type = 'R' and name = 'TEST_APP_RX'  and is_fixed_role = 0)  
			begin
				CREATE ROLE TEST_APP_RX AUTHORIZATION [dbo];
				exec sp_addrolemember @rolename = 'db_datareader', @membername = 'TEST_APP_RX'
				GRANT EXECUTE TO TEST_APP_RX
			end
		else
			begin
				print 'TEST_APP_RX role already exists on database.'	
			end
--Read/Write/Ececute Access..Execute permission can be added as required for App Id's -- not as per guidlines
	
	if not exists (select name from sys.database_principals where type = 'R' and name = 'TEST_APP_RWX'  and is_fixed_role = 0)  
		begin
			CREATE ROLE TEST_APP_RWX AUTHORIZATION [dbo];
			exec sp_addrolemember @rolename = 'db_datareader', @membername = 'TEST_APP_RWX'
			exec sp_addrolemember @rolename = 'db_datawriter', @membername = 'TEST_APP_RWX'
			GRANT EXECUTE TO TEST_APP_RWX
		end
	else
		begin
			print 'TEST_APP_RWX role already exists on database.'
		end

	
--Database Owner 

	if not exists (select name from sys.database_principals where type = 'R' and name = 'TEST_APP_DBO'  and is_fixed_role = 0)  
		begin
			CREATE ROLE TEST_APP_DBO AUTHORIZATION [dbo];
			exec sp_addrolemember @rolename = 'db_owner', @membername = 'TEST_APP_DBO'
		end
	else
		begin
			print 'TEST_APP_DBO role already exists on database.'
		end
		
go  -- End of TEST SP.


-- Prod SP

/*
For Production Environment only
Pl. run this script in master database and it will create role in all databases other than System databases.
Create by : Harsh sahal on 02/12/2009
*/

use master
go

-- Prod SP

create procedure dbo.sp_Add_Security_Roles_PRD
as

--***************************************DEVELOPERS***************************************************************************************
--DEVELOPERS:
	
	--Read Access
	
	if not exists (select name from sys.database_principals where type = 'R' and name = 'PROD_DEVEL_RD'  and is_fixed_role = 0)  
		begin
			CREATE ROLE PROD_DEVEL_RD AUTHORIZATION [dbo];
			exec sp_addrolemember @rolename = 'db_datareader', @membername = 'PROD_DEVEL_RD'
		end
	else
		begin
			print 'PROD_DEVEL_RD role already exists on database.'
		end
--***************************************USERS***************************************************************************************

--Read Access...USERS:
	
	if not exists (select name from sys.database_principals where type = 'R' and name = 'PROD_USER_RD'  and is_fixed_role = 0)  
		begin
			CREATE ROLE PROD_USER_RD AUTHORIZATION [dbo];
			exec sp_addrolemember @rolename = 'db_datareader', @membername = 'PROD_USER_RD'
		end
	else
		begin
			print 'PROD_USER_RD role already exists on database.'
		end


--Read/Write Access...USERS:
	
	if not exists (select name from sys.database_principals where type = 'R' and name = 'PROD_USER_RW'  and is_fixed_role = 0)  
		begin
			CREATE ROLE PROD_USER_RW AUTHORIZATION [dbo];
			exec sp_addrolemember @rolename = 'db_datareader', @membername = 'PROD_USER_RW'
			exec sp_addrolemember @rolename = 'db_datawriter', @membername = 'PROD_USER_RW'
		end
	else
		begin
			print 'PROD_USER_RW role already exists on database.'
		end

--***************************************APPLICATIONS***************************************************************************************
--APPLICATION IDs:


--Read Access...Application
	
	if not exists (select name from sys.database_principals where type = 'R' and name = 'PROD_APP_RD'  and is_fixed_role = 0)  
		begin
			CREATE ROLE PROD_APP_RD AUTHORIZATION [dbo];
			exec sp_addrolemember @rolename = 'db_datareader', @membername = 'PROD_APP_RD'
		end
	else
		begin
			print 'PROD_APP_RD role already exists on database.'
		end

--Read/Write Access...Application
	
	if not exists (select name from sys.database_principals where type = 'R' and name = 'PROD_APP_RW'  and is_fixed_role = 0)  
		begin
			CREATE ROLE PROD_APP_RW AUTHORIZATION [dbo];
			exec sp_addrolemember @rolename = 'db_datareader',  @membername = 'PROD_APP_RW'
			exec sp_addrolemember @rolename = 'db_datawriter',  @membername = 'PROD_APP_RW'
		end
	else
		begin
			print 'PROD_APP_RW role already exists on database.'
		end

--Read/Write Access/DDL ..Application
	
	if not exists (select name from sys.database_principals where type = 'R' and name = 'PROD_APP_RWDDL'  and is_fixed_role = 0)  
		begin
			CREATE ROLE PROD_APP_RWDDL AUTHORIZATION [dbo];
			exec sp_addrolemember @rolename = 'db_datareader',	@membername = 'PROD_APP_RWDDL'
			exec sp_addrolemember @rolename = 'db_datawriter',	@membername = 'PROD_APP_RWDDL'
			exec sp_addrolemember @rolename = 'db_ddladmin',	@membername = 'PROD_APP_RWDDL'
		end
	else
		begin
			print 'PROD_APP_RWDDL role already exists on database.'
		end

--Read/Execute Access -- not as per guidlines

	if not exists (select name from sys.database_principals where type = 'R' and name = 'PROD_APP_RX'  and is_fixed_role = 0)  
			begin
				CREATE ROLE PROD_APP_RX AUTHORIZATION [dbo];
				exec sp_addrolemember @rolename = 'db_datareader', @membername = 'PROD_APP_RX'
				GRANT EXECUTE TO PROD_APP_RX
			end
		else
			begin
				print 'PROD_APP_RX role already exists on database.'	
			end

--Read/Write/Ececute Access..Execute permission can be added as required for App Id's -- not as per guidlines
	
	if not exists (select name from sys.database_principals where type = 'R' and name = 'PROD_APP_RWX'  and is_fixed_role = 0)  
		begin
			CREATE ROLE PROD_APP_RWX AUTHORIZATION [dbo];
			exec sp_addrolemember @rolename = 'db_datareader', @membername = 'PROD_APP_RWX'
			exec sp_addrolemember @rolename = 'db_datawriter', @membername = 'PROD_APP_RWX'
			GRANT EXECUTE TO PROD_APP_RWX
		end
	else
		begin
			print 'PROD_APP_RWX role already exists on database.'
		end
	
--Database Owner 

	if not exists (select name from sys.database_principals where type = 'R' and name = 'PROD_APP_DBO'  and is_fixed_role = 0)  
		begin
			CREATE ROLE PROD_APP_DBO AUTHORIZATION [dbo];
			exec sp_addrolemember @rolename = 'db_owner', @membername = 'PROD_APP_DBO'
			
		end
	else
		begin
			print 'PROD_APP_DBO role already exists on database.'
		end

go  -- End of PROD SP.



-- Run environment specific SP based on domain.
use master

set nocount on
declare @domain char(9)
declare @Server_Env varchar(200)


set @domain = default_domain()

if exists (select 1 from master.dbo.sa_logins where LoginName = 'ENVIRONMENT')
begin
  select @Server_Env = Name from master.dbo.sa_logins where LoginName = 'ENVIRONMENT'
end

-- DEV

IF @domain = 'ADHCSCDEV' OR @Server_Env like 'DEVELOPMENT%'
BEGIN

declare @dbname	varchar(60), @sql varchar(255)

declare dbname_cursor CURSOR FOR     
	select name from sys.databases where   
		DATABASEPROPERTYEX(name,'STATUS') = 'ONLINE' 
		AND name not in ('master','msdb','tempdb','SSISConfigDB')
	order by name
  
   open dbname_cursor    
   fetch next from dbname_cursor into @dbname    
    
   while @@FETCH_STATUS = 0    
   begin    

		select @sql = 'use '+@dbname+';'+char(13)+'exec dbo.sp_Add_Security_Roles_DEV'
		exec(@sql)

		FETCH NEXT FROM dbname_cursor INTO @dbname    
     
	END   

   CLOSE dbname_cursor    
   DEALLOCATE dbname_cursor 
  
  use msdb



		if not exists (select name from sys.database_principals where type = 'R' and name = 'DEV_APP_DTS_OPR'  and is_fixed_role = 0)  
			begin
				CREATE ROLE DEV_APP_DTS_OPR AUTHORIZATION [dbo];
				exec sp_addrolemember @rolename = 'db_ssisoperator', @membername = 'DEV_APP_DTS_OPR'
			end
		else
			begin
				print 'DEV_APP_DTS_OPR role already exists on database.'		
			end
	
--SQLAgentOperatorRole		
		if not exists (select name from sys.database_principals where type = 'R' and name = 'DEV_DEVEL_AGT_OPR'  and is_fixed_role = 0)  
			begin
				CREATE ROLE DEV_DEVEL_AGT_OPR AUTHORIZATION [dbo];
				exec sp_addrolemember @rolename = 'SQLAgentOperatorRole', @membername = 'DEV_DEVEL_AGT_OPR'
			end
		else
			begin
				print 'DEV_DEVEL_AGT_OPR role already exists on database.'		
			end
---Adding  DEV_DEVEL_AGT_OPR role to the proxy account
		if exists (select name from dbo.sysproxies where name = 'SSIS_SQLProxy')
			begin
				if not exists (select sdp.name --DEV_DEVEL_AGT_OPR(SQLAgentOperatorRole) for sqlproxy
							from dbo.sysproxylogin spl inner join sys.database_principals sdp on (spl.sid = sdp.sid)
							where sdp.type = 'R' -- Role only
								and is_fixed_role = 0 -- Only user defined role
								and sdp.name = 'DEV_DEVEL_AGT_OPR'
								and proxy_id in (select proxy_id from dbo.sysproxies where name = 'SSIS_SQLProxy')
							)
					begin
						
						EXEC msdb.dbo.sp_grant_login_to_proxy 
							@proxy_name=N'SSIS_SQLProxy', -- proxy name, can go by proxy id also
						--	@login_name = N'?????' -- If need to add login
						--	@fixed_server_role = N'?????' -- If need to add server fixed role
							@msdb_role =N'DEV_DEVEL_AGT_OPR' -- For msdb user defined role
					end
				else
					begin
						print 'DEV_DEVEL_AGT_OPR(SQLAgentOperatorRole) is already added to Proxy "SSIS_SQLProxy"'
					end
			end
		else
			begin
				print 'Proxy ''SSIS_SQLProxy'' is not exists, pl. first create proxy account.'
			end

--SQLAgentOperatorRole for Applications		
		if not exists (select name from sys.database_principals where type = 'R' and name = 'DEV_APP_AGT_OPR'  and is_fixed_role = 0)  
			begin
				CREATE ROLE DEV_APP_AGT_OPR AUTHORIZATION [dbo];
				exec sp_addrolemember @rolename = 'SQLAgentOperatorRole', @membername = 'DEV_APP_AGT_OPR'
			end
		else
			begin
				print 'DEV_APP_AGT_OPR role already exists on database.'		
			end
---Adding  DEV_APP_AGT_OPR role to the proxy account
		if exists (select name from dbo.sysproxies where name = 'SSIS_SQLProxy')
			begin
				if not exists (select sdp.name --DEV_APP_AGT_OPR(SQLAgentOperatorRole) for sqlproxy
							from dbo.sysproxylogin spl inner join sys.database_principals sdp on (spl.sid = sdp.sid)
							where sdp.type = 'R' -- Role only
								and is_fixed_role = 0 -- Only user defined role
								and sdp.name = 'DEV_APP_AGT_OPR'
								and proxy_id in (select proxy_id from dbo.sysproxies where name = 'SSIS_SQLProxy')
							)
					begin
						
						EXEC msdb.dbo.sp_grant_login_to_proxy 
							@proxy_name=N'SSIS_SQLProxy', -- proxy name, can go by proxy id also
						--	@login_name = N'?????' -- If need to add login
						--	@fixed_server_role = N'?????' -- If need to add server fixed role
							@msdb_role =N'DEV_APP_AGT_OPR' -- For msdb user defined role
					end
				else
					begin
						print 'DEV_APP_AGT_OPR(SQLAgentOperatorRole) is already added to Proxy "SSIS_SQLProxy"'
					end
			end
		else
			begin
				print 'Proxy ''SSIS_SQLProxy'' is not exists, pl. first create proxy account.'
			end

END
GO

use master

set nocount on
declare @domain char(9)
declare @Server_Env varchar(200)

set @domain = default_domain()

if exists (select 1 from master.dbo.sa_logins where LoginName = 'ENVIRONMENT')
begin
  select @Server_Env = Name from master.dbo.sa_logins where LoginName = 'ENVIRONMENT'
end

-- TEST

IF @domain = 'ADHCSCTST' AND @Server_Env like 'TEST%'

BEGIN

declare @dbname	varchar(60), @sql varchar(255)

declare dbname_cursor CURSOR FOR     
	select name from sys.databases where   
		DATABASEPROPERTYEX(name,'STATUS') = 'ONLINE' 
		AND name not in ('master','msdb','tempdb','SSISConfigDB')
	order by name
  
   open dbname_cursor    
   fetch next from dbname_cursor into @dbname    
    
   while @@FETCH_STATUS = 0    
   begin    

		select @sql = 'use '+@dbname+';'+char(13)+'exec dbo.sp_Add_Security_Roles_TST'
		exec(@sql)

		FETCH NEXT FROM dbname_cursor INTO @dbname    
     
	END   

   CLOSE dbname_cursor    
   DEALLOCATE dbname_cursor 


  use msdb


	if not exists (select name from sys.database_principals where type = 'R' and name = 'TEST_APP_DTS_OPR'  and is_fixed_role = 0)  
		begin
			CREATE ROLE TEST_APP_DTS_OPR AUTHORIZATION [dbo];
			exec sp_addrolemember @rolename = 'db_ssisoperator', @membername = 'TEST_APP_DTS_OPR'
		end
	else
		begin
			print 'TEST_APP_DTS_OPR role already exists on database.'		
		end

--SQLAgentOperatorRole for Applications		
		if not exists (select name from sys.database_principals where type = 'R' and name = 'TEST_APP_AGT_OPR'  and is_fixed_role = 0)  
			begin
				CREATE ROLE TEST_APP_AGT_OPR AUTHORIZATION [dbo];
				exec sp_addrolemember @rolename = 'SQLAgentOperatorRole', @membername = 'TEST_APP_AGT_OPR'
			end
		else
			begin
				print 'TEST_APP_AGT_OPR role already exists on database.'		
			end
---Adding  TEST_APP_AGT_OPR role to the proxy account
		if exists (select name from dbo.sysproxies where name = 'SSIS_SQLProxy')
			begin
				if not exists (select sdp.name --TEST_APP_AGT_OPR(SQLAgentOperatorRole) for sqlproxy
							from dbo.sysproxylogin spl inner join sys.database_principals sdp on (spl.sid = sdp.sid)
							where sdp.type = 'R' -- Role only
								and is_fixed_role = 0 -- Only user defined role
								and sdp.name = 'TEST_APP_AGT_OPR'
								and proxy_id in (select proxy_id from dbo.sysproxies where name = 'SSIS_SQLProxy')
							)
					begin
						
						EXEC msdb.dbo.sp_grant_login_to_proxy 
							@proxy_name=N'SSIS_SQLProxy', -- proxy name, can go by proxy id also
						--	@login_name = N'?????' -- If need to add login
						--	@fixed_server_role = N'?????' -- If need to add server fixed role
							@msdb_role =N'TEST_APP_AGT_OPR' -- For msdb user defined role
					end
				else
					begin
						print 'TEST_APP_AGT_OPR(SQLAgentOperatorRole) is already added to Proxy "SSIS_SQLProxy"'
					end
			end
		else
			begin
				print 'Proxy ''SSIS_SQLProxy'' is not exists, pl. first create proxy account.'
			end
END
GO

use master

set nocount on
declare @domain char(9)


set @domain = default_domain()

-- PROD

IF @domain = 'ADHCSCINT'
BEGIN
  
declare @dbname	varchar(60), @sql varchar(255)

declare dbname_cursor CURSOR FOR     
	select name from sys.databases where   
		DATABASEPROPERTYEX(name,'STATUS') = 'ONLINE' 
		AND name not in ('master','msdb','tempdb','SSISConfigDB')
	order by name
  
   open dbname_cursor    
   fetch next from dbname_cursor into @dbname    
    
   while @@FETCH_STATUS = 0    
   begin    

		select @sql = 'use '+@dbname+';'+char(13)+'exec dbo.sp_Add_Security_Roles_PRD'
		exec(@sql)

		FETCH NEXT FROM dbname_cursor INTO @dbname    
     
	END   

   CLOSE dbname_cursor    
   DEALLOCATE dbname_cursor 
  
  use msdb


	if not exists (select name from sys.database_principals where type = 'R' and name = 'PROD_APP_DTS_OPR'  and is_fixed_role = 0)  
		begin
			CREATE ROLE PROD_APP_DTS_OPR AUTHORIZATION [dbo];
			exec sp_addrolemember @rolename = 'db_ssisoperator', @membername = 'PROD_APP_DTS_OPR'
		end
	else
		begin
			print 'PROD_APP_DTS_OPR role already exists on database.'		
		end

--SQLAgentOperatorRole for Applications		
		if not exists (select name from sys.database_principals where type = 'R' and name = 'PROD_APP_AGT_OPR'  and is_fixed_role = 0)  
			begin
				CREATE ROLE PROD_APP_AGT_OPR AUTHORIZATION [dbo];
				exec sp_addrolemember @rolename = 'SQLAgentOperatorRole', @membername = 'PROD_APP_AGT_OPR'
			end
		else
			begin
				print 'PROD_APP_AGT_OPR role already exists on database.'		
			end
---Adding  PROD_APP_AGT_OPR role to the proxy account
		if exists (select name from dbo.sysproxies where name = 'SSIS_SQLProxy')
			begin
				if not exists (select sdp.name --PROD_APP_AGT_OPR(SQLAgentOperatorRole) for sqlproxy
							from dbo.sysproxylogin spl inner join sys.database_principals sdp on (spl.sid = sdp.sid)
							where sdp.type = 'R' -- Role only
								and is_fixed_role = 0 -- Only user defined role
								and sdp.name = 'PROD_APP_AGT_OPR'
								and proxy_id in (select proxy_id from dbo.sysproxies where name = 'SSIS_SQLProxy')
							)
					begin
						
						EXEC msdb.dbo.sp_grant_login_to_proxy 
							@proxy_name=N'SSIS_SQLProxy', -- proxy name, can go by proxy id also
						--	@login_name = N'?????' -- If need to add login
						--	@fixed_server_role = N'?????' -- If need to add server fixed role
							@msdb_role =N'PROD_APP_AGT_OPR' -- For msdb user defined role
					end
				else
					begin
						print 'PROD_APP_AGT_OPR(SQLAgentOperatorRole) is already added to Proxy "SSIS_SQLProxy"'
					end
			end
		else
			begin
				print 'Proxy ''SSIS_SQLProxy'' is not exists, pl. first create proxy account.'
			end
END


use master;
drop procedure dbo.sp_Add_Security_Roles_DEV;
drop procedure dbo.sp_Add_Security_Roles_TST;
drop procedure dbo.sp_Add_Security_Roles_PRD;

