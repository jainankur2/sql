set nocount on
declare @login varchar(200)
declare @userid varchar(200)
declare @db_name varchar(200)
declare @sql varchar(8000)
declare @sql2 varchar(8000)
declare @domain char(9)
declare @environment varchar(4)
declare @counter int  


--*************

-- VALID ENVIRONMENTS - DEV, TEST, PROD - Needed for Hallmark only.  HCSC is automatic.

--*************

-- Populate variables

set @environment = ''
set @domain = DEFAULT_DOMAIN()
set @counter = 1

--*************
-- Check if a valid environment is selected (if Hallmark only).

if @domain not in  ('ADHCSCDEV','ADHCSCTST','ADHCSCINT')
 begin 
  if @environment not in ('DEV', 'TEST', 'PROD')
    begin
       Print 'Invalid environment value.  Valid environments are DEV, TEST or PROD.'
       GOTO DONE
    end
 end


--*****************************
-- Declare Database cursor

declare @dbname	varchar(200)

declare dbname_cursor CURSOR FOR     
	select name from sys.databases where   
		DATABASEPROPERTYEX(name,'STATUS') = 'ONLINE' 
		AND name not in ('master','tempdb','distribution','SSISConfigDB')
	order by name
  
   open dbname_cursor    
   fetch next from dbname_cursor into @dbname    
    
   while @@FETCH_STATUS = 0    
   begin
  
   set @sql2 = ''
   select @sql2 = char(13) + char(13) + 'USE [' + @dbname + '];' + CHAR(13) + CHAR(13)
   
   set @counter = 1

-- Declare Login cursor

   declare lgn_cursor cursor for
     select login_nm, userid from master.dbo.datamdl_tbl
   for read only

    	open lgn_cursor
	
	    fetch next from lgn_cursor into @login, @userid
	    while (@@fetch_status = 0)
	    begin

set @sql = ''


-- Development logic
if @domain = 'ADHCSCDEV' or @environment = 'DEV'
BEGIN

    if @counter = 1 
    begin 
      select @sql = '-- Database schema' + char(13) + char(13) + 'IF  EXISTS (SELECT * FROM sys.schemas WHERE name =  ''DEV_DATAMDL_RD'')' + 
      char(13) +'DROP Schema [DEV_DATAMDL_RD]' + char(13) + ';' + CHAR(13) + CHAR(13) +
      '--Database Roles' + char(13) + char(13) +
      'IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = ''DEV_DATAMDL_RD'')'+ char(13) +
      'exec sp_addrole @rolename =   [DEV_DATAMDL_RD]'+ char(13) +
      ';'+ char(13) + char(13)      
    end
      select @sql = @sql + char(13) + char(13) + '--Database users' + char(13) + char(13) +
      'IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name =  ''' + @userid + ''')' + char(13) +
      'CREATE USER [' + @userid + ']   FOR  LOGIN [' + @login + ']  WITH DEFAULT_SCHEMA = dbo' + char(13) +
      ';'+ char(13) +
      '--Database Roles and Members'+ char(13) +
      '--Role Memberships'+ char(13) + char(13) +
      'EXEC sp_addrolemember @rolename = "DEV_DATAMDL_RD", @membername = "' + @userid + '";'+ char(13) +
      'EXEC sp_addrolemember @rolename = "db_datareader", @membername = "DEV_DATAMDL_RD";'
      select @sql2 = @sql2 + @sql
END


-- Test Logic
if @domain = 'ADHCSCTST' or @environment = 'TEST'
BEGIN

    if @counter = 1 
    begin 
      select @sql = '-- Database schema' + char(13) + char(13) + 'IF  EXISTS (SELECT * FROM sys.schemas WHERE name =  ''TEST_DATAMDL_RD'')' + 
      char(13) +'DROP Schema [TEST_DATAMDL_RD]' + char(13) + ';' + CHAR(13) + CHAR(13) +
      '--Database Roles' + char(13) + char(13) +
      'IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = ''TEST_DATAMDL_RD'')'+ char(13) +
      'exec sp_addrole @rolename =   [TEST_DATAMDL_RD]'+ char(13) +
      ';'+ char(13) + char(13)
    end
      select @sql = @sql + char(13) + char(13) + '--Database users' + char(13) + char(13) +
      'IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name =  ''' + @userid + ''')' + char(13) +
      'CREATE USER [' + @userid + ']   FOR  LOGIN [' + @login + ']  WITH DEFAULT_SCHEMA = dbo' + char(13) +
      ';'+ char(13) +
      '--Database Roles and Members'+ char(13) +
      '--Role Memberships'+ char(13) + char(13) +
      'EXEC sp_addrolemember @rolename = "TEST_DATAMDL_RD", @membername = "' + @userid + '";'+ char(13) +
      'EXEC sp_addrolemember @rolename = "db_datareader", @membername = "TEST_DATAMDL_RD";'
      select @sql2 = @sql2 + @sql
END

--Production Logic
if @domain = 'ADHCSCINT' or @environment = 'PROD'
BEGIN
    if @counter = 1 
    begin 
      select @sql = '-- Database schema' + char(13) + char(13) + 'IF  EXISTS (SELECT * FROM sys.schemas WHERE name =  ''PROD_DATAMDL_RD'')' + 
      char(13) +'DROP Schema [PROD_DATAMDL_RD]' + char(13) + ';' + CHAR(13) + CHAR(13) +
      '--Database Roles' + char(13) + char(13) +
      'IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = ''PROD_DATAMDL_RD'')'+ char(13) +
      'exec sp_addrole @rolename =   [PROD_DATAMDL_RD]'+ char(13) +
      ';'+ char(13) + char(13)
    end
      select @sql = @sql  + char(13) + char(13) + '--Database users' + char(13) + char(13) +
      'IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name =  ''' + @userid + ''')' + char(13) +
      'CREATE USER [' + @userid + ']   FOR  LOGIN [' + @login + ']  WITH DEFAULT_SCHEMA = dbo' + char(13) +
      ';'+ char(13) +
      '--Database Roles and Members'+ char(13) +
      '--Role Memberships'+ char(13) + char(13) +
      'EXEC sp_addrolemember @rolename = "PROD_DATAMDL_RD", @membername = "' + @userid + '";'+ char(13) +
      'EXEC sp_addrolemember @rolename = "db_datareader", @membername = "PROD_DATAMDL_RD";'
      select @sql2 = @sql2 + @sql
END

           set @counter = @counter + 1

        fetch next from lgn_cursor into @login, @userid
	  end
	close lgn_cursor
	deallocate lgn_cursor
	
    EXEC(@sql2)
    
		FETCH NEXT FROM dbname_cursor INTO @dbname    
     
	END   

   CLOSE dbname_cursor    
   DEALLOCATE dbname_cursor  

DONE:
go


drop table master.dbo.datamdl_tbl

