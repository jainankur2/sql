use [master]
CREATE DATABASE SSISConfigDB;


--Creating credentials
USE [master]
GO

set nocount on
declare @domain char(9)
declare @sql varchar(5000)

set @domain = default_domain()

set @sql = 'CREATE CREDENTIAL [SQLProxyCredential]' + char(13) +  'WITH IDENTITY = N''' + @domain + '\sqlproxy'',' + char(13) + ' SECRET = N''password'''
exec (@sql)

GO
--Applying credentials to proxy account
USE [msdb]
GO
EXEC msdb.dbo.sp_add_proxy @proxy_name=N'SSIS_SQLProxy',@credential_name=N'SQLProxyCredential', @enabled=1
GO
-- Granting proxy permissions for job steps starting with Cmdexec,SSIS packages
--EXEC msdb.dbo.sp_grant_proxy_to_subsystem @proxy_name=N'SSIS_SQLProxy', @subsystem_id=2
--GO
EXEC msdb.dbo.sp_grant_proxy_to_subsystem @proxy_name=N'SSIS_SQLProxy', @subsystem_id=3
GO
EXEC msdb.dbo.sp_grant_proxy_to_subsystem @proxy_name=N'SSIS_SQLProxy', @subsystem_id=11
GO
EXEC msdb.dbo.sp_grant_proxy_to_subsystem @proxy_name=N'SSIS_SQLProxy', @subsystem_id=12
GO

set nocount on
declare @domain char(9)
declare @sql varchar(5000)

set @domain = default_domain()
set @sql = 'CREATE LOGIN [' + @domain + '\sqlproxy] FROM WINDOWS WITH DEFAULT_DATABASE=[master], DEFAULT_LANGUAGE=[us_english]'
exec (@sql)
GO

USE [msdb]
GO
set nocount on
declare @domain char(9)
declare @sql varchar(5000)

set @domain = default_domain()
set @sql = 'CREATE USER [sqlproxy] FOR LOGIN [' + @domain + '\sqlproxy] WITH DEFAULT_SCHEMA=[dbo]'
exec (@sql)
GO
EXEC sp_addrolemember 'db_ssisoperator', 'sqlproxy' 
GO

USE [SSISConfigDB]
GO

set nocount on
declare @domain char(9)
declare @sql varchar(5000)

set @domain = default_domain()
set @sql = 'CREATE USER [sqlproxy] FOR LOGIN [' + @domain + '\sqlproxy] WITH DEFAULT_SCHEMA=[dbo]'
exec (@sql)
GO
EXEC sp_addrolemember 'db_datareader', 'sqlproxy';

USE SSISConfigDB
GO
exec sp_changedbowner 'sa'
GO
