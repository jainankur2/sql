 USE [master]
GO
IF   EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_deac_delete_logins_auto_imprv]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_deac_delete_logins_auto_imprv]
go


/****** Object:  StoredProcedure [dbo].[usp_deac_delete_logins_auto_imprv]    Script Date: 07/29/2010 11:39:51 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
Created by	:  Babu Kondragunta
Create Date :  2008/12/17 9.13am
Description	:  Delete imperva disabled Logins.(SQL2012)         
Use			:  This SP is used to delete imperva disabled logins       
Parameters	: 
			: @servr_machn_id - Server Machine Id is for processing server. 
			: @servr_machn_nm - Server Machine name is for processing server.
			: @instnc_id - SQL Server Instance id for a machine.
			: @status_server_ip - SQL Server Instance IP address for Centerlize server to save staus.
			: @sql_id - Login Id to connect Centerlize server.
			: @sql_pwd - Password to connect Centerlize server.
			: @prc_typ - 2 For Imperva, 1 For AutoTerm
			
--Example to exec stored procedure:

exec dbo.usp_deac_delete_logins_auto_imprv 
	@servr_machn_id		= 451,
	@servr_machn_nm		= 'DVMSSQL02',	
	@instnc_id			= 587,			
	@status_server_ip	= '10.130.135.14',
	@sql_id				= 'DeacAdmin',
	@sql_pwd			= '',
	@prc_typ			= 2

	
--We need to create this stored procedure on master database on each SQL2012 Server.
--Once this procedure is created on master database, need to add entry in "systemsp" table on master database
--if we don't add entry on this table, alert will notify to on call DBA that system sp has been 
--modified on master database.

insert into SystemSP(id,name,number,colid,text)
select id,'usp_deac_delete_logins_auto_imprv' as name,number,colid,text 
from syscomments 
where id  in (select id from sysobjects where name = 'usp_deac_delete_logins_auto_imprv')

*/

create procedure [dbo].[usp_deac_delete_logins_auto_imprv]
	@servr_machn_id 	int,
	@servr_machn_nm		varchar(50),
	@instnc_id			int,
	@status_server_ip	varchar(50),
	@sql_id				varchar(10),
	@sql_pwd			varchar(20),
	@prc_typ			int = 2
	
as
SET NOCOUNT ON

declare @opendatasource varchar(250), 
		@openrowset		varchar(1000),
		@sql			varchar(1000),
		@sql_imprv		varchar(1000),
		@schema_nm		VARCHAR(50),
		@lgn_id			varchar(50),
		@lgn_nm			varchar(50),
		@db_nm			varchar(100),
		@usr_id			varchar(50),
		@err_desc		varchar(255)

/*

		@servr_machn_id 	int,
		@servr_machn_nm		varchar(50),
		@instnc_id			int,
		@status_server_ip	varchar(50),
		@sql_id				varchar(10),
		@sql_pwd			varchar(20),
		@prc_typ			tinyint

select 	@servr_machn_id		= 451,
		@servr_machn_nm		= 'DVMSSQL02',	
		@instnc_id			= 587,			
		@status_server_ip	= '10.130.135.14',
		@sql_id				= 'DeacAdmin',
		@sql_pwd			= '',
		@prc_typ			= 2
*/

select @err_desc = 'Please check the status file on R:\DEAC\AUTOTERM_IMPRV\TermServerStatus'

set @opendatasource = 'OPENDATASOURCE(''SQLOLEDB'',''Data Source='
						+@status_server_ip+';User ID='+@sql_id+';Password='
						+@sql_pwd+''').DEAC.dbo.'

--Create a  temp table to store imperva disabled logins for processing server
/*
drop table #Imperva_disabled_logins
drop table #delete_users
drop table #deac_trm_lgn_sta_usr
*/
create table #Imperva_disabled_logins(
	servr_machn_id 	int,
	servr_machn_nm	varchar(50),
	instnc_id		int,
	lgn_id			varchar(50),
	lgn_nm			varchar(60),
)

set @sql = 'select servr_machn_id, servr_machn_nm,instnc_id,lgn_id,lgn_nm
			from DEAC.dbo.deac_trm_lgn_sta
			where servr_machn_id = '+cast(@servr_machn_id as varchar)+' and instnc_id = '+cast(@instnc_id as varchar)
					+ ' and prc_typ = '+cast(@prc_typ as varchar)
					+' and LGN_STA = ''''Imp_Disabled'''' and datediff(day,dis_dt,getdate()) >= 14
			order by trm_dt,lgn_id'
--print 'del sel qry is : '+@sql
set @openrowset = 'insert into #Imperva_disabled_logins(servr_machn_id, servr_machn_nm,instnc_id,lgn_id,lgn_nm) 
						select a.* from OPENROWSET('+''''+'SQLOLEDB'+''''+','+''''+@status_server_ip+''''+';'+''''
						+@sql_id+''';'''+@sql_pwd+''','''
						+@sql+''''+') as a'
--print 'Openrowset is: '+@openrowset

exec (@openrowset)

--select * from #Imperva_disabled_logins

-- Temp table to for database users
CREATE TABLE #delete_users(
	servr_machn_id	INT,
	servr_machn_nm	VARCHAR(100),
	instnc_id		INT,
	db_nm			VARCHAR(50),
	schema_nm		VARCHAR(50),
	lgn_id			VARCHAR(50),
	usr_id			VARCHAR(50),
	lgn_nm			VARCHAR(50)
)

--Check id's own any objects ...start
DECLARE dbname_cursor CURSOR FOR     
SELECT name FROM sys.databases 
WHERE DATABASEPROPERTYEX(name,'STATUS') = 'ONLINE'
ORDER BY name
  
OPEN dbname_cursor    
FETCH next FROM dbname_cursor INTO @db_nm    
    
WHILE @@FETCH_STATUS = 0    
	BEGIN --Start of outside begin   
		IF (DATABASEPROPERTYEX(@db_nm,'STATUS') = 'ONLINE'  AND DATABASEPROPERTYEX(@db_nm,'Updateability') = 'READ_WRITE')
			BEGIN --Start of inside Begin
				SELECT @sql = ' SELECT dl.servr_machn_id,dl.servr_machn_nm,dl.instnc_id, '''+@db_nm+''' AS dbname, 
										su.default_schema_name AS schema_nm, sl.name AS lgn_id,su.name AS usr_id,dl.lgn_nm
								FROM #Imperva_disabled_logins dl 
								INNER JOIN sys.sql_logins sl (NoLock) ON (SUSER_SNAME(sl.sid) = dl.lgn_id)
								INNER JOIN ['+@db_nm+'].sys.database_principals su (NoLock) ON (SUSER_SNAME(su.sid) = dl.lgn_id)
								WHERE SUSER_SNAME(su.sid) = SUSER_SNAME(sl.sid) '
			END --End of inside begin

		INSERT INTO #delete_users (servr_machn_id,servr_machn_nm,instnc_id,db_nm,schema_nm,lgn_id,usr_id,lgn_nm)
 		EXEC (@sql)    
  
		FETCH NEXT FROM dbname_cursor INTO @db_nm    
    END --End of outside begin    
CLOSE dbname_cursor    
DEALLOCATE dbname_cursor 
--Check id's own any objects ...over
-- SELECT * FROM #delete_users

INSERT INTO #delete_users (servr_machn_id,servr_machn_nm,instnc_id,lgn_id,lgn_nm)
SELECT servr_machn_id,servr_machn_nm,instnc_id,lgn_id,lgn_nm 
FROM #Imperva_disabled_logins 
WHERE lgn_id IN (SELECT name FROM sys.sql_logins (NoLock))

--select * from #delete_users
--select * from #delete_users where db_nm is null

--ID disabled...need to be DELETED
--Create a temp table to store staus of Deleted Logins and Users

create table #deac_trm_lgn_sta_usr(
	servr_machn_id	int,
	servr_machn_nm	varchar(100),
	instnc_id		int,
	lgn_id			varchar(50),
	lgn_nm			varchar(50),
	db_nm			varchar(100),
	usr_id			varchar(50),
	lgn_sta			varchar(50),
	del_dt			smalldatetime,
	prc_typ			tinyint, --Process type 1-Terminated, 2-Imperva
	remarks			varchar(1000)
)

INSERT INTO dbo.#deac_trm_lgn_sta_usr(servr_machn_id, servr_machn_nm,instnc_id,lgn_id,lgn_nm,lgn_sta,del_dt,prc_typ,remarks)
SELECT 		servr_machn_id,servr_machn_nm,instnc_id,lgn_id,lgn_nm,'Deleted' AS lgn_sta,GETDATE() del_dt,@prc_typ,
			'Login Already deleted' AS remarks
FROM #Imperva_disabled_logins WHERE lgn_id NOT IN (SELECT name FROM sys.sql_logins (NoLock))

--select * from #deac_trm_lgn_sta_usr


DECLARE mtch_lgn_cursor CURSOR FOR 
SELECT DISTINCT servr_machn_id,servr_machn_nm,instnc_id,db_nm,schema_nm,lgn_id,usr_id,lgn_nm 
FROM  #delete_users 
ORDER BY lgn_id,db_nm DESC,usr_id DESC

OPEN mtch_lgn_cursor
FETCH next FROM mtch_lgn_cursor INTO @servr_machn_id,@servr_machn_nm,@instnc_id,@db_nm,@schema_nm,@lgn_id,@usr_id,@lgn_nm

WHILE @@FETCH_STATUS = 0
	BEGIN -- starting of cursor begin
		BEGIN TRY -- Begining of Try Blcok
			IF @db_nm IS NULL
				BEGIN -- starting of if begin
					SELECT @sql = 'DROP LOGIN  ['+@lgn_id+']'
					EXEC (@sql)
					INSERT INTO dbo.#deac_trm_lgn_sta_usr (servr_machn_id, servr_machn_nm,instnc_id,lgn_id,lgn_nm,lgn_sta,del_dt,prc_typ,remarks)
					SELECT @servr_machn_id,@servr_machn_nm,@instnc_id,@lgn_id,@lgn_nm,'Deleted' AS lgn_sta,GETDATE() del_dt,@prc_typ,
							@sql AS remarks
				END -- end of if begin
			ELSE
				BEGIN -- starting of else begin
					IF @schema_nm = @usr_id AND @schema_nm <> 'dbo'
						BEGIN -- Begin of inside if
						SELECT @sql = 'USE '+@db_nm+'; DROP SCHEMA ['+@schema_nm+'] ;'
						--PRINT @sql
						EXEC(@sql)
						INSERT INTO dbo.#deac_trm_lgn_sta_usr(servr_machn_id, servr_machn_nm,instnc_id,lgn_id,lgn_nm,db_nm,usr_id,
																lgn_sta,del_dt,prc_typ,remarks)
						SELECT @servr_machn_id,@servr_machn_nm,@instnc_id,@lgn_id,@lgn_nm,@db_nm,@usr_id,'Deleted' AS lgn_sta,
								GETDATE() AS del_dt,@prc_typ,@sql AS remarks
					END -- End of inside if Begin
				SELECT @sql = 'USE '+@db_nm+'; DROP USER ['+@usr_id+'];'
				--PRINT 'Sql is'+@sql
				EXEC (@sql)
				INSERT INTO dbo.#deac_trm_lgn_sta_usr(servr_machn_id, servr_machn_nm,instnc_id,lgn_id,lgn_nm,db_nm,usr_id,
														lgn_sta,del_dt,prc_typ,remarks)
				SELECT @servr_machn_id,@servr_machn_nm,@instnc_id,@lgn_id,@lgn_nm,@db_nm,@usr_id,'Deleted' AS lgn_sta,GETDATE() del_dt,
						@prc_typ,@sql AS remarks
			END -- end of else begin
		END TRY --End of Try block
		BEGIN CATCH --Begin of Catch Block
			INSERT INTO dbo.#deac_trm_lgn_sta_usr (servr_machn_id, servr_machn_nm,instnc_id,lgn_id,lgn_nm,lgn_sta,del_dt,prc_typ,remarks)
			SELECT @servr_machn_id,@servr_machn_nm,@instnc_id,@lgn_id,@lgn_nm,'Error' AS lgn_sta,GETDATE() del_dt,
					@prc_typ,LEFT(ERROR_MESSAGE(),900)+@err_desc AS remarks
		END CATCH --End of Catch Block
      FETCH next FROM mtch_lgn_cursor INTO @servr_machn_id,@servr_machn_nm,@instnc_id,@db_nm,@schema_nm,@lgn_id,@usr_id,@lgn_nm
   
   END -- end of cursor begin


CLOSE mtch_lgn_cursor
DEALLOCATE mtch_lgn_cursor
--select * from #deac_trm_lgn_sta_usr order by lgn_id,db_nm desc

--Ouput from the below query needs to be inserted into DEAC.deac_trm_lgn_sta_usr on DVMSSQLCLDB1 for status.
--select * from #deac_trm_lgn_sta_usr order by lgn_id,db_nm desc
set nocount off

select @sql = 'insert into '+@opendatasource+'deac_trm_lgn_sta_usr(SERVR_MACHN_ID,SERVR_MACHN_NM,INSTNC_ID,LGN_ID,LGN_NM,
													DB_NM,USR_ID,DEL_DT,LGN_STA,PRC_TYP,REMARKS)	
				select servr_machn_id,servr_machn_nm,instnc_id, lgn_id,lgn_nm,db_nm,usr_id,del_dt,lgn_sta,prc_typ,remarks
				from #deac_trm_lgn_sta_usr 
				order by lgn_id,db_nm desc'

--print 'SQL for deac_trm_lgn_sta_usr is: '+@sql
exec(@sql)
go
grant exec on usp_deac_delete_logins_auto_imprv to public
go
