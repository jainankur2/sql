# Changelog for ansible-Microsoft_SQL_Server
---------------------------------------------

Add new versions on **TOP** of older versions so we don't have to scroll to look for new changes. A link to a Jira ticket is usually sufficient, obviously more is better. Don't need to write a book though!

## 2.0.3

* [INFRA-451](https://jira.fyiblue.com/browse/INFRA-451) Add SQLProxy credential

## 2.0.2

* [INFRA-230](https://jira.fyiblue.com/browse/INFRA-230) Create an entry in EDBA server for new SQL Server
* [INFRA-231](https://jira.fyiblue.com/browse/INFRA-231) Ansible to execute Security scripts
* [INFRA-232](https://jira.fyiblue.com/browse/INFRA-232) Execute SQL post install scripts and EDBA security script
* Updated task names in sql_install role

## 2.0.1

* [INFRA-506](https://jira.fyiblue.com/browse/INFRA-506) Fixed Max Memory setting for Large SQL servers to be 13312MB.

## 2.0.0
------------------

* [INFRA-395](https://jira.fyiblue.com/browse/INFRA-395) Refactored use variables files to remove duplicate code and added README.md.

## 1.0.0
------------------

* Playbook that was refactored by Red Hat Consulting.


## 0.0.1
------------------

* Initial playbook that was created by HCL.
