# ansible-Microsoft_SQL_Server Playbook

Provides roles for the installation and configuration of Microsoft SQL Server server. Includes several basic tasks that install and configure resources.

## Version
2.0.0

## Requirements

### Platforms

- Windows Server 2012 R2

### Supported Server Verions

- Microsoft SQL Server 2014

### Ansible

- Ansible Tower 3.2.2
- Ansible 2.4.2.0

## Playbooks
- `workflow_router.yml` 
    - This play is designed to route an SQL Playbook to Test or Prod
- `sql2014-install.yml`
    - Gathers facts and loads production variables if necessary
    - Includes role `netframework` and executes the `sql_install` role with `SQL_VERSION` set to `2014`
- `sql_uninstall.yml`
    - Gathers facts and loads production variables if necessary
    - Loops through to includes role `uninstall_sql` 5 times!!!

## Prerequisites
Playbook requires the following binaries located on the localhost:

- /var/ansible/binaries/Sql2014/2014_SQL_SERVER_enterprise.zip
- /var/ansible/binaries/Sql2014/SSDT_14.0.61021.0_EN.zip

## Testing
To test the playbook, use the following `ansible-playbook` command example. Any of the extra variables that we want to override for running the playbook requires can be found in `extra_vars.yml`.  Verify that the `inventory` contains the name of the machine that you want to test aginst.  In the example below we are passing in the username and requesting the password for the SQL server we are installing SQL Server to.

`ansible-playbook -e @extra_vars.yml --ask-vault-pass -i inventory sql2014-install.yml -u 67340004@ADHCSCTST.NET -k`

## Roles

### netframework

#### Variables 
- `REMOTE_PATH` - Location for the installation files of the sxs.zip file 
    - `Default value` = 'C:\Software_Agents'

#### Handlers
- `remove sxs zip` - Deletes the sxs.zip file from the `REMOTE_PATH`

#### Tasks
- `main.yml` 
    - Validates that dotnet_version variable is defined
    - Installs .NET Framework Windows Feature (3 or 4.5)
    - Extracts sxs.zip file in `REMOTE_PATH`
    - Reboots the node

### sql_install

#### Variables 

- `default/main.yml`
    - `REMOTE_PATH` - Location for the SQL installation files and scripts
        - `Default value` = 'D:\sql'

    - `SQL_POLICIES` - List of security policies to automate.  The translations come from https://docs.microsoft.com/en-us/previous-versions/windows/it-pro/windows-server-2008-R2-and-2008/dd349804(v=ws.10)
        - `Default value`
            - 'SeTcbPrivilege'
            - 'SeIncreaseQuotaPrivilege'
            - 'SeChangeNotifyPrivilege'
            - 'SeLockMemoryPrivilege'
            - 'SeBatchLogonRight'
            - 'SeServiceLogonRight'
            - 'SeManageVolumePrivilege'
            - 'SeAssignPrimaryTokenPrivilege'

- `vars/main.yml`
    - `SQL_EDITION` - Used to determine the path of SQL binaries
        - `Default value` = enterprise
    - `SERVICE_TYPE`
        - `Default value` = DEDICATED
    - `EDBA_HOSTNAME`
        - `Default value` =  pwauswifsq05.adhcscint.net (Test EDBA server = twauswifsq07.adhcsctst.net)
    - `APPLICATION_ID`
        - `Default value` = 'APP00006291'
    - `SIZE`
        -`Default value` = SMALL

- `vars/[Offshore|Onshare]_[test|prod]_accounts`
    - `SQL_GROUPS` - Groups that are added to the local Administrators group, the `SQL_POLICIES` local security policies and group is added a SQL Sys Admin group.
    - `SQL_ADMIN_GROUPS` - Groups that are added to the local Administrators group and group is added a SQL Sys Admin group.
    - `SQL_PROXY_USER` - User that is added to the SeBatchLogonRight local security policy.
    - `SQL_SERVICE_USER` - User account used to run the SQL Server Service, Full Text Service and a SQL Sys Admin account.
    - `SQL_AGENT_USER` - User account used to run the SQL Agent Service and a SQL Sys Admin account.
    - `ANSIBLE_ACCOUNT` - Ansible account used as the become user for install SQL Server and a SQL Sys Admin account.

- `vars/[Offshore|Onshare]_secrets`
    - `sa_password` - SQL SA password
    - `sql_svc_password` - SQL Server Service account password
    - `sql_agt_password` - SQL Agent Service account password

- `vars/[test|prod]_secrets`
    - `ansible_password` - Ansible user account password

#### Handlers
- `remove setup zipfile` - Deletes the SQL binaries file from the `REMOTE_PATH` after installation
- `remove ssdt zipfile` - Remove ssdt binaries from the `REMOTE_PATH` after installation

#### Templates
- `compatibility_GENERIC.sql.j2` - NOT CURRENTLY USED
- `ConfigurationNPID.ini.j2` - File that will be used for silent SQL Server installation
- `degreeofparallelism_GENERIC.bat.j2` - Batch script to run SQL script to set Max Degree of Parallelism
- `degreeofparallelism_GENERIC.sql.j2` - SQL script to set Max Degree of Parallelism
- `edba_add_server.sql.j2` - Used to create a script to generate a script to insert an entry into the EDBA database
- `edba_security.sql.j2` - Used to create a script to generate a script based on information from the EDBA database to be executed on target SQL Server
- `physicalmemory_GENERIC.bat.j2` - Batch script to run SQL script to configure SQL Server physical memory allocation
- `physicalmemory_GENERIC.sql.j2` - SQL script to configure SQL Server physical memory allocation
- `tempdb_GENERIC.bat.j2` - Batch script to run SQL script to configure SQL Server temp db
- `tempdb_GENERIC.sql.j2` - SQL script to run configure SQL Server temp db

#### Tasks
- `main.yml` 
    - Validates that SQL_VERSION, SQL_ACCOUNTS, and env variables are defined
    - Checks to see if SQL Server is already installed
    - Gets the IP Address and Hostname of target SQL Server used for EDBA script
    - Executes `configure_os.yml` task
    - Executes `sql_install_prereqs.yml` task
    - Reboots the node
    - Executes `sql_install.yml` task    
    - Executes `configure_sql.yml` task
    - Executes `edba_scripts.yml` task
    - Executes `post_install_scripts.yml` task    

- `conficonfigure_os.yml` 
    - Sets the VisualFXSetting Registry Key to 2
    - Sets the Win32PrioritySeparation Registry Key to 24
    - Updates the boot configuration operating systems time to 5 using bcdedit

- `sql_install_prereqs.yml` 
    - Loads the proper account and secrets values using variable files
    - Create the `REMOTE_PATH` folder for SQL installation binaries and scripts
    - Adds the proper groups to the local administrators group
    - Adds the proper groups to the local security policies
    - Copies down  and extracts the SQL binaries to the `REMOTE_PATH` folder
    - Deletes the SQL zip file from the `REMOTE_PATH` folder
    - Flushes local DNS cache

- `sql_install.yml` 
    - Loads the proper secrets values using variable files
    - Sets proper facts that will be used in the SQL configuration ini file
    - Generates a ConfigurationNPID.ini file the `REMOTE_PATH` folder for a silent SQL installation
    - Silently installs SQL Server using ConfigurationNPID.ini file    
    - Deletes the ConfigurationNPID.ini file the `REMOTE_PATH` folder

- `configure_sql.yml` 
    - Disables indexing on SQLDATA and SQLLOGS drives
    - Sets proper facts based on "t-shirt size"
    - Configures max degree of parallelism based on "t-shirt size"
    - Configures temp db based on "t-shirt size"
    - Configures physical memory utilization based on "t-shirt size"
    - Sets up TCP/IP for SQL Server
    - Copies, extracts, and install SQL SSDT using the zip file

- `edba_scripts.yml` 
    - Generates and executes script, edba_add_server_out.sql, that will add an entry to EDBA database for target SQL Server.
    - Generates a script, edba_security_out.sql, that will configure database security on target SQL Server based on values in EDBA server
    - Copies edba_security_out.sql to Ansible server and cleans it up from EDBA server

- `post_install_scripts.yml` 
    - Copies edba_security_out.sql from Ansible server to target SQL Server
    - Executes edba_security_out.sql on target SQL Server
    - Copies post install SQL scripts to target SQL Server
    - Determines which post install SQL scripts to execute based on contents of folder and if there is a corresponding .out file.
    - Executes the post install SQL scripts that do not have a .out file
    - Cleans up `REMOTE_PATH` folder from target server


### uninstall_sql

#### Variables
- `default/main.yml`
    - `SQL_DOMAIN_ACCOUNTS`
    - `SQL_POLICIES`
- `vars/main.yml`

#### Tasks
- `main.yml`
    - Stop all SQL Services
    - Unisntall SQL Programs
    - Remove the `SQL_DOMAIN_ACCOUNTS` from all associated security policies `SQL_POLICIES`
    - Statically erase identified files in W, X, Y Z drives
    - Clear out temp ansible data
    - Remove Windows registry keys
    - Reboot VM
    - Clear out Microsoft SQL Server files under Program files in C and D drives

## Authors

**Author:** Cloud Automtion Engineering Team ([CloudAutomationEngineering@hcsc.net](mailto:CloudAutomationEngineering@hcsc.net))
